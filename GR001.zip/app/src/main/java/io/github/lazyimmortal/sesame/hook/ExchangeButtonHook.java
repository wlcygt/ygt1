package io.github.lazyimmortal.sesame.hook;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewParent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * 将商品页中的“本轮已抢光”状态统一显示为“立即兑换”，并恢复按钮可点击状态。
 */
public final class ExchangeButtonHook {

    private static final String TAG = "ExchangeButtonHook";
    private static final String EXCHANGE_TEXT = "立即兑换";
    private static final String[] SOLD_OUT_TEXTS = {
            "本轮已抢光",
            "本轮已抢完",
            "已抢光",
            "已抢完",
            "已售罄",
            "已兑完"
    };

    private static final Map<View, Boolean> FORCED_VIEWS = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static volatile boolean installed = false;

    private ExchangeButtonHook() {
    }

    public static synchronized void setupHook(ClassLoader classLoader) {
        if (installed) {
            return;
        }
        installed = true;

        hookSetTextCharSequence();
        hookSetTextBufferType();
        hookViewState();
        hookWebView(classLoader);
    }

    private static void hookSetTextCharSequence() {
        try {
            XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    CharSequence text = (CharSequence) param.args[0];
                    if (replaceSoldOutText(view, text)) {
                        param.args[0] = EXCHANGE_TEXT;
                    }
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    if (isForced(view)) {
                        forceView(view);
                    }
                }
            });
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setText(CharSequence) error", throwable);
        }
    }

    private static void hookSetTextBufferType() {
        try {
            XposedHelpers.findAndHookMethod(
                    TextView.class,
                    "setText",
                    CharSequence.class,
                    TextView.BufferType.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            View view = (View) param.thisObject;
                            CharSequence text = (CharSequence) param.args[0];
                            if (replaceSoldOutText(view, text)) {
                                param.args[0] = EXCHANGE_TEXT;
                            }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            View view = (View) param.thisObject;
                            if (isForced(view)) {
                                forceView(view);
                            }
                        }
                    }
            );
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setText(CharSequence, BufferType) error", throwable);
        }
    }

    private static void hookViewState() {
        hookSetEnabled();
        hookSetClickable();
        hookSetFocusable();
        hookSetAlpha();
    }

    private static void hookSetEnabled() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "setEnabled", boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    if (isForced(view) && Boolean.FALSE.equals(param.args[0])) {
                        param.args[0] = Boolean.TRUE;
                    }
                }
            });
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setEnabled error", throwable);
        }
    }

    private static void hookSetClickable() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "setClickable", boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    if (isForced(view) && Boolean.FALSE.equals(param.args[0])) {
                        param.args[0] = Boolean.TRUE;
                    }
                }
            });
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setClickable error", throwable);
        }
    }

    private static void hookSetFocusable() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "setFocusable", boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    if (isForced(view) && Boolean.FALSE.equals(param.args[0])) {
                        param.args[0] = Boolean.TRUE;
                    }
                }
            });
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setFocusable error", throwable);
        }
    }

    private static void hookSetAlpha() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "setAlpha", float.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    View view = (View) param.thisObject;
                    float alpha = (Float) param.args[0];
                    if (isForced(view) && alpha < 1.0f) {
                        param.args[0] = 1.0f;
                    }
                }
            });
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook setAlpha error", throwable);
        }
    }

    private static void hookWebView(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    WebViewClient.class,
                    "onPageFinished",
                    WebView.class,
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            injectIntoWebView((WebView) param.args[0]);
                        }
                    }
            );
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook WebViewClient.onPageFinished error", throwable);
        }

        try {
            XposedHelpers.findAndHookMethod(
                    "android.webkit.WebView",
                    classLoader,
                    "loadUrl",
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(final MethodHookParam param) {
                            final WebView webView = (WebView) param.thisObject;
                            MAIN_HANDLER.postDelayed(() -> injectIntoWebView(webView), 800L);
                        }
                    }
            );
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook WebView.loadUrl error", throwable);
        }
    }

    private static boolean replaceSoldOutText(View view, CharSequence source) {
        if (view == null || source == null || !isSoldOutText(source.toString())) {
            return false;
        }
        markForced(view);
        return true;
    }

    private static boolean isSoldOutText(String text) {
        if (text == null) {
            return false;
        }
        String normalized = text.replaceAll("\\s+", "").trim();
        for (String soldOutText : SOLD_OUT_TEXTS) {
            if (normalized.contains(soldOutText)) {
                return true;
            }
        }
        return false;
    }

    private static void markForced(View view) {
        if (view == null) {
            return;
        }
        FORCED_VIEWS.put(view, Boolean.TRUE);
        ViewParent parent = view.getParent();
        int depth = 0;
        while (parent instanceof View && depth < 3) {
            FORCED_VIEWS.put((View) parent, Boolean.TRUE);
            parent = parent.getParent();
            depth++;
        }
    }

    private static boolean isForced(View view) {
        return view != null && FORCED_VIEWS.containsKey(view);
    }

    private static void forceView(final View view) {
        if (view == null) {
            return;
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            forceViewNow(view);
        } else {
            MAIN_HANDLER.post(() -> forceViewNow(view));
        }
    }

    private static void forceViewNow(View view) {
        View current = view;
        int depth = 0;
        while (current != null && depth < 4) {
            FORCED_VIEWS.put(current, Boolean.TRUE);
            current.setEnabled(true);
            current.setClickable(true);
            current.setFocusable(true);
            current.setAlpha(1.0f);
            ViewParent parent = current.getParent();
            current = parent instanceof View ? (View) parent : null;
            depth++;
        }
    }

    private static void injectIntoWebView(final WebView webView) {
        if (webView == null) {
            return;
        }
        MAIN_HANDLER.post(() -> {
            try {
                webView.evaluateJavascript(WEBVIEW_SCRIPT, null);
            } catch (Throwable throwable) {
                io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " inject WebView script error", throwable);
            }
        });
    }

    private static final String WEBVIEW_SCRIPT =
            "(function(){" +
                    "if(window.__sesameExchangeButtonHooked)return;" +
                    "window.__sesameExchangeButtonHooked=true;" +
                    "var target='立即兑换';" +
                    "var words=['本轮已抢光','本轮已抢完','已抢光','已抢完','已售罄','已兑完'];" +
                    "function fix(el){" +
                    "if(!el)return;" +
                    "var text=(el.textContent||'').replace(/\\s+/g,'').trim();" +
                    "if(!text)return;" +
                    "for(var i=0;i<words.length;i++){" +
                    "if(text===words[i]||(text.indexOf(words[i])>=0&&text.length<=words[i].length+8)){" +
                    "el.textContent=target;" +
                    "el.removeAttribute('disabled');" +
                    "el.setAttribute('aria-disabled','false');" +
                    "el.disabled=false;" +
                    "el.style.pointerEvents='auto';" +
                    "el.style.opacity='1';" +
                    "if(el.classList){el.classList.remove('disabled');el.classList.remove('van-button--disabled');}" +
                    "var p=el;" +
                    "for(var j=0;j<4&&p;j++){" +
                    "p.removeAttribute('disabled');" +
                    "p.setAttribute('aria-disabled','false');" +
                    "p.style.pointerEvents='auto';" +
                    "p.style.opacity='1';" +
                    "if(p.classList){p.classList.remove('disabled');p.classList.remove('van-button--disabled');}" +
                    "p=p.parentElement;" +
                    "}" +
                    "return;" +
                    "}" +
                    "}" +
                    "}" +
                    "function scan(root){" +
                    "if(!root||!root.querySelectorAll)return;" +
                    "var list=root.querySelectorAll('*');" +
                    "for(var i=0;i<list.length;i++)fix(list[i]);" +
                    "}" +
                    "var pending=false;" +
                    "function schedule(){" +
                    "if(pending)return;" +
                    "pending=true;" +
                    "setTimeout(function(){pending=false;scan(document);},50);" +
                    "}" +
                    "scan(document);" +
                    "if(window.MutationObserver&&document.documentElement){" +
                    "new MutationObserver(schedule).observe(document.documentElement,{subtree:true,childList:true,characterData:true});" +
                    "}" +
                    "})();";
}
