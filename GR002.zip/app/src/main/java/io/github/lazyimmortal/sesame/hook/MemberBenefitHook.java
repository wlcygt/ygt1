package io.github.lazyimmortal.sesame.hook;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import io.github.lazyimmortal.sesame.data.ConfigV2;
import io.github.lazyimmortal.sesame.data.ModelField;
import io.github.lazyimmortal.sesame.data.ModelFields;
import io.github.lazyimmortal.sesame.util.ClassUtil;

/**
 * 支付宝会员权益页“立即兑换”适配。
 *
 * <p>详情页会依据 exchangeable、exchangeStartDt、exchangeEndDt、reserve、
 * notSupportExchangeReason 等字段决定按钮状态。这里只修改客户端收到的展示数据，
 * 让详情页显示“立即兑换”，并允许正常进入订单确认页。</p>
 */
public final class MemberBenefitHook {

    private static final String TAG = "MemberBenefitHook";
    public static final String MODEL_CODE = "AntMember";
    public static final String FIELD_CODE = "memberBenefitForceExchangeButton";

    private static final String OP_DETAIL = "querySingleBenefitDetail";
    private static final String OP_COPY_DETAIL = "querySingleBenefitCopyDetail";
    private static final String OP_ORDER_CONFIRM = "queryPromoBenefitOrderConfirmInfo";
    private static final String OP_COPY_ORDER_CONFIRM = "queryPromoCopyBenefitOrderConfirmInfo";
    private static final long EXCHANGE_WINDOW_MILLIS = 30L * 24L * 60L * 60L * 1000L;

    private static final Map<Object, String> RPC_METHOD_MAP = Collections.synchronizedMap(new WeakHashMap<>());
    private static volatile boolean installed = false;
    private static volatile boolean enabled = false;
    private static volatile long nextEnabledCheck = 0L;

    private MemberBenefitHook() {
    }

    public static synchronized void setupHook(ClassLoader classLoader) {
        if (installed) {
            return;
        }
        installed = true;
        try {
            Class<?> jsonObjectClass = XposedHelpers.findClass(ClassUtil.JSON_OBJECT_NAME, classLoader);
            hookRpcRequest(classLoader, jsonObjectClass);
            hookRpcResponse(classLoader, jsonObjectClass);
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " setupHook error", throwable);
        }
    }

    public static boolean isEnabled() {
        long now = System.currentTimeMillis();
        if (now >= nextEnabledCheck) {
            enabled = readEnabled();
            nextEnabledCheck = now + 1000L;
        }
        return enabled;
    }

    private static boolean readEnabled() {
        try {
            ModelFields modelFields = ConfigV2.INSTANCE.getModelFieldsMap().get(MODEL_CODE);
            if (modelFields == null) {
                return false;
            }
            ModelField<?> modelField = modelFields.get(FIELD_CODE);
            return modelField != null && Boolean.TRUE.equals(modelField.getValue());
        } catch (Throwable throwable) {
            return false;
        }
    }

    private static void hookRpcRequest(ClassLoader classLoader, Class<?> jsonObjectClass) {
        try {
            Class<?> appClass = XposedHelpers.findClass("com.alibaba.ariver.app.api.App", classLoader);
            Class<?> pageClass = XposedHelpers.findClass("com.alibaba.ariver.app.api.Page", classLoader);
            Class<?> apiContextClass = XposedHelpers.findClass("com.alibaba.ariver.engine.api.bridge.model.ApiContext", classLoader);
            Class<?> callbackClass = XposedHelpers.findClass(
                    "com.alibaba.ariver.engine.api.bridge.extension.BridgeCallback",
                    classLoader
            );
            XposedHelpers.findAndHookMethod(
                    "com.alibaba.ariver.commonability.network.rpc.RpcBridgeExtension",
                    classLoader,
                    "rpc",
                    String.class,
                    boolean.class,
                    boolean.class,
                    String.class,
                    jsonObjectClass,
                    String.class,
                    jsonObjectClass,
                    boolean.class,
                    boolean.class,
                    int.class,
                    boolean.class,
                    String.class,
                    appClass,
                    pageClass,
                    apiContextClass,
                    callbackClass,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Object callback = param.args[15];
                            if (callback != null) {
                                RPC_METHOD_MAP.put(callback, String.valueOf(param.args[0]));
                            }
                        }

                    }
            );
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook RpcBridgeExtension.rpc error", throwable);
        }
    }

    private static void hookRpcResponse(ClassLoader classLoader, Class<?> jsonObjectClass) {
        try {
            XposedHelpers.findAndHookMethod(
                    "com.alibaba.ariver.engine.common.bridge.internal.DefaultBridgeCallback",
                    classLoader,
                    "sendJSONResponse",
                    jsonObjectClass,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (!isEnabled()) {
                                return;
                            }
                            String operationType = RPC_METHOD_MAP.remove(param.thisObject);
                            if (operationType == null) {
                                return;
                            }
                            mutateResponse(param.args[0], operationType);
                        }
                    }
            );
        } catch (Throwable throwable) {
            io.github.lazyimmortal.sesame.util.Log.printStackTrace(TAG + " hook sendJSONResponse error", throwable);
        }
    }

    private static void mutateResponse(Object response, String operationType) {
        if (response == null || operationType == null) {
            return;
        }
        if (operationType.contains(OP_DETAIL) || operationType.contains(OP_COPY_DETAIL)) {
            mutateNode(response, true);
            io.github.lazyimmortal.sesame.util.Log.i(TAG, "force detail button: " + operationType);
        } else if (operationType.contains(OP_ORDER_CONFIRM) || operationType.contains(OP_COPY_ORDER_CONFIRM)) {
            mutateNode(response, false);
            io.github.lazyimmortal.sesame.util.Log.i(TAG, "force order confirm reserve: " + operationType);
        }
    }

    private static void mutateNode(Object node, boolean detail) {
        if (node == null) {
            return;
        }
        if (node instanceof Map) {
            Map<?, ?> nodeMap = (Map<?, ?>) node;
            mutateMap(nodeMap, detail);
            ArrayList<Object> values = new ArrayList<>(((Map<?, ?>) node).values());
            for (Object value : values) {
                mutateNode(value, detail);
            }
            return;
        }
        if (node instanceof Collection) {
            ArrayList<Object> values = new ArrayList<>((Collection<?>) node);
            for (Object value : values) {
                mutateNode(value, detail);
            }
            return;
        }
        if (node.getClass().isArray()) {
            int length = Array.getLength(node);
            for (int i = 0; i < length; i++) {
                mutateNode(Array.get(node, i), detail);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void mutateMap(Map<?, ?> nodeMap, boolean detail) {
        if (!(nodeMap instanceof Map)) {
            return;
        }
        Map<Object, Object> map = (Map<Object, Object>) nodeMap;
        if (detail) {
            if (!map.containsKey("benefitId")
                    && !map.containsKey("exchangeStartDt")
                    && !map.containsKey("exchangeEndDt")
                    && !map.containsKey("nextExchangeStartDt")
                    && !map.containsKey("notSupportExchangeReason")) {
                return;
            }
            long now = System.currentTimeMillis();
            put(map, "exchangeable", Boolean.TRUE);
            put(map, "exchangeStartDt", now - 60_000L);
            put(map, "exchangeEndDt", Math.max(getLong(map.get("exchangeEndDt")), now + EXCHANGE_WINDOW_MILLIS));
            put(map, "nextExchangeStartDt", 0L);
            put(map, "reserve", Math.max(1, getInt(map.get("reserve"))));
            put(map, "notSupportExchangeReason", null);
            put(map, "sellOutNoticeMessage", "");
            put(map, "usable", Boolean.TRUE);
        } else if (map.containsKey("reserve") || map.containsKey("benefitId")) {
            put(map, "reserve", Math.max(1, getInt(map.get("reserve"))));
            put(map, "exchangeable", Boolean.TRUE);
            put(map, "notSupportExchangeReason", null);
            put(map, "sellOutNoticeMessage", "");
        }
    }

    private static void put(Map<Object, Object> map, String key, Object value) {
        try {
            map.put(key, value);
        } catch (Throwable ignored) {
        }
    }

    private static int getInt(Object value) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static long getLong(Object value) {
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return Long.parseLong(String.valueOf(value));
        } catch (Throwable ignored) {
            return 0L;
        }
    }
}
