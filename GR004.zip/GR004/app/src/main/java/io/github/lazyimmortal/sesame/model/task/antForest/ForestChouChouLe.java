package io.github.lazyimmortal.sesame.model.task.antForest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import io.github.lazyimmortal.sesame.hook.Toast;
import io.github.lazyimmortal.sesame.util.Log;
import io.github.lazyimmortal.sesame.util.MessageUtil;
import io.github.lazyimmortal.sesame.util.Statistics;
import io.github.lazyimmortal.sesame.util.Status;
import io.github.lazyimmortal.sesame.util.TimeUtil;
import io.github.lazyimmortal.sesame.util.idMap.ForestHuntIdMap;
import io.github.lazyimmortal.sesame.util.idMap.UserIdMap;

public class ForestChouChouLe {

    private static final String TAG = ForestChouChouLe.class.getSimpleName();

    void chouChouLe(Boolean ForestHuntDraw, Boolean ForestHuntHelp, Set<String> shareIds, Boolean NORMALForestHuntHelp, Boolean ACTIVITYForestHuntHelp, Set<String> AntForestHuntTaskList) {
        try {
            ForestHuntIdMap.load();
            // String source = "task_entry";
            // String source = "guide";
            // String source = "forestchouchoule";
            JSONObject resData = new JSONObject(AntForestRpcCall.enterDrawActivityopengreen("", "ANTFOREST_NORMAL_DRAW", "task_entry"));
            if (!MessageUtil.checkSuccess(TAG, resData)) {
                return;
            }
            // 提取drawSceneGroups数组
            JSONArray drawSceneGroups = resData.getJSONArray("drawSceneGroups");
            for (int i = 0; i < drawSceneGroups.length(); i++) {
                JSONObject drawScene = drawSceneGroups.getJSONObject(i);
                JSONObject drawActivity = drawScene.getJSONObject("drawActivity");

                String activityId = drawActivity.getString("activityId");
                String drawScenename = drawActivity.getString("name");
                String sceneCode = drawActivity.getString("sceneCode");

                chouChouLescene(ForestHuntDraw, activityId, drawScenename, sceneCode, ForestHuntHelp, shareIds, NORMALForestHuntHelp, ACTIVITYForestHuntHelp, AntForestHuntTaskList);
            }
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
    }

    void chouChouLescene(Boolean ForestHuntDraw, String activityId, String drawScenename, String sceneCode, Boolean ForestHuntHelp, Set<String> shareIds, Boolean NORMALForestHuntHelp, Boolean ACTIVITYForestHuntHelp, Set<String> AntForestHuntTaskList) {
        String taskUid = UserIdMap.getCurrentUid();
        try {
            boolean doublecheck;
            Set<String> presetBad = new LinkedHashSet<>();
            presetBad.add("FOREST_NORMAL_DRAW_SHARE"); // 邀请好友任务（跳过）
            presetBad.add("FOREST_ACTIVITY_DRAW_SHARE");

            // =====================================================

            int loopCount = 0; // 循环次数计数
            final int MAX_LOOP = 7; // 最大循环次数，避免死循环

      /*
      sceneCode
      ANTFOREST_NORMAL_DRAW_TASK
      ANTFOREST_ACTIVITY_DRAW_TASK

      taskType
      FOREST_NORMAL_DRAW_SHARE
      FOREST_ACTIVITY_DRAW_SHARE

      p2pSceneCode
      FOREST_NORMAL_20250829_SHARE
      FOREST_NORMAL_20251024_SHARE
       */
            do {
                doublecheck = false;
                JSONObject listTaskopengreen = new JSONObject(AntForestRpcCall.listTaskopengreen(sceneCode + "_TASK", "task_entry"));
                if (MessageUtil.checkSuccess(TAG, listTaskopengreen)) {
                    JSONArray taskList = listTaskopengreen.getJSONArray("taskInfoList");
                    for (int i = 0; i < taskList.length(); i++) {
                        JSONObject taskInfo = taskList.getJSONObject(i);
                        JSONObject taskBaseInfo = taskInfo.getJSONObject("taskBaseInfo");
                        JSONObject bizInfo = new JSONObject(taskBaseInfo.getString("bizInfo"));
                        String taskName = bizInfo.getString("title");
                        String desc = bizInfo.getString("desc");

                        String taskSceneCode = taskBaseInfo.getString("sceneCode");
                        String taskStatus = taskBaseInfo.getString("taskStatus");
                        String taskType = taskBaseInfo.getString("taskType");

                        JSONObject taskRights = taskInfo.getJSONObject("taskRights");
                        int rightsTimes = taskRights.getInt("rightsTimes");
                        int rightsTimesLimit = taskRights.getInt("rightsTimesLimit");

                        // 已完成任务领取奖励
                        if (taskStatus.equals("FINISHED")) {
                            TimeUtil.sleep(2000);
                            JSONObject sginRes = new JSONObject(AntForestRpcCall.receiveTaskAwardopengreen("task_entry", taskSceneCode, taskType));
                            if (MessageUtil.checkSuccess(TAG, sginRes)) {
                                int incAwardCount = sginRes.getInt("incAwardCount");
                                Log.forest("森林寻宝🎖️[" + taskName + "]获得抽奖*" + incAwardCount);
                                if (rightsTimesLimit - rightsTimes > 0) {
                                    doublecheck = true;
                                }
                            }
                            continue;
                        }

                        //黑名单任务跳过
                        if (AntForestHuntTaskList.contains(taskName)) {
                            continue;
                        }

                        if (taskType.contains("_DRAW_SHARE") && ForestHuntHelp) {
                            // if (!Status.hasFlagToday("Forest::" + sceneCode)) {
                            int forestHuntHelpTodayCount = Status.getforestHuntHelpToday(taskType);
                            if (forestHuntHelpTodayCount < shareIds.size()) {
                                JSONObject prodPlayParam = new JSONObject(taskBaseInfo.getString("prodPlayParam"));
                                String p2pSceneCode = prodPlayParam.getString("p2pSceneCode");
                                Log.forest("森林寻宝🎰️执行[" + drawScenename + "]助力好友[" + UserIdMap.getShowName(UserIdMap.getCurrentUid()) + "]");
                                DoForestHuntHelp(shareIds, activityId, p2pSceneCode, taskType);
                                // Status.flagToday("Forest::" + sceneCode,taskUid);
                            }
                        }
                        // 在最后一个任务时强制开启助力
                        if (i == (taskList.length() - 1)) {
                            if (NORMALForestHuntHelp && sceneCode.equals("ANTFOREST_NORMAL_DRAW")) {
                                int forestHuntHelpTodayCount = Status.getforestHuntHelpToday("FOREST_NORMAL_DRAW_SHARE");
                                if (forestHuntHelpTodayCount < shareIds.size()) {
                                    // if (!Status.hasFlagToday("Forest::" + sceneCode)) {
                                    Log.forest("森林寻宝🎰️执行[普通场景]助力好友[" + UserIdMap.getShowName(UserIdMap.getCurrentUid()) + "](薅羊毛，如果助力结果不返回成功请关闭配置项)");
                                    DoForestHuntHelp(shareIds, activityId, "FOREST_NORMAL_20250829_SHARE", "FOREST_NORMAL_DRAW_SHARE");
                                    // Status.flagToday("Forest::" + sceneCode,taskUid);
                                }
                            }
                            if (ACTIVITYForestHuntHelp && sceneCode.equals("ANTFOREST_ACTIVITY_DRAW")) {
                                int forestHuntHelpTodayCount = Status.getforestHuntHelpToday("FOREST_ACTIVITY_DRAW_SHARE");
                                if (forestHuntHelpTodayCount < shareIds.size()) {
                                    // if (!Status.hasFlagToday("Forest::" + sceneCode)) {
                                    Log.forest("森林寻宝🎰️执行[活动场景]助力好友[" + UserIdMap.getShowName(UserIdMap.getCurrentUid()) + "](薅羊毛，如果助力结果不返回成功请关闭配置项)");
                                    DoForestHuntHelp(shareIds, activityId, "FOREST_NORMAL_20251024_SHARE", "FOREST_ACTIVITY_DRAW_SHARE");
                                    // Status.flagToday("Forest::" + sceneCode,taskUid);
                                }
                            }
                        }
                        // ==================== 活力值兑换任务 =====================
                        if (taskType.equals("NORMAL_DRAW_EXCHANGE_VITALITY") && taskStatus.equals("TODO")) {
                            //先判断活力值是否大于20
                            int totalVitalityAmount = 0;
                            try {
                                JSONObject jo = new JSONObject(AntForestRpcCall.queryVitalityStoreIndex());
                                if (!MessageUtil.checkResultCode(TAG, jo)) {
                                    return;
                                }
                                if (!jo.has("userVitalityInfoVO")) {
                                    return;
                                }
                                JSONObject userVitalityInfo = jo.getJSONObject("userVitalityInfoVO");
                                totalVitalityAmount = userVitalityInfo.optInt("totalVitalityAmount", 0);
                            } catch (Throwable th) {
                                Log.i(TAG, "chouChouLesceneEXCHANGE err:");
                                Log.printStackTrace(TAG, th);
                            }
                            if (totalVitalityAmount < 20) {
                                Log.forest("森林寻宝🧾活力值" + totalVitalityAmount + "不能兑换#[" + UserIdMap.getShowName(UserIdMap.getCurrentUid()) + "]");
                                continue;
                            }
                            //🏆
                            JSONObject sginRes = new JSONObject(AntForestRpcCall.exchangeTimesFromTaskopengreen(activityId, sceneCode, "task_entry", taskSceneCode, taskType));
                            if (MessageUtil.checkSuccess(TAG, sginRes)) {
                                int times = sginRes.getInt("times");
                                Log.forest("森林寻宝🎖️[" + taskName + "]获得抽奖*" + times);
                                doublecheck = true;
                            }
                            continue; // 防止进入下面的 FOREST_NORMAL_DRAW 分支
                        }

                        // 统一处理 FOREST_NORMAL_DRAW 和 FOREST_ACTIVITY_DRAW开头任务
                        if ((taskType.startsWith("FOREST_NORMAL_DRAW") || taskType.startsWith("FOREST_ACTIVITY_DRAW")) && taskStatus.equals("TODO")) {
                            TimeUtil.sleep(1000);
                            // 调用对应完成接口
                            JSONObject result;
                            if (taskType.contains("XLIGHT")) {
                                result = new JSONObject(AntForestRpcCall.finishTask4Chouchoule(taskType, taskSceneCode));
                            } else {
                                result = new JSONObject(AntForestRpcCall.finishTaskopengreen(taskType, taskSceneCode));
                            }
                            //检查并标记黑名单任务
                            MessageUtil.checkResultCodeAndMarkTaskBlackList("AntForestHuntTaskList", taskName, result);
                            if (MessageUtil.checkSuccess(TAG, result)) {
                                Log.forest("森林寻宝🧾完成[" + taskName + "]");
                                doublecheck = true;
                            }
                            continue;
                        }
                        if (taskStatus.equals("TODO")) {
                            //兜底完成任务操作
                            TimeUtil.sleep(1000);
                            JSONObject result = new JSONObject(AntForestRpcCall.finishTaskopengreen(taskType, taskSceneCode));
                            //检查并标记黑名单任务
                            MessageUtil.checkResultCodeAndMarkTaskBlackList("AntForestHuntTaskList", taskName, result);
                            if (MessageUtil.checkSuccess(TAG, result)) {
                                Log.forest("森林寻宝🧾完成[" + taskName + "]");
                                doublecheck = true;
                            }
                        }
                    }
                }
            } while (doublecheck && ++loopCount < MAX_LOOP);

            // ==================== 执行抽奖 ====================
            if (ForestHuntDraw) {
                JSONObject jo = new JSONObject(AntForestRpcCall.enterDrawActivityopengreen(activityId, sceneCode, "task_entry"));
                if (MessageUtil.checkSuccess(TAG, jo)) {
                    JSONObject drawAsset = jo.getJSONObject("drawAsset");
                    int blance = drawAsset.getInt("blance");

                    while (blance > 0) {
                        jo = new JSONObject(AntForestRpcCall.drawopengreen(activityId, sceneCode, "task_entry", UserIdMap.getCurrentUid()));
                        if (MessageUtil.checkSuccess(TAG, jo)) {
                            drawAsset = jo.getJSONObject("drawAsset");
                            blance = drawAsset.getInt("blance");
                            JSONObject prizeVO = jo.getJSONObject("prizeVO");
                            String prizeName = prizeVO.getString("prizeName");
                            int prizeNum = prizeVO.getInt("prizeNum");
                            Log.forest("森林寻宝🎁领取[" + prizeName + "*" + prizeNum + "]" + "#[" + UserIdMap.getShowName(UserIdMap.getCurrentUid()) + "]");
                            Toast.show("森林寻宝🎁领取[" + prizeName + "*" + prizeNum + "]");
                            if (prizeName.contains("g能量")) {
                                Statistics.addData(Statistics.DataType.COLLECTED, prizeNum);
                            }
                        } else {
                            blance--;
                        }
                    }
                }
            }

            // ==============================================

        } catch (Exception e) {
            Log.printStackTrace(e);
        }
    }

    // kuzVe2lrSrXFdacxxi3KWjxx-4O7FEYDgn0xx0OehP5jt9-YINZOkxgPDkvWvkwkQXSDbZ
    // -77VUJcjlcZsjGio6MsAtmwxkxkx(FOREST_NORMAL_DRAW_SHARE)
    // kuzVe2lrSrXFdacxxi3KWjxx-4O7FEYDgn0xx0OehP5jt9-bxgpIW643h4FnWRjs9uZzng
    // -77VUJcjlcZsjGio6MsAtmwxkxkx(FOREST_ACTIVITY_DRAW_SHARE)
    void DoForestHuntHelp(Set<String> shareIds, String activityId, String p2pSceneCode, String taskType) {
        String taskUid = UserIdMap.getCurrentUid();
        try {
            int forestHuntHelpTodayCount;

            for (String shareUserId : shareIds) {
                forestHuntHelpTodayCount = Status.getforestHuntHelpToday(taskType);
                // if (!Status.canForestHuntHelpToday(taskType + "::" + shareUserId)) {
                // 判断当天是否助力过
                if (Status.hasFlagToday(taskType + "::" + shareUserId)) {
                    continue;
                }
                String shareId;
                if ((shareUserId.length() > 20 && shareUserId.length() < 28) && taskType.equals("FOREST_NORMAL_DRAW_SHARE")) {
                    shareId = shareUserId + "4O7FEYDgn0xx0OehP5jt9" + "YINZOkxgPDkvWvkwkQXSDbZ" + "77VUJcjlcZsjGio6MsAtmwxkxkx";
                } else if ((shareUserId.length() > 20 && shareUserId.length() < 28) && taskType.equals("FOREST_ACTIVITY_DRAW_SHARE")) {
                    shareId = shareUserId + "4O7FEYDgn0xx0OehP5jt9" + "bxgpIW643h4FnWRjs9uZzng" + "77VUJcjlcZsjGio6MsAtmwxkxkx";
                } else {
                    Log.forest("森林寻宝🎰️存在错误usershareUserId:" + shareUserId);
                    continue;
                }
                String userId = shareComponentRecall(p2pSceneCode, shareId);
                // Log.forest("森林寻宝🎰️尝试助力#" + ForestHuntIdMap.get(shareUserId));
                if (userId.equals("解析userID失败")) {
                    continue;
                }
                TimeUtil.sleep(1500);
                //能成功返回，但解析不了UID
                if (userId.length() != 16) {
                    continue;
                }
                String resconfirmShareRecall = confirmShareRecall(activityId, p2pSceneCode, shareId, userId);
                TimeUtil.sleep(1500);

                String userName = UserIdMap.getShowName(userId) != null ? UserIdMap.getShowName(userId) : userId;
                Log.forest("森林寻宝👊助力[" + userName + "]" + resconfirmShareRecall);
                // 标记助力成功
                Status.flagToday(taskType + "::" + shareUserId, taskUid);
                // Status.ForestHuntHelpToday(taskType + "::" + shareUserId, taskUid);
                forestHuntHelpTodayCount++;
                // 统计场景助力次数
                Status.forestHuntHelpToday(taskType, forestHuntHelpTodayCount, taskUid);
            }
        } catch (Throwable t) {
            Log.printStackTrace(TAG, t);
        }
    }

    private String shareComponentRecall(String sceneCode, String shareId) {
        try {
            JSONObject jo = new JSONObject(AntForestRpcCall.shareComponentRecall(sceneCode, shareId));
            if (!MessageUtil.checkSuccess(TAG, jo)) {
                return "解析shareID失败";
            }
            if (jo.has("inviterInfoVo")) {
                jo = jo.getJSONObject("inviterInfoVo");
                return jo.getString("userId");
            }
        } catch (Throwable t) {
            Log.i(TAG, "shareComponentRecall err:");
            Log.printStackTrace(TAG, t);
        }
        return "解析userID失败";
    }

    private String confirmShareRecall(String activityId, String p2pSceneCode, String shareId, String userId) {
        try {
            JSONObject jo = new JSONObject(AntForestRpcCall.confirmShareRecall(activityId, p2pSceneCode, shareId, userId));
            return jo.getString("desc");
        } catch (Throwable t) {
            Log.i(TAG, "confirmShareRecall err:");
            Log.printStackTrace(TAG, t);
        }
        return "FALSE end";
    }
}

/*我的图标
1. Unicode Emojis 小图标 (可直接复制使用的)
  1.0.1 杂项符号和象形文字
  🌀🌁🌂🌃🌄🌅🌆🌇🌈🌉🌊🌋🌌🌍🌎🌏🌐🌑🌒🌓🌔🌕
          🌖🌗🌘🌙🌚🌛🌜🌝🌞🌟🌠🌡🌢🌣🌤🌥🌦🌧🌨🌩🌪🌫🌬
          🌭🌮🌯🌰🌱🌲🌳🌴🌵🌶🌷🌸🌹🌺🌻🌼🌽🌾🌿🍀🍁
          🍂🍃🍄🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🍒🍓🍔🍕🍖
          🍗🍘🍙🍚🍛🍜🍝🍞🍟🍠🍡🍢🍣🍤🍥🍦🍧🍨🍩🍪🍫
          🍬🍭🍮🍯🍰🍱🍲🍳🍴🍵🍶🍷🍸🍹🍺🍻🍼🍽🍾🍿
          🎀🎁🎂🎃🎄🎅🎆🎇🎈🎉🎊🎋🎌🎍🎎🎏🎐🎑
          🎒🎓🎠🎡🎢🎣🎤🎥🎦🎧🎨🎩🎪🎫🎬🎭🎮🎯🎰🎱
          🎲🎳🎴🎵🎶🎷🎸🎹🎺🎻🎼🎽🎾🎿🏀🏁🏂🏃🏄🏅
          🏆🏇🏈🏉🏊🏋🏌🏍🏎🏏🏐🏑🏒🏓🏔🏕🏖🏗🏘🏙
          🏚🏛🏜🏝🏞🏟🏠🏡🏢🏣🏤🏥🏦🏧🏨🏩🏪🏫🏬🏭🏮
          🏯🏰🏱🏲🏳🏴🏵🏶🏷🏸🏹🏺🏻🏼🏽🏾🏿🐀🐁🐂🐃🐄🐅
          🐆🐇🐈🐉🐊🐋🐌🐍🐎🐏🐐🐑🐒🐓🐔🐕🐖🐗🐘🐙
          🐚🐛🐜🐝🐞🐟🐠🐡🐢🐣🐤🐥🐦🐧🐨🐩🐪🐫🐬🐭
          🐮🐯🐰🐱🐲🐳🐴🐵🐶🐷🐸🐹🐺🐻🐼🐽🐾🐿👀👁
          👂👃👄👅👆👇👈👉👊👋👌👍👎👏👐👑👒👓👔👕
          👖👗👘👙👚👛👜👝👞👟👠👡👢👣👤👥👦👧👨👩
          👪👫👬👭👮👯👰👱👲👳👴👵👶👷👸👹👺👻👼👽👾
          👿💀💁💂💃💄💅💆💇💈💉💊💋💌💍💎💏💐💑💒
          💓💔💕💖💗💘💙💚💛💜💝💞💟💠💡💢💣💤
          💥💦💧💨💩💪💫💬💭💮💯💰💱💲💳💴💵💶💷
          💸💹💺💻💼💽💾💿📀📁📂📃📄📅📆📇📈📉📊📋
          📌📍📎📏📐📑📒📓📔📕📖📗📘📙📚📛📜📝
          📞📟📠📡📢📣📤📥📦📧📨📩📪📫📬📭📮📯📰📱
          📲📳📴📵📶📷📸📹📺📻📼📽📾📿🔀🔁🔂🔃🔄🔅
          🔆🔇🔈🔉🔊🔋🔌🔍🔎🔏🔐🔑🔒🔓🔔🔕🔖
          🔗🔘🔙🔚🔛🔜🔝🔞🔟🔠🔡🔢🔣🔤🔥🔦🔧🔨🔩
          🔪🔫🔬🔭🔮🔯🔰🔱🔲🔳🔴🔵🔶🔷🔸🔹🔺🔻🔼🔽
          🕋🕌🕍🕎
          🕐🕑🕒🕓🕔🕕🕖🕗🕘🕙🕚🕛🕜🕝🕞🕟🕠🕡🕢🕣🕤🕥🕦🕧
          🕴🕵🕶🕷🕸🕹🕺🖐🖕🖖🖤🖥🖨🖱🖲🖼🗂🗃🗑🗒🗓🗜🗝🗞🗡🗣🗨🗯🗳🗺🗻🗼🗽🗾🗿
          ✖💲‼☑️⚪️🏁💱
          1.0.2 几何图形拓展
  🞀🞁🞂🞃🞄🞅🞇🞉🞌🞍🞑🞒🞓🞔🞕🞖🞗🞘🞚🞛🞜🞝🞞🞠🞡🞢🞣🞤🞥🞦🞧🞨🞩🞪🞫🞬🞭🞮✔✅☑︎
          🞯🞰🞱🞲🞳🞴🞵🞶🞷🞸🞹🞺🞻🞼🞽🞾🞿🟀🟂🟃🟄🟆🟇🟈🟉🟊🟌🟍🟎🟐🟒🟔🟘
          🟠🟡🟢🟣🟤🟥🟦🟧🟨🟩🟪🟫
          1.0.3 扑克牌
  🂠🂡🂢🂣🂤🂥🂦🂧🂨🂩🂪🂫🂬🂭🂮🂱🂲🂳🂴🂵🂶🂷🂸🂹🂺🂻🂼🂽🂾🂿
          🃁🃂🃃🃄🃅🃆🃇🃈🃉🃊🃋🃌🃍🃎🃏🃑🃒🃓🃔🃕🃖🃗🃘🃙🃚🃛🃜🃝🃞🃟
          🃠🃡🃢🃣🃤🃥🃦🃧🃨🃩🃪🃫🃬🃭🃮🃯🃰🃱🃲🃳🃴🃵
          1.0.4 麻将牌
  🀀🀁🀂🀃🀄🀅🀆🀇🀈🀉🀊🀋🀌🀍🀎🀏🀐🀑🀒🀓🀔🀕🀖🀗🀘
          🀙🀚🀛🀜🀝🀞🀟🀠🀡🀢🀣🀤🀥🀦🀧🀨🀩🀪🀫
          1.0.5 多米诺骨牌
  🀰🀱🀲🀳🀴🀵🀶🀷🀸🀹🀺🀻🀼🀽🀾🀿🁀🁁🁂🁃🁄🁅🁆🁇🁈🁉🁊
          🁋🁌🁍🁎🁏🁐🁑🁒🁓🁔🁕🁖🁗🁘🁙🁚🁛🁜🁝🁞🁟🁠🁡
          🁢🁣🁤🁥🁦🁧🁨🁩🁪🁫🁬🁭🁮🁯🁰🁱🁲🁳🁴🁵🁶🁷🁸🁹🁺
          🁻🁼🁽🁾🁿🂀🂁🂂🂃🂄🂅🂆🂇🂈🂉🂊🂋🂌🂍🂎🂏🂐🂑🂒🂓
          1. 1 表情
  🤗🤫🤣🙃🙂🥰🤩🤪🤑🤭🤔
          🤐🤬🥱😩🥺🧐🤓😎🤠🥳😵‍💫
          🤯🤧😷🤒🤕🤢🤮🥵🥶🥴🤤
          🤥🤨🤖🤡💩
  非礼勿视 🙈
  非礼勿听 🙉
  非礼勿言 🙊
          😀😁😂😃😄😅😆😉😊😋😎😍😘😗😙😚☺😇😐😑😶😏😣
          😥😮😯😪😫😴😌😛😜😝😒😓😔😕😲😷😖😞😟😤😢😭😦
          😧😨😬😰😱😳😵😡😠
          1.1.1 情感
  💋💯💢💥💫💦💨🕳💬👁️‍🗨️🗨🗯💭💤
          1. 2 人物
  👦👧👨👩👴👵👶👱👮👲👳👷👸💂🎅👰👼💆💇🙍🙎🙅🙆💁🙋🙇
          🙌🙏👤👥🚶🏃👯💃👫👬👭💏💑👪
          1.2.1 肤色+发型+性别
  👴👴🏻👴🏼👴🏽👴🏾👴🏿
          💇🦰🦱🦳🦲
          🧑👨👩👫
          1.3 手势
  💪👈👉☝👆👇✌✋👌👍👎✊👊👋👏👐✍
          1.4 日常
  👣👀👂👃👅👄💋👓👔👕👖👗👘👙👚👛👜👝🎒💼👞👟👠👡👢👑
          👒🎩🎓💄💅💍🌂
          1.5 手机
  📱📲📶📳📴☎📞📟📠
          1.5.1 视频标志
  🐊😭⏏️⏏️🔀🔁🔂▶⏩⏭⏯◀⏪⏮
          🔼⏫🔽⏬⏸⏹⏺⏏🎦🔅🔆📶📳📴
          1.6 公共/社会
  ♻🏧🚮🚰♿🚹🚺🚻🚼🚾⚠🚸⛔🚫🚳🚭🚯🚱🚷🔞💈
          1.7 动物
  🙈🙉🙊🐵🐒🐶🐕🐩🐺🐱😺😸😹😻😼😽🙀😿😾🐈
          🐯🐅🐆🐴🐎🐮🐂🐃🐄🐷🐖🐗🐽🐏🐑🐐🐪🐫🐘
          🐭🐁🐀🐹🐰🐇🐻🐨🐼🐾🐔🐓🐣🐤🐥🐦🐧🐸
          🐊🐢🐍🐲🐉🐳🐋🐬🐟🐠🐡🐙🐚🐌🐛🐜🐝🐞🦋

          1.8 植物
  💐🌸💮🌹🌺🌻🌼🌷🌱🌲🌳🌴🌵🌾🌿🍀🍁🍂🍃
          1.9 自然
  🌍🌎🌏🌐🌑🌒🌓🌔🌕🌖🌗🌘🌙🌚🌛🌜
          ☀🌝🌞⭐🌟🌠☁⛅☔⚡❄🔥💧🌊
          1.10 饮食
  🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🍒🍓🍅🍆🌽🍄🌰🍞
          🍖🍗🍔🍟🍕🍳🍲🍱🍘🍙🍚🍛🍜🍝🍠🍢🍣🍤🍥🍡
          🍦🍧🍨🍩🍪🎂🍰🍫🍬🍭🍮🍯🍼☕🍵🍶🍷🍸🍹🍺🍻🍴
          1.11 文体
  🎪🎭🎨🎰🚣🛀🎫🏆⚽⚾🏀🏈🏉🎾🎱🎳⛳🎣🎽🎿
          🏂🏄🏇🏊🚴🚵🎯🎮🎲🎷🎸🎺🎻🎬
          1.12 恐怖
  😈👿👹👺💀☠👻👽👾💣
          1.13 旅游
  🌋🗻🏠🏡🏢🏣🏤🏥🏦🏨🏩🏪🏫🏬🏭🏯🏰💒🗼🗽⛪⛲
          🌁🌃🌆🌇🌉🌌🎠🎡🎢🚂🚃🚄🚅🚆🚇🚈🚉🚊🚝🚞🚋🚌
          🚍🚎🚏🚐🚑🚒🚓🚔🚕🚖🚗🚘🚚🚛🚜🚲⛽🚨🚥🚦🚧⚓⛵
          🚤🚢✈💺🚁🚟🚠🚡🚀🎑🗿🛂🛃🛄🛅
          1.14 物品
  💌💎🔪💈🚪🚽🚿🛁⌛⏳⌚⏰🎈🎉🎊🎎🎏🎐🎀🎁📯📻📱📲
          ☎📞📟📠🔋🔌💻💽💾💿📀🎥📺📷📹📼🔍🔎🔬🔭📡💡🔦
          🏮📔📕📖📗📘📙📚📓📃📜📄📰📑🔖💰💴💵💶💷💸💳✉📧
          📨📩📤📥📦📫📪📬📭📮✏✒📝📁📂📅📆📇📈📉📊📋📌
          📍📎📏📐✂🔒🔓🔏🔐🔑🔨🔫🔧🔩🔗💉💊🚬🔮🚩🎌💦💨
          1.15 标识/标志
  ♠♥♦♣🀄🎴🔇🔈🔉🔊📢📣💤💢💬💭♨🌀🔔🔕✡✝🔯📛🔰🔱⭕
          ✅☑✔✖❌❎➕➖➗➰➿〽✳✴❇‼⁉❓❔❕❗©®™🎦🔅🔆💯🔠🔡🔢🔣🔤🅰🆎🅱🆑🆒🆓ℹ🆔Ⓜ🆕🆖🅾🆗🅿
          🆘🆙🆚🈁🈂🈷🈶🈯🉐🈹🈚🈲🉑🈸🈴🈳㊗㊙🈺🈵▪▫◻◼◽◾⬛⬜🔶🔷🔸🔹🔺🔻💠🔲🔳⚪⚫🔴🔵
          1.16 生肖
  🐁🐂🐅🐇🐉🐍🐎🐐🐒🐓🐕🐖
          1.17 星座
  ♈♉♊♋♌♍♎♏♐♑♒♓⛎
          1.18 时间/时钟/钟表
  🕛🕧🕐🕜🕑🕝🕒🕞🕓🕟🕔🕠🕕🕡🕖🕢🕗🕣🕘🕤🕙🕥🕚🕦
          ⌛⏳⌚⏰⏱⏲🕰
          1.19 爱心/心形/爱情
  ❤💌💝❤️‍🔥❤️‍🩹
          🧡💛💚💙💜🤎🖤🤍
          💘❤💓💔💕💖💗💙💚💛💜💝💞💟❣
          1.20 花草/植物
  💐🌸💮🌹🌺🌻🌼🌷🌱🌿🍀 🌿🍀🍁🍂🍃
          1.21 月亮
  🌑🌒🌓🌔🌕🌖🌗🌘🌙🌚🌛🌜🌝
          1.22 水果
  🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🍒🍓
          1.23 钱包
  💴💵💶💷💰💸💳
          1.24 交通
  🚂🚃🚄🚅🚆🚇🚈🚉🚊🚝🚞🚋🚌🚍🚎🚏🚐🚑🚒🚓🚔🚕
          🚖🚗🚘🚚🚛🚜🚲⛽🚨🚥🚦🚧⚓⛵🚣🚤🚢✈💺🚁🚟🚠🚡🚀
          1.25 建筑
  🏠🏡🏢🏣🏤🏥🏦🏨🏩🏪🏫🏬🏭🏯🏰💒🗼🗽⛪🌆🌇🌉
          1.26 办公
  📱📲☎📞📟📠🔋🔌💻💽💾💿📀🎥📺📷📹📼🔍🔎🔬🔭📡📔📕
          📖📗📘📙📚📓📃📜📄📰📑🔖💳✉📧📨📩📤📥📦📫📪📬📭📮
          ✏✒📝📁📂📅📆📇📈📉📊📋📌📍📎📏📐✂🔒🔓🔏🔐🔑
          1.27 箭头/方向
  ⬆↗➡↘⬇↙⬅↖↕↔↩↪⤴⤵🔃🔄🔙🔚🔛🔜🔝
          2. Unicode 非 Emojis (可直接复制使用的)
  2.0 装饰符号
  ✀✁✂✃✄✅✆✇✈✉✊✋✌✍✎✏✐✑✒✓✔✕✖✗✘
          ✙✚✛✜✝✞✟✠✡✢✣✤✥✦✧✨✩✪✫✬✭✮✯✰
          ✱✲✳✴✵✶✷✸✹✺✻✼✽✾✿❀❁❂❃❄❅❆❇❈❉❊❋
          ❌❍❎❏❐❑❒❓❔❕❖❗❘❙❚❛❜❝❞❟❠❡❢❣❤❥❦❧❨❩❪❫❬❭❮❯❰❱❲❳❴❵❶❷❸❹❺❻❼❽❾❿➀➁➂➃➄➅➆➇➈➉➊➋➌➍➎➏➐➑➒➓➔
          ➕➖➗➘➙➚➛➜➝➞➟➠➡➢➣➤➥➦➧➨➩➪➫➬➭➮➯
          ➰➱➲➳➴➵➶➷➸➹➺➻➼➽➾➿
          2.1 特殊符号
  ♠♣♧♡♥❤❥❣♂♀✲☀☼☾☽◐◑☺☻☎☏✿❀№↑↓←→
          √×÷★℃℉°◆◇⊙■□△▽¿½☯✡㍿卍卐♂♀✚〓㎡♪♫♩♬
          ㊚㊛囍㊒㊖Φ♀♂‖$@*&#※卍卐Ψ♫♬♭♩♪♯♮⌒¶∮‖€￡¥$
  2.2 编号序号
  ①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳⓪
          ❶❷❸❹❺❻❼❽❾❿⓫⓬⓭⓮⓯⓰⓱⓲⓳⓴
          ㊀㊁㊂㊃㊄㊅㊆㊇㊈㊉㈠㈡㈢㈣㈤㈥㈦㈧㈨㈩
          ⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽⑾⑿⒀⒁⒂⒃⒄⒅⒆⒇
          ⒈⒉⒊⒋⒌⒍⒎⒏⒐⒑⒒⒓⒔⒕⒖⒗⒘⒙⒚⒛
  ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫⅰⅱⅲⅳⅴⅵⅶⅷⅸⅹ
  ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ
          ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ
          ⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵
          2.3 数学符号
  ﹢﹣×÷±/=≌∽≦≧≒﹤﹥≈≡≠=≤≥<>≮≯∷∶∫∮∝∞∧∨∑∏∪∩∈∵∴
          ⊥∥∠⌒⊙√∟⊿㏒㏑%‰
          ⅟½⅓⅕⅙⅛⅔⅖⅚⅜¾⅗⅝⅞⅘
          ≂≃≄≅≆≇≈≉≊≋≌≍≎≏
          ≐≑≒≓≔≕≖≗≘≙≚≛≜≝≞≟≠≡≢≣≤≥≦≧≨≩⊰⊱
          ⋛⋚∫∬∭∮∯∰∱∲∳%℅‰‱øØπ

  2.4 爱心符号

  ♥❣ღ♠♡♤❤❥

          2.5 标点符号

  。，、＇：∶；?‘’“”〝〞ˆˇ﹕︰﹔﹖﹑•¨….¸;！´？！
          ～—ˉ｜‖＂〃｀@﹫¡¿﹏﹋﹌︴々﹟#﹩$﹠&﹪%
          *﹡﹢﹦﹤‐￣¯―﹨ˆ˜﹍﹎+=<＿ *-\ˇ~﹉﹊（）〈〉
          ‹›﹛﹜『』〖〗［］《》〔〕{}「」【】︵︷︿︹︽*
          ﹁﹃︻︶︸﹀︺︾ˉ﹂﹄︼❝❞

          2.6 单位符号

  °′″＄￥〒￠￡％＠℃℉﹩﹪‰﹫
          ㎡㏕㎜㎝㎞㏎m³㎎㎏㏄º○¤%$º¹²³

          2.7 货币符号

          €£Ұ₴$₰¢₤¥₳₲₪₵元₣₱฿¤₡₮₭₩
  ރ円₢₥₫₦zł﷼₠₧₯₨Kčर₹ƒ₸￠

  2.8 箭头符号

  ↑↓←→↖↗↘↙↔↕➻➼➽➸➳➺➻➴➵➶➷➹▶►▷◁◀◄
          «»➩➪➫➬➭➮➯➱⏎➲➾➔➘➙➚➛➜➝➞➟➠➡➢➣
          ➤➥➦➧➨↚↛↜↝↞↟↠↠↡↢↣↤↤↥↦↧↨
          ⇄⇅⇆⇇⇈⇉⇊⇋⇌⇍⇎⇏⇐⇑⇒⇓⇔⇖⇗⇘⇙⇜↩↪↫↬↭↮
          ↯↰↱↲↳↴↵↶↷↸↹☇☈↼↽↾↿⇀⇁⇂⇃⇞⇟⇠⇡⇢⇣⇤⇥⇦⇧⇨⇩⇪↺↻⇚⇛♐

          2.9 符号图案

  ✐✎✏✑✒✍✉✁✂✃✄✆✉☎☏☑✓✔√☐☒✗✘ㄨ✕✖✖
          ☢☠☣✈★☆✡囍㍿☯☰☲☱☴☵☶☳☷☜☞☝✍☚☛☟✌
          ♤♧♡♢♠♣♥♦☀☁☂❄☃♨웃유❖☽☾☪✿♂♀✪✯☭➳卍卐√×■◆●○
          ◐◑✙☺☻❀⚘♔♕♖♗♘♙♚♛♜♝♞♟♧♡♂♀♠♣♥❤☜☞☎☏⊙◎☺☻☼
          ▧▨♨◐◑↔↕▪▒◊◦▣▤▥▦▩◘◈◇♬♪♩♭♪の★☆→あぃ￡Ю〓§♤♥▶¤✲❈
          ✿✲❈➹☀☂☁【】┱┲❣✚✪✣✤✥✦❉❥❦❧❃❂❁❀✄☪☣☢☠☭ღ
  ▶▷◀◁☀☁☂☃☄★☆☇☈⊙☊☋☌☍ⓛⓞⓥⓔ╬『』∴☀♫♬♩♭♪☆∷﹌の
  ★◎▶☺☻►◄▧▨♨◐◑↔↕↘▀▄█▌
          ◦☼♪の☆→♧ぃ￡❤▒▬♦◊◦♠♣▣
          ۰•❤•۰►◄▧▨♨◐◑↔↕▪▫☼♦⊙●○①⊕◎Θ⊙¤㊣★☆♀◆◇◣◢◥▲▼△▽⊿
          ◤◥✐✌✍✡✓✔✕✖♂♀♥♡☜☞☎☏⊙◎☺☻►◄▧▨♨◐◑↔↕♥♡▪▫☼♦▀▄█▌
          ▐░▒▬♦◊◘◙◦☼♠♣▣▤▥▦▩◘◙◈♫♬♪♩♭♪✄☪
          ☣☢☠♯♩♪♫♬♭♮☎☏☪♈ºº₪¤큐«»™♂✿♥ ◕‿-｡ ｡◕‿◕｡

          2.10 希腊字母

          ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨ
  Ωαβγδεζνξοπρσηθικλμτυφχψω

  2.11 俄语字母

          АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩ
  ЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя

  2.12 汉语拼音

  āáǎàōóǒòēéěèīíǐìūúǔùǖǘǚǜüêɑńňɡ
          ㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔㄕㄖㄗㄘㄙ
  ㄚㄛㄜㄝㄞㄟㄠㄡㄢㄣㄤㄥㄦㄧㄨㄩ

  2.13 中文字符

          零壹贰叁肆伍陆柒捌玖拾佰仟万亿吉太拍艾分厘毫微
  卍卐卄巜弍弎弐朤氺曱甴囍兀々〆のぁ〡〢〣〤〥〦〧〨〩
  ㊎㊍㊌㊋㊏㊚㊛㊐㊊㊣㊤㊥㊦㊧㊨㊒㊫㊑㊓㊔㊕㊖
          ㊗㊘㊜㊝㊞㊟㊠㊡㊢㊩㊪㊬㊭㊮㊯㊰
          ㊀㊁㊂㊃㊄㊅㊆㊇㊈㊉

          2.14 日文平假名片假名

          ぁあぃいぅうぇえぉおかがきぎくぐけげこごさざしじすずせぜそぞただ
  ちぢっつづてでとどなにぬねのはばぱひびぴふぶぷへべぺほぼぽまみむめも
          ゃやゅゆょよらりるれろゎわゐゑをんゔゕゖァアィイゥウェエォオカガキギ
  クグケゲコゴサザシジスズセゼソゾタダチヂッツヅテデトドナニヌネノハバパ
          ヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロヮワヰヱヲンヴ
  ヵヶヷヸヹヺ・ーヽヾヿ゠ㇰㇱㇲㇳㇴㇵㇶㇷㇸㇹㇺㇻㇼㇽㇾㇿ

  2.15 制表符

  ─ ━│┃╌╍╎╏┄ ┅┆┇┈ ┉┊┋┌┍┎┏┐┑┒┓└ ┕┖┗ ┘┙┚┛├┝┞┟┠┡┢┣ ┤┥┦
          ┧┨┩┪┫┬ ┭ ┮ ┯ ┰ ┱ ┲ ┳ ┴ ┵ ┶ ┷ ┸ ┹ ┺ ┻┼ ┽ ┾ ┿ ╀ ╁ ╂ ╃ ╄ ╅ ╆ ╇ ╈ ╉ ╊
          ╋ ╪ ╫ ╬═║╒╓╔ ╕╖╗╘╙╚ ╛╜╝╞╟╠ ╡╢╣╤ ╥ ╦ ╧ ╨ ╩ ╳╔ ╗╝╚ ╬ ═
          ╓ ╩ ┠ ┨┯ ┷┏ ┓┗ ┛┳ ⊥ ﹃ ﹄┌ ╮ ╭ ╯╰

          2.16 皇冠符号

  ♚ ♛ ♝ ♞ ♜ ♟ ♔ ♕ ♗ ♘ ♖ ♟

          2.17 一些特殊字符

  ♥ ღ ❣ **❁** ❀ ✿҉ ❥ ♤ ♠ ♣ ✿ এ ✿ ♡ ༺๑๑༻  ✨ ⚡☔ ⛄
          ? დ ✿ ♔ ♕ ♚ ♛ ✫ ❤ ☯ ❧ ?ஐ ﻬ ღ ❆ ❁ ☇ ☈ ₪₪  ส็็็็็็ ਊ ﻬﻬ શ
   ♚♛♔♕ ೯ ೮ ೭ ೬ ೫ ೪ ೩ ೨ ೧ ೦
  ೡ ೠ ೞ ೖ ೕ ್ ೌ ೋ ೊ ೈ ೇ ೆ ೄ
          ೃ ೂ ು ೀ ಿ ಾ ಹ ಸ ಷ ಶ ವ ಳ ಲ ಱ ರ ಯಮ
  ಭ ಬ ಫ ಪ ನ ಧ ದ ಥ ತ ಣ ಢ ಡ ಠ
  ಟ ಞ ಝ ಜ ಛ ಚ ಙ ಘ ಗ ಖ ಕ ಔ ಓ ಒ ಐ ಏ ಎ
  ಌ ಋ ಊ ಉ ಈ ಇ ಆ ಅಃ ಂ ͜❀҉ এ ృ
  ʚΐɞ ʚɞ ﻬ ๑ ๓͜✿҉ ͜梁ღ҉ ℘ ೄ ζั͡ ต ԅ️ ✾ ೄ೨❀҉ এ
   ృ ʚΐɞ ʚɞ ﻬ ๑ ๓͜✿҉ ͜ღ҉ ℘ ೄ ζั͡ ต ԅ️ ✾
          ೄϿ҉ ✿ ೃ ✿҉͜ ✿ ζั͡✿ ℳღ

  2.18 其它符号和箭头

  ⬀⬁⬂⬃⬄⬅⬆⬇⬈⬉⬊⬋⬌⬍⬎⬏⬐⬑⬒⬓⬔⬕⬖⬗⬘⬙⬚⬛⬜
          ⬝⬞⬟⬠⬡⬢⬣⬤⬥⬦⬧⬨⬩⬪⬫⬬⬭⬮⬯⬰⬱⬲⬳⬴⬵⬶⬷⬸
          ⬹⬺⬻⬼⬽⬾⬿⭀⭁⭂⭃⭄⭅⭆⭇⭈⭉⭊⭋⭌⭍⭎⭏⭐⭑⭒⭓⭔
          ⭕⭖⭗⭘⭙⭚⭛⭜⭝⭞⭟⭠⭡⭢⭣⭤⭥⭦⭧⭨⭩⭪⭫⭬⭭⭮⭯⭰⭱⭲⭳⭶⭷
          ⭸⭹⭺⭻⭼⭽⭾⭿⮀⮁⮂⮃⮄⮅⮆⮇⮈⮉⮊⮋⮌⮍⮎⮏⮐⮑⮒⮓⮔
          ⮕⮘⮙⮚⮛⮜⮝⮞⮟⮠⮡⮢⮣⮤⮥⮦⮧⮨⮩⮪⮫⮬⮭⮮⮯⮰⮱⮲⮳⮴⮵⮶⮷
          ⮸⮹⮺⮻⮼⮽⮾⮿⯀⯁⯂⯃⯄⯅⯆⯇⯈⯉⯊⯋⯌⯍⯎⯏⯐⯬⯭⯮⯯

          2.19 数学运算符

  ∀∁∂∃∄∅∆∇∈∉∊∋∌∍∎∏∐∑−∓∔∕∖∗∘∙√∛∜∝∞∟∠∡∢∣∤∥∦∧∨
          ∩∪∫∬∭∮∯∰∱∲∳∴∵∶∷∸∹∺∻∼∽∾∿≀≁≂≃≄≅≆≇
          ≈≉≊≋≌≍≎≏≐≑≒≓≔≕≖≗≘≙≚≛≜≝≞≟≠≡≢≣≤≥≦≧≨≩
          ≪≫≬≭≮≯≰≱≲≳≴≵≶≷≸≹≺≻≼≽≾≿⊀⊁⊂⊃⊄⊅⊆⊇⊈⊉⊊⊋
          ⊌⊍⊎⊏⊐⊑⊒⊓⊔⊕⊖⊗⊘⊙⊚⊛⊜⊝⊞⊟⊠⊡⊢⊣⊤⊥⊦⊧⊨⊩
          ⊪⊫⊬⊭⊮⊯⊰⊱⊲⊳⊴⊵⊶⊷⊸⊹⊺⊻⊼⊽⊾⊿⋀⋁⋂⋃⋄⋅⋆⋇⋈⋉⋊⋋⋌
          ⋍⋎⋏⋐⋑⋒⋓⋔⋕⋖⋗⋘⋙⋚⋛⋜⋝⋞⋟⋠⋡⋢⋣⋤⋥⋦⋧⋨⋩⋪⋫⋬⋭
          ⋮⋯⋰⋱⋲⋳⋴⋵⋶⋷⋸⋹⋺⋻⋼⋽⋾⋿

          2.20 带圈字母数字补充

  🄀🄁🄂🄃🄄🄅🄆🄇🄈🄉🄊🄋🄌
          🄐🄑🄒🄓🄔🄕🄖🄗🄘🄙🄚🄛🄜🄝🄞🄟🄠🄡🄢🄣🄤🄥🄦🄧🄨🄩
          🄪🄫🄬🄭🄮🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉🅊🅋🅌🅍🅎🅏
          🅐🅑🅒🅓🅔🅕🅖🅗🅘🅙🅚🅛🅜🅝🅞🅟🅠🅡🅢🅣🅤🅥🅦🅧🅨🅩
          🅰🅱🅲🅳🅴🅵🅶🅷🅸🅹🅺🅻🅼🅽🅾🅿🆀🆁🆂🆃🆄🆅🆆🆇🆈🆉
          🆊🆋🆌🆍🆎🆏🆐🆑🆒🆓🆔🆕🆖🆗🆘🆙
          🇦🇧🇨🇩🇪🇫🇬🇭🇮🇯🇰🇱🇲🇳🇴🇵🇶🇷🇸🇹🇺🇻🇼🇽🇾🇿

          2.21 一般标点符号
    ​‌‍‎‏‐‑‒–—―‖‗‘’‚‛“”„‟†‡•‣․‥…‧  ‪‫‬‭‮ ‰‱′″‴‵‶‷‸‹›※‼‽
            ‾‿⁀⁁⁂⁃⁄⁅⁆⁇⁈⁉⁊⁋⁌⁍⁎⁏⁐⁑
          ⁒⁓⁔⁕⁖⁗⁘⁙⁚⁛⁜⁝⁞ ⁠⁡⁢⁣⁤⁦⁧⁨⁩⁪⁫⁬⁭⁮⁯
          2.22 方框绘制字符
  ─━│┃┄┅┆┇┈┉┊┋┌┍┎┏┐┑┒┓└┕┖┗┘┙┚┛├┝┞┟┠┡┢┣┤┥┦┧┨┩┪┫
          ┬┭┮┯┰┱┲┳┴┵┶┷┸┹┺┻┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋╌╍╎╏═║╒╓╔╕╖╗
          ╘╙╚╛╜╝╞╟╠╡╢╣╤╥╦╧╨╩╪╫╬╭╮╯╰╱╲╳╴╵╶╷╸╹╺╻╼╽╾╿
          2.23 上标和下标
  ⁰ⁱ⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿ ₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₒₓₔₕₖₗₘₙₚₛₜ
  2.24 八思巴字
          ꡀꡁꡂꡃꡄꡅꡆꡇꡈꡉꡊꡋꡌꡍꡎꡏꡐꡑꡒꡓꡔꡕ
  ꡖꡗꡘꡙꡚꡛꡜꡝꡞꡟꡠꡡꡢꡣꡤꡥꡦꡧꡨꡩꡪꡫꡬꡭꡮꡯꡰꡱꡲꡳ꡴꡵꡶꡷
          2.25 埃及圣书体
          𓀀𓀁𓀂𓀃𓀄𓀅𓀆𓀇𓀈𓀉𓀊𓀋𓀌𓀍𓀎𓀏𓀐𓀑𓀒𓀓𓀔𓀕𓀖𓀗𓀘𓀙𓀚𓀛𓀜𓀝𓀞𓀟𓀠𓀡𓀢𓀣𓀤𓀥𓀦𓀧𓀨𓀩𓀪𓀫𓀬
  𓀭𓀮𓀯𓀰𓀱𓀲𓀳𓀴𓀵𓀶𓀷𓀸𓀹𓀺𓀻𓀼𓀽𓀾𓀿𓁀𓁁𓁂𓁃𓁄𓁅𓁆𓁇𓁈𓁉𓁊𓁋𓁌𓁍𓁎𓁏𓁐𓁑𓁒𓁓𓁔𓁕𓁖𓁗𓁘𓁙𓁚𓁛𓁜𓁝𓁞
          𓁟𓁠𓁡𓁢𓁣𓁤𓁥𓁦𓁧𓁨𓁩𓁪𓁫𓁬𓁭𓁮𓁯𓁰𓁱𓁲𓁳𓁴𓁵𓁶𓁷𓁸𓁹𓁺𓁻𓁼𓁽𓁾𓁿𓂀𓂁𓂂𓂃𓂄𓂅𓂆𓂇𓂈𓂉𓂊𓂋𓂌𓂍𓂎𓂏
  𓂐𓂑𓂒𓂓𓂔𓂕𓂖𓂗𓂘𓂙𓂚𓂛𓂜𓂝𓂞𓂟𓂠𓂡𓂢𓂣𓂤𓂥𓂦𓂧𓂨𓂩𓂪𓂫𓂬𓂭𓂮𓂯𓂰𓂱𓂲𓂳𓂴𓂵𓂶𓂷𓂸𓂹
          𓂺𓂻𓂼𓂽𓂾𓂿𓃀𓃁𓃂𓃃𓃄𓃅𓃆𓃇𓃈𓃉𓃊𓃋𓃌𓃍𓃎𓃏𓃐𓃑𓃒𓃓𓃔𓃕𓃖𓃗𓃘𓃙𓃚𓃛𓃜𓃝𓃞𓃟𓃠𓃡𓃢𓃣𓃤
  𓃥𓃦𓃧𓃨𓃩𓃪𓃫𓃬𓃭𓃮𓃯𓃰𓃱𓃲𓃳𓃴𓃵𓃶𓃷𓃸𓃹𓃺𓃻𓃼𓃽𓃾𓃿𓄀𓄁𓄂𓄃𓄄𓄅𓄆𓄇𓄈𓄉𓄊𓄋𓄌𓄍𓄎𓄏
          𓄐𓄑𓄒𓄓𓄔𓄕𓄖𓄗𓄘𓄙𓄚𓄛𓄜𓄝𓄞𓄟𓄠𓄡𓄢𓄣𓄤𓄥𓄦𓄧𓄨𓄩𓄪𓄫𓄬𓄭𓄮𓄯𓄰𓄱𓄲𓄳𓄴𓄵𓄶𓄷𓄸𓄹𓄺𓄻𓄼𓄽𓄾𓄿
  𓅀𓅁𓅂𓅃𓅄𓅅𓅆𓅇𓅈𓅉𓅊𓅋𓅌𓅍𓅎𓅏𓅐𓅑𓅒𓅓𓅔𓅕𓅖𓅗𓅘𓅙𓅚𓅛𓅜𓅝𓅞𓅟𓅠𓅡𓅢𓅣𓅤
          𓅥𓅦𓅧𓅨𓅩𓅪𓅫𓅬𓅭𓅮𓅯𓅰𓅱𓅲𓅳𓅴𓅵𓅶𓅷𓅸𓅹𓅺𓅻𓅼𓅽𓅾𓅿𓆀𓆁𓆂𓆃𓆄𓆅𓆆𓆇𓆈𓆉𓆊𓆋𓆌𓆍𓆎
  𓆏𓆐𓆑𓆒𓆓𓆔𓆕𓆖𓆗𓆘𓆙𓆚𓆛𓆜𓆝𓆞𓆟𓆠𓆡𓆢𓆣𓆤𓆥𓆦𓆧𓆨𓆩𓆪𓆫𓆬𓆭𓆮𓆯𓆰𓆱𓆲𓆳𓆴𓆵𓆶𓆷𓆸𓆹𓆺
          𓆻𓆼𓆽𓆾𓆿𓇀𓇁𓇂𓇃𓇄𓇅𓇆𓇇𓇈𓇉𓇊𓇋𓇌𓇍𓇎𓇏𓇐𓇑𓇒𓇓𓇔𓇕𓇖𓇗𓇘𓇙𓇚𓇛𓇜𓇝𓇞𓇟𓇠𓇡𓇢𓇣𓇤𓇥𓇦𓇧𓇨𓇩𓇪𓇫𓇬𓇭𓇮𓇯𓇰𓇱
  𓇲𓇳𓇴𓇵𓇶𓇷𓇸𓇹𓇺𓇻𓇼𓇽𓇾𓇿𓈀𓈁𓈂𓈃𓈄𓈅𓈆𓈇𓈈𓈉𓈊𓈋𓈌𓈍𓈎𓈏𓈐𓈑𓈒𓈓𓈔𓈕𓈖𓈗𓈘𓈙𓈚𓈛𓈜𓈝𓈞
          𓈟𓈠𓈡𓈢𓈣𓈤𓈥𓈦𓈧𓈨𓈩𓈪𓈫𓈬𓈭𓈮𓈯𓈰𓈱𓈲𓈳𓈴𓈵𓈶𓈷𓈸𓈹𓈺𓈻𓈼𓈽𓈾𓈿𓉀𓉁𓉂𓉃𓉄𓉅𓉆𓉇𓉈𓉉𓉊𓉋𓉌𓉍𓉎𓉏𓉐
  𓉑𓉒𓉓𓉔𓉕𓉖𓉗𓉘𓉙𓉚𓉛𓉜𓉝𓉞𓉟𓉠𓉡𓉢𓉣𓉤𓉥𓉦𓉧𓉨𓉩𓉪𓉫𓉬𓉭𓉮𓉯𓉰𓉱𓉲𓉳𓉴𓉵𓉶𓉷𓉸𓉹𓉺𓉻𓉼𓉽𓉾𓉿𓊀𓊁𓊂𓊃𓊄𓊅𓊆𓊇𓊈𓊉
          𓊊𓊋𓊌𓊍𓊎𓊏𓊐𓊑𓊒𓊓𓊔𓊕𓊖𓊗𓊘𓊙𓊚𓊛𓊜𓊝𓊞𓊟𓊠𓊡𓊢𓊣𓊤𓊥𓊦𓊧𓊨𓊩𓊪𓊫𓊬𓊭𓊮𓊯𓊰𓊱𓊲𓊳𓊴𓊵𓊶𓊷𓊸
  𓊹𓊺𓊻𓊼𓊽𓊾𓊿𓋀𓋁𓋂𓋃𓋄𓋅𓋆𓋇𓋈𓋉𓋊𓋋𓋌𓋍𓋎𓋏𓋐𓋑𓋒𓋓𓋔𓋕𓋖𓋗𓋘𓋙𓋚𓋛𓋜𓋝𓋞𓋟𓋠𓋡𓋢𓋣𓋤𓋥𓋦𓋧𓋨𓋩𓋪𓋫
          𓋬𓋭𓋮𓋯𓋰𓋱𓋲𓋳𓋴𓋵
  𓋶𓋷𓋸𓋹𓋺𓋻𓋼𓋽𓋾𓋿𓌀𓌁𓌂𓌃𓌄𓌅𓌆𓌇𓌈𓌉𓌊𓌋𓌌𓌍𓌎𓌏𓌐𓌑𓌒𓌓𓌔𓌕𓌖𓌗𓌘𓌙𓌚𓌛𓌜𓌝𓌞𓌟𓌠𓌡𓌢𓌣𓌤𓌥𓌦𓌧𓌨𓌩𓌪𓌫
          𓌬𓌭𓌮𓌯𓌰𓌱𓌲𓌳
  𓌴𓌵𓌶𓌷𓌸𓌹𓌺𓌻𓌼𓌽𓌾𓌿𓍀𓍁𓍂𓍃𓍄𓍅𓍆𓍇𓍈𓍉𓍊𓍋𓍌𓍍𓍎𓍏𓍐𓍑𓍒𓍓𓍔𓍕𓍖𓍗𓍘𓍙𓍚𓍛𓍜𓍝𓍞𓍟𓍠𓍡𓍢𓍣𓍤
          𓍥𓍦𓍧𓍨𓍩𓍪𓍫𓍬𓍭𓍮𓍯𓍰𓍱𓍲𓍳𓍴𓍵𓍶𓍷𓍸𓍹𓍺𓍻𓍼𓍽𓍾𓍿𓎀𓎁𓎂𓎃𓎄𓎅𓎆𓎇𓎈𓎉𓎊𓎋𓎌𓎍𓎎
  𓎏𓎐𓎑𓎒𓎓𓎔𓎕𓎖𓎗𓎘𓎙𓎚𓎛𓎜𓎝𓎞
          𓎟𓎠𓎡𓎢𓎣𓎤𓎥𓎦𓎧𓎨𓎩𓎪𓎫𓎬𓎭𓎮𓎯𓎰𓎱𓎲𓎳𓎴𓎵𓎶𓎷𓎸𓎹𓎺𓎻𓎼𓎽𓎾𓎿𓏀𓏁𓏂𓏃𓏄𓏅𓏆𓏇𓏈𓏉𓏊𓏋𓏌𓏍𓏎𓏏𓏐𓏑
  𓏒𓏓𓏔𓏕𓏖𓏗𓏘𓏙𓏚𓏛𓏜𓏝𓏞𓏟𓏠𓏡𓏢𓏣𓏤𓏥𓏦𓏧𓏨𓏩𓏪𓏫𓏬𓏭𓏮𓏯𓏰𓏱𓏲𓏳𓏴𓏵𓏶𓏷𓏸𓏹𓏺𓏻𓏼𓏽𓏾𓏿𓐀𓐁𓐂𓐃𓐄𓐅𓐆𓐇𓐈𓐉𓐊𓐋𓐌𓐍𓐎
          𓐏𓐐𓐑𓐒𓐓𓐔𓐕𓐖𓐗𓐘𓐙𓐚𓐛𓐜𓐝𓐞𓐟𓐠𓐡𓐢𓐣𓐤𓐥𓐦𓐧𓐨𓐩𓐪𓐫𓐬𓐭𓐮
  2.26 带圈表意文字补充
  🈀🈁🈂🈐🈑🈒🈓🈔🈕🈖🈗🈘🈙🈚🈛🈜🈝🈞🈟🈠🈡🈢🈣🈤🈥🈦🈧🈨
          🈩🈪🈫🈬🈭🈮🈯🈰🈱🈲🈳🈴🈵🈶🈷🈸🈹🈺🉐🉑
          2.25 字母连写形式
  ﬀﬁﬂﬃﬄﬅﬆﬓﬔﬕﬖﬗיִﬞײַﬠﬡﬢﬣﬤﬥﬦﬧﬨ﬩שׁשׂשּׁשּׂאַאָאּבּגּדּהּוּזּטּיּךּכּלּמּנּסּףּפּצּקּרּשּתּוֹבֿכֿפֿﭏ
  2.26 中国-八卦-六十四卦
  八卦是中国古老文化的一种深奥概念，是一套用三组阴阳组成的形而上的哲学符号。八卦生自太极,
  太极生两仪、两仪生四象，即四象生八卦, 八卦交互成六十四卦.

  ☰☱☲☳☴☵☶☷

          ䷀䷁䷂䷃䷄䷅䷆䷇
          ䷈䷉䷊䷋䷌䷍䷎䷏
          ䷐䷑䷒䷓䷔䷕䷖䷗
          ䷘䷙䷚䷛䷜䷝䷞䷟
          ䷠䷡䷢䷣䷤䷥䷦䷧
          ䷨䷩䷪䷫䷬䷭䷮䷯
          ䷰䷱䷲䷳䷴䷵䷶䷷
          ䷸䷹䷺䷻䷼䷽䷾䷿

          */
/*分类：😂笑脸和情感✌️人物和身体👩🏻‍🦰肤色和发型🐵动物和自然🍓食物和饮料🚌旅行和地点⚽️活动🔋物品🛑符号🏁旗帜😂笑脸和情感171😄笑脸14😀嘿嘿😁嘻嘻😂笑哭了😃哈
哈😄大笑😅苦笑😆斜眼笑😇微笑天使😉眨眼😊羞涩微笑🙂呵呵🙃倒脸🤣笑得满地打滚🫠融化😍示爱的脸9☺️微笑😍花痴😗亲亲😘飞吻😙微笑亲亲😚羞涩亲亲🤩好崇拜哦🥰喜笑颜开🥲含
泪的笑脸😛吐舌头的脸6😋好吃😛吐舌😜单眼吐舌😝眯眼吐舌🤑发财🤪滑稽🤔带手势的脸7🤔想一想🤗抱抱🤫安静的脸🤭不说🫡致敬🫢睁眼捂嘴🫣偷看🤐无感情和怀疑的脸16😏得意😐冷
漠😑无语😒不高兴😬龇牙咧嘴😮‍💨呼气😶沉默😶‍🌫️迷茫🙂‍↔️左右摇头🙂‍↕️上下点头🙄翻白眼🤐闭嘴🤥说谎🤨挑眉🫥虚线脸🫨颤抖😴困倦的脸6😌松了口气😔沉思😪困
😴睡着了🤤流口水🫩有眼袋🤧生病的脸12😵晕头转向😵‍💫晕😷感冒🤒发烧🤕受伤🤢恶心🤧打喷嚏🤮呕吐🤯爆炸头🥴头昏眼花🥵脸发烧🥶冷脸🤠戴帽子的脸3🤠牛仔帽脸🥳聚会笑脸
🥸伪装的脸😎戴眼镜的脸3😎墨镜笑脸🤓书呆子脸🧐带单片眼镜的脸😞担心的脸27☹️不满😓汗😕困扰😖困惑😞失望😟担心😢哭😣痛苦😥失望但如释重负😦啊😧极度痛苦😨害怕😩累死了
😫累😭放声大哭😮吃惊😯缄默😰冷汗😱吓死了😲震惊😳脸红🙁微微不满🥱打呵欠🥹忍住泪水🥺恳求的脸🫤郁闷🫪变形的脸😠负面情绪的脸8☠️骷髅👿生气的恶魔💀头骨😈恶魔微笑😠生
气😡怒火中烧😤傲慢🤬嘴上有符号的脸💩装扮的脸8👹食人魔👺小妖精👻鬼👽外星人👾外星怪物💩大便🤖机器人🤡小丑脸😸猫咪脸9😸微笑的猫😹笑出眼泪的猫😺大笑的猫😻花痴的猫😼奸
笑的猫😽亲亲猫😾生气的猫😿哭泣的猫🙀疲倦的猫🙈猴子脸3🙈非礼勿视🙉非礼勿听🙊非礼勿言❤️爱心25❣️心叹号❤️红心❤️‍🔥火上之心❤️‍🩹修复受伤的心灵💌情书💓心跳💔心碎💕
两颗心💖闪亮的心💗搏动的心💘心中箭了💙蓝心💚绿心💛黄心💜紫心💝系有缎带的心💞舞动的心💟心型装饰🖤黑心🤍白心🤎棕心🧡橙心🩵浅蓝色的心🩶灰心🩷粉红色的心💋情感15👁️
‍🗨️眼睛对话框💋唇印💢怒💤睡着💥爆炸💦汗滴💨尾气💫头晕💬话语气泡💭内心活动气泡💯一百分🕳️洞🗨️朝左的话语气泡🗯️愤怒话语气泡🫯打斗云团✌️人物和身体2418🖐️手掌
张开66✋举起手✋🏻举起手:较浅肤色✋🏼举起手:中等-浅肤色✋🏽举起手:中等肤色✋🏾举起手:中等-深肤色✋🏿举起手:较深肤色👋挥手👋🏻挥手:较浅肤色👋🏼挥手:中等-浅肤色👋🏽挥
手:中等肤色👋🏾挥手:中等-深肤色👋🏿挥手:较深肤色🖐️手掌🖐🏻手掌:较浅肤色🖐🏼手掌:中等-浅肤色🖐🏽手掌:中等肤色🖐🏾手掌:中等-深肤色🖐🏿手掌:较深肤色🖖瓦肯举手
礼🖖🏻瓦肯举手礼:较浅肤色🖖🏼瓦肯举手礼:中等-浅肤色🖖🏽瓦肯举手礼:中等肤色🖖🏾瓦肯举手礼:中等-深肤色🖖🏿瓦肯举手礼:较深肤色🤚立起的手背🤚🏻立起的手背:较浅肤色🤚🏼
立起的手背:中等-浅肤色🤚🏽立起的手背:中等肤色🤚🏾立起的手背:中等-深肤色🤚🏿立起的手背:较深肤色🫱向右的手🫱🏻向右的手:较浅肤色🫱🏼向右的手:中等-浅肤色🫱🏽向右的手:中
等肤色🫱🏾向右的手:中等-深肤色🫱🏿向右的手:较深肤色🫲向左的手🫲🏻向左的手:较浅肤色🫲🏼向左的手:中等-浅肤色🫲🏽向左的手:中等肤色🫲🏾向左的手:中等-深肤色🫲🏿向左的
手:较深肤色🫳掌心向下的手🫳🏻掌心向下的手:较浅肤色🫳🏼掌心向下的手:中等-浅肤色🫳🏽掌心向下的手:中等肤色🫳🏾掌心向下的手:中等-深肤色🫳🏿掌心向下的手:较深肤色🫴掌心向上的
手🫴🏻掌心向上的手:较浅肤色🫴🏼掌心向上的手:中等-浅肤色🫴🏽掌心向上的手:中等肤色🫴🏾掌心向上的手:中等-深肤色🫴🏿掌心向上的手:较深肤色🫷向左推🫷🏻向左推:较浅肤色🫷
🏼向左推:中等-浅肤色🫷🏽向左推:中等肤色🫷🏾向左推:中等-深肤色🫷🏿向左推:较深肤色🫸向右推🫸🏻向右推:较浅肤色🫸🏼向右推:中等-浅肤色🫸🏽向右推:中等肤色🫸🏾向右推
:中等-深肤色🫸🏿向右推:较深肤色👌手指手势54✌️胜利手势✌🏻胜利手势:较浅肤色✌🏼胜利手势:中等-浅肤色✌🏽胜利手势:中等肤色✌🏾胜利手势:中等-深肤色✌🏿胜利手势:较深肤色👌O
K👌🏻OK:较浅肤色👌🏼OK:中等-浅肤色👌🏽OK:中等肤色👌🏾OK:中等-深肤色👌🏿OK:较深肤色🤌捏手指🤌🏻捏手指:较浅肤色🤌🏼捏手指:中等-浅肤色🤌🏽捏手指:中
等肤色🤌🏾捏手指:中等-深肤色🤌🏿捏手指:较深肤色🤏捏合的手势🤏🏻捏合的手势:较浅肤色🤏🏼捏合的手势:中等-浅肤色🤏🏽捏合的手势:中等肤色🤏🏾捏合的手势:中等-深肤色🤏🏿
捏合的手势:较深肤色🤘摇滚🤘🏻摇滚:较浅肤色🤘🏼摇滚:中等-浅肤色🤘🏽摇滚:中等肤色🤘🏾摇滚:中等-深肤色🤘🏿摇滚:较深肤色🤙给我打电话🤙🏻给我打电话:较浅肤色🤙🏼给我
打电话:中等-浅肤色🤙🏽给我打电话:中等肤色🤙🏾给我打电话:中等-深肤色🤙🏿给我打电话:较深肤色🤞交叉的手指🤞🏻交叉的手指:较浅肤色🤞🏼交叉的手指:中等-浅肤色🤞🏽交叉的手指
:中等肤色🤞🏾交叉的手指:中等-深肤色🤞🏿交叉的手指:较深肤色🤟爱你的手势🤟🏻爱你的手势:较浅肤色🤟🏼爱你的手势:中等-浅肤色🤟🏽爱你的手势:中等肤色🤟🏾爱你的手势:中等-深
肤色🤟🏿爱你的手势:较深肤色🫰食指与拇指交叉的手🫰🏻食指与拇指交叉的手:较浅肤色🫰🏼食指与拇指交叉的手:中等-浅肤色🫰🏽食指与拇指交叉的手:中等肤色🫰🏾食指与拇指交叉的手:中等-
深肤色🫰🏿食指与拇指交叉的手:较深肤色👈指向手势42☝️食指向上指☝🏻食指向上指:较浅肤色☝🏼食指向上指:中等-浅肤色☝🏽食指向上指:中等肤色☝🏾食指向上指:中等-深肤色☝🏿食指向上指
:较深肤色👆反手食指向上指👆🏻反手食指向上指:较浅肤色👆🏼反手食指向上指:中等-浅肤色👆🏽反手食指向上指:中等肤色👆🏾反手食指向上指:中等-深肤色👆🏿反手食指向上指:较深肤色👇
反手食指向下指👇🏻反手食指向下指:较浅肤色👇🏼反手食指向下指:中等-浅肤色👇🏽反手食指向下指:中等肤色👇🏾反手食指向下指:中等-深肤色👇🏿反手食指向下指:较深肤色👈反手食指向左指
👈🏻反手食指向左指:较浅肤色👈🏼反手食指向左指:中等-浅肤色👈🏽反手食指向左指:中等肤色👈🏾反手食指向左指:中等-深肤色👈🏿反手食指向左指:较深肤色👉反手食指向右指👉🏻反手食
指向右指:较浅肤色👉🏼反手食指向右指:中等-浅肤色👉🏽反手食指向右指:中等肤色👉🏾反手食指向右指:中等-深肤色👉🏿反手食指向右指:较深肤色🖕竖中指🖕🏻竖中指:较浅肤色🖕🏼竖中
指:中等-浅肤色🖕🏽竖中指:中等肤色🖕🏾竖中指:中等-深肤色🖕🏿竖中指:较深肤色🫵指向观察者的食指🫵🏻指向观察者的食指:较浅肤色🫵🏼指向观察者的食指:中等-浅肤色🫵🏽指向观察
者的食指:中等肤色🫵🏾指向观察者的食指:中等-深肤色🫵🏿指向观察者的食指:较深肤色👍手掌握紧36✊举起拳头✊🏻举起拳头:较浅肤色✊🏼举起拳头:中等-浅肤色✊🏽举起拳头:中等肤色✊🏾举
起拳头:中等-深肤色✊🏿举起拳头:较深肤色👊出拳👊🏻出拳:较浅肤色👊🏼出拳:中等-浅肤色👊🏽出拳:中等肤色👊🏾出拳:中等-深肤色👊🏿出拳:较深肤色👍拇指向上👍🏻拇指向上:
较浅肤色👍🏼拇指向上:中等-浅肤色👍🏽拇指向上:中等肤色👍🏾拇指向上:中等-深肤色👍🏿拇指向上:较深肤色👎拇指向下👎🏻拇指向下:较浅肤色👎🏼拇指向下:中等-浅肤色👎🏽拇指
向下:中等肤色👎🏾拇指向下:中等-深肤色👎🏿拇指向下:较深肤色🤛朝左的拳头🤛🏻朝左的拳头:较浅肤色🤛🏼朝左的拳头:中等-浅肤色🤛🏽朝左的拳头:中等肤色🤛🏾朝左的拳头:中等-深
肤色🤛🏿朝左的拳头:较深肤色🤜朝右的拳头🤜🏻朝右的拳头:较浅肤色🤜🏼朝右的拳头:中等-浅肤色🤜🏽朝右的拳头:中等肤色🤜🏾朝右的拳头:中等-深肤色🤜🏿朝右的拳头:较深肤色🤝双
手手势62👏鼓掌👏🏻鼓掌:较浅肤色👏🏼鼓掌:中等-浅肤色👏🏽鼓掌:中等肤色👏🏾鼓掌:中等-深肤色👏🏿鼓掌:较深肤色👐张开双手👐🏻张开双手:较浅肤色👐🏼张开双手:中等-浅
肤色👐🏽张开双手:中等肤色👐🏾张开双手:中等-深肤色👐🏿张开双手:较深肤色🙌举双手🙌🏻举双手:较浅肤色🙌🏼举双手:中等-浅肤色🙌🏽举双手:中等肤色🙌🏾举双手:中等-深肤色
🙌🏿举双手:较深肤色🙏双手合十🙏🏻双手合十:较浅肤色🙏🏼双手合十:中等-浅肤色🙏🏽双手合十:中等肤色🙏🏾双手合十:中等-深肤色🙏🏿双手合十:较深肤色🤝握手🤝🏻握手:较浅
肤色🤝🏼握手:中等-浅肤色🤝🏽握手:中等肤色🤝🏾握手:中等-深肤色🤝🏿握手:较深肤色🤲掌心向上托起🤲🏻掌心向上托起:较浅肤色🤲🏼掌心向上托起:中等-浅肤色🤲🏽掌心向上托起
:中等肤色🤲🏾掌心向上托起:中等-深肤色🤲🏿掌心向上托起:较深肤色🫱🏻‍🫲🏼握手:较浅肤色中等-浅肤色🫱🏻‍🫲🏽握手:较浅肤色中等肤色🫱🏻‍🫲🏾握手:较浅肤色中等-深肤
色🫱🏻‍🫲🏿握手:较浅肤色较深肤色🫱🏼‍🫲🏻握手:中等-浅肤色较浅肤色🫱🏼‍🫲🏽握手:中等-浅肤色中等肤色🫱🏼‍🫲🏾握手:中等-浅肤色中等-深肤色🫱🏼‍🫲🏿握手
:中等-浅肤色较深肤色🫱🏽‍🫲🏻握手:中等肤色较浅肤色🫱🏽‍🫲🏼握手:中等肤色中等-浅肤色🫱🏽‍🫲🏾握手:中等肤色中等-深肤色🫱🏽‍🫲🏿握手:中等肤色较深肤色🫱🏾‍
🫲🏻握手:中等-深肤色较浅肤色🫱🏾‍🫲🏼握手:中等-深肤色中等-浅肤色🫱🏾‍🫲🏽握手:中等-深肤色中等肤色🫱🏾‍🫲🏿握手:中等-深肤色较深肤色🫱🏿‍🫲🏻握手:较深肤
色较浅肤色🫱🏿‍🫲🏼握手:较深肤色中等-浅肤色🫱🏿‍🫲🏽握手:较深肤色中等肤色🫱🏿‍🫲🏾握手:较深肤色中等-深肤色🫶做成心形的双手🫶🏻做成心形的双手:较浅肤色🫶🏼做成
心形的双手:中等-浅肤色🫶🏽做成心形的双手:中等肤色🫶🏾做成心形的双手:中等-深肤色🫶🏿做成心形的双手:较深肤色✍️持物手势18✍️写字✍🏻写字:较浅肤色✍🏼写字:中等-浅肤色✍🏽写
字:中等肤色✍🏾写字:中等-深肤色✍🏿写字:较深肤色💅涂指甲油💅🏻涂指甲油:较浅肤色💅🏼涂指甲油:中等-浅肤色💅🏽涂指甲油:中等肤色💅🏾涂指甲油:中等-深肤色💅🏿涂指甲油:较
深肤色🤳自拍🤳🏻自拍:较浅肤色🤳🏼自拍:中等-浅肤色🤳🏽自拍:中等肤色🤳🏾自拍:中等-深肤色🤳🏿自拍:较深肤色👃身体部位48👀双眼👁️眼睛👂耳朵👂🏻耳朵:较浅肤色👂
🏼耳朵:中等-浅肤色👂🏽耳朵:中等肤色👂🏾耳朵:中等-深肤色👂🏿耳朵:较深肤色👃鼻子👃🏻鼻子:较浅肤色👃🏼鼻子:中等-浅肤色👃🏽鼻子:中等肤色👃🏾鼻子:中等-深肤色👃
🏿鼻子:较深肤色👄嘴👅舌头💪肌肉💪🏻肌肉:较浅肤色💪🏼肌肉:中等-浅肤色💪🏽肌肉:中等肤色💪🏾肌肉:中等-深肤色💪🏿肌肉:较深肤色🦴骨头🦵腿🦵🏻腿:较浅肤色🦵🏼
腿:中等-浅肤色🦵🏽腿:中等肤色🦵🏾腿:中等-深肤色🦵🏿腿:较深肤色🦶脚🦶🏻脚:较浅肤色🦶🏼脚:中等-浅肤色🦶🏽脚:中等肤色🦶🏾脚:中等-深肤色🦶🏿脚:较深肤色🦷牙
齿🦻戴助听器的耳朵🦻🏻戴助听器的耳朵:较浅肤色🦻🏼戴助听器的耳朵:中等-浅肤色🦻🏽戴助听器的耳朵:中等肤色🦻🏾戴助听器的耳朵:中等-深肤色🦻🏿戴助听器的耳朵:较深肤色🦾机械手臂
🦿机械腿🧠脑🫀心脏器官🫁肺🫦咬住嘴唇👦人物168👦男孩👦🏻男孩:较浅肤色👦🏼男孩:中等-浅肤色👦🏽男孩:中等肤色👦🏾男孩:中等-深肤色👦🏿男孩:较深肤色👧女孩👧
🏻女孩:较浅肤色👧🏼女孩:中等-浅肤色👧🏽女孩:中等肤色👧🏾女孩:中等-深肤色👧🏿女孩:较深肤色👨男人👨‍🦰男人:红发👨‍🦱男人:卷发👨‍🦲男人:秃顶👨‍🦳男人:白
发👨🏻男人:较浅肤色👨🏻‍🦰男人:较浅肤色红发👨🏻‍🦱男人:较浅肤色卷发👨🏻‍🦲男人:较浅肤色秃顶👨🏻‍🦳男人:较浅肤色白发👨🏼男人:中等-浅肤色👨🏼‍🦰男人:中
等-浅肤色红发👨🏼‍🦱男人:中等-浅肤色卷发👨🏼‍🦲男人:中等-浅肤色秃顶👨🏼‍🦳男人:中等-浅肤色白发👨🏽男人:中等肤色👨🏽‍🦰男人:中等肤色红发👨🏽‍🦱男人:中等
肤色卷发👨🏽‍🦲男人:中等肤色秃顶👨🏽‍🦳男人:中等肤色白发👨🏾男人:中等-深肤色👨🏾‍🦰男人:中等-深肤色红发👨🏾‍🦱男人:中等-深肤色卷发👨🏾‍🦲男人:中等-深肤
色秃顶👨🏾‍🦳男人:中等-深肤色白发👨🏿男人:较深肤色👨🏿‍🦰男人:较深肤色红发👨🏿‍🦱男人:较深肤色卷发👨🏿‍🦲男人:较深肤色秃顶👨🏿‍🦳男人:较深肤色白发👩女人
👩‍🦰女人:红发👩‍🦱女人:卷发👩‍🦲女人:秃顶👩‍🦳女人:白发👩🏻女人:较浅肤色👩🏻‍🦰女人:较浅肤色红发👩🏻‍🦱女人:较浅肤色卷发👩🏻‍🦲女人:较浅肤色秃顶
👩🏻‍🦳女人:较浅肤色白发👩🏼女人:中等-浅肤色👩🏼‍🦰女人:中等-浅肤色红发👩🏼‍🦱女人:中等-浅肤色卷发👩🏼‍🦲女人:中等-浅肤色秃顶👩🏼‍🦳女人:中等-浅肤色白
发👩🏽女人:中等肤色👩🏽‍🦰女人:中等肤色红发👩🏽‍🦱女人:中等肤色卷发👩🏽‍🦲女人:中等肤色秃顶👩🏽‍🦳女人:中等肤色白发👩🏾女人:中等-深肤色👩🏾‍🦰女人:中
等-深肤色红发👩🏾‍🦱女人:中等-深肤色卷发👩🏾‍🦲女人:中等-深肤色秃顶👩🏾‍🦳女人:中等-深肤色白发👩🏿女人:较深肤色👩🏿‍🦰女人:较深肤色红发👩🏿‍🦱女人:较深
肤色卷发👩🏿‍🦲女人:较深肤色秃顶👩🏿‍🦳女人:较深肤色白发👱金色头发的人👱‍♀️金发女👱‍♂️金发男👱🏻金色头发的人:较浅肤色👱🏻‍♀️女人：浅肤色，金色的头发👱🏻‍♂
️男人：浅肤色，金色的头发👱🏼金色头发的人:中等-浅肤色👱🏼‍♀️女人：中浅肤色，金色的头发👱🏼‍♂️男人：中浅肤色，金色的头发👱🏽金色头发的人:中等肤色👱🏽‍♀️女人：中等肤色，
金色的头发👱🏽‍♂️男人：中等肤色，金色的头发👱🏾金色头发的人:中等-深肤色👱🏾‍♀️女人：中深肤色，金色的头发👱🏾‍♂️男人：中深肤色，金色的头发👱🏿金色头发的人:较深肤色👱
🏿‍♀️女人：深肤色，金色的头发👱🏿‍♂️男人：深肤色，金色的头发👴老爷爷👴🏻老爷爷:较浅肤色👴🏼老爷爷:中等-浅肤色👴🏽老爷爷:中等肤色👴🏾老爷爷:中等-深肤色👴🏿老爷爷
:较深肤色👵老奶奶👵🏻老奶奶:较浅肤色👵🏼老奶奶:中等-浅肤色👵🏽老奶奶:中等肤色👵🏾老奶奶:中等-深肤色👵🏿老奶奶:较深肤色👶小宝贝👶🏻小宝贝:较浅肤色👶🏼小宝贝:中
等-浅肤色👶🏽小宝贝:中等肤色👶🏾小宝贝:中等-深肤色👶🏿小宝贝:较深肤色🧑成人🧑‍🦰成人:红发🧑‍🦱成人:卷发🧑‍🦲成人:秃顶🧑‍🦳成人:白发🧑🏻成人:较浅肤色🧑
🏻‍🦰成人:较浅肤色红发🧑🏻‍🦱成人:较浅肤色卷发🧑🏻‍🦲成人:较浅肤色秃顶🧑🏻‍🦳成人:较浅肤色白发🧑🏼成人:中等-浅肤色🧑🏼‍🦰成人:中等-浅肤色红发🧑🏼‍🦱
成人:中等-浅肤色卷发🧑🏼‍🦲成人:中等-浅肤色秃顶🧑🏼‍🦳成人:中等-浅肤色白发🧑🏽成人:中等肤色🧑🏽‍🦰成人:中等肤色红发🧑🏽‍🦱成人:中等肤色卷发🧑🏽‍🦲成人:
中等肤色秃顶🧑🏽‍🦳成人:中等肤色白发🧑🏾成人:中等-深肤色🧑🏾‍🦰成人:中等-深肤色红发🧑🏾‍🦱成人:中等-深肤色卷发🧑🏾‍🦲成人:中等-深肤色秃顶🧑🏾‍🦳成人:中
等-深肤色白发🧑🏿成人:较深肤色🧑🏿‍🦰成人:较深肤色红发🧑🏿‍🦱成人:较深肤色卷发🧑🏿‍🦲成人:较深肤色秃顶🧑🏿‍🦳成人:较深肤色白发🧒儿童🧒🏻儿童:较浅肤色🧒
🏼儿童:中等-浅肤色🧒🏽儿童:中等肤色🧒🏾儿童:中等-深肤色🧒🏿儿童:较深肤色🧓老年人🧓🏻老年人:较浅肤色🧓🏼老年人:中等-浅肤色🧓🏽老年人:中等肤色🧓🏾老年人:中等-
深肤色🧓🏿老年人:较深肤色🧔有胡子的人🧔‍♀️有络腮胡子的女人🧔‍♂️有络腮胡子的男人🧔🏻有胡子的人:较浅肤色🧔🏻‍♀️有络腮胡子的女人:较浅肤色🧔🏻‍♂️有络腮胡子的男人:较浅
肤色🧔🏼有胡子的人:中等-浅肤色🧔🏼‍♀️有络腮胡子的女人:中等-浅肤色🧔🏼‍♂️有络腮胡子的男人:中等-浅肤色🧔🏽有胡子的人:中等肤色🧔🏽‍♀️有络腮胡子的女人:中等肤色🧔🏽
‍♂️有络腮胡子的男人:中等肤色🧔🏾有胡子的人:中等-深肤色🧔🏾‍♀️有络腮胡子的女人:中等-深肤色🧔🏾‍♂️有络腮胡子的男人:中等-深肤色🧔🏿有胡子的人:较深肤色🧔🏿‍♀️有络腮
胡子的女人:较深肤色🧔🏿‍♂️有络腮胡子的男人:较深肤色🙋人物姿势180💁前台💁‍♀️前台女💁‍♂️前台男💁🏻前台:较浅肤色💁🏻‍♀️女人倾手：淡肤色💁🏻‍♂️男子倾手：浅肤色
💁🏼前台:中等-浅肤色💁🏼‍♀️女人倾手：中浅肤色💁🏼‍♂️男士倾手：中浅肤色💁🏽前台:中等肤色💁🏽‍♀️女人倾手：中等肤色💁🏽‍♂️男士倾手：中等肤色💁🏾前台:中等-深肤
色💁🏾‍♀️女人倾手：中深肤色💁🏾‍♂️男士倾手：中深肤色💁🏿前台:较深肤色💁🏿‍♀️女人倾手：深肤色💁🏿‍♂️男人倾手：深肤色🙅禁止手势🙅‍♀️禁止手势女🙅‍♂️禁止手势男
🙅🏻禁止手势:较浅肤色🙅🏻‍♀️女人打手势不同意：浅肤色🙅🏻‍♂️男人打手势不同意：浅肤色🙅🏼禁止手势:中等-浅肤色🙅🏼‍♀️女人打手势不同意：中浅肤色🙅🏼‍♂️男人打手势不同
意：中浅肤色🙅🏽禁止手势:中等肤色🙅🏽‍♀️女人打手势不同意：中等肤色🙅🏽‍♂️男人打手势不同意：中等肤色🙅🏾禁止手势:中等-深肤色🙅🏾‍♀️女人打手势不同意：中深肤色🙅🏾‍♂
️男人打手势不同意：中深肤色🙅🏿禁止手势:较深肤色🙅🏿‍♀️女人打手势不同意：深肤色🙅🏿‍♂️男人打手势不同意：深肤色🙆OK手势🙆‍♀️OK手势女🙆‍♂️OK手势男🙆🏻OK手势:
较浅肤色🙆🏻‍♀️女人打手势同意：浅肤色🙆🏻‍♂️男人打手势同意：浅肤色🙆🏼OK手势:中等-浅肤色🙆🏼‍♀️女人打手势同意：中浅肤色🙆🏼‍♂️男人打手势同意：中浅肤色🙆🏽OK手
势:中等肤色🙆🏽‍♀️女人打手势同意：中等肤色🙆🏽‍♂️男人打手势同意：中等肤色🙆🏾OK手势:中等-深肤色🙆🏾‍♀️女人打手势同意：中深肤色🙆🏾‍♂️男子打手势同意：中深肤色🙆
🏿OK手势:较深肤色🙆🏿‍♀️女人打手势同意：深肤色🙆🏿‍♂️男子打手势同意：深肤色🙇鞠躬🙇‍♀️女生鞠躬🙇‍♂️男生鞠躬🙇🏻鞠躬:较浅肤色🙇🏻‍♀️女人鞠躬：浅肤色🙇🏻‍
♂️男人鞠躬：浅肤色🙇🏼鞠躬:中等-浅肤色🙇🏼‍♀️女人鞠躬：中浅肤色🙇🏼‍♂️男人鞠躬：中浅肤色🙇🏽鞠躬:中等肤色🙇🏽‍♀️女人鞠躬：中等肤色🙇🏽‍♂️男人鞠躬：中等肤色🙇
🏾鞠躬:中等-深肤色🙇🏾‍♀️女人鞠躬：中深肤色🙇🏾‍♂️男人鞠躬：中深肤色🙇🏿鞠躬:较深肤色🙇🏿‍♀️女人鞠躬：深肤色🙇🏿‍♂️男人鞠躬：深肤色🙋举手🙋‍♀️女生举手🙋‍
♂️男生举手🙋🏻举手:较浅肤色🙋🏻‍♀️举手的女人：浅肤色🙋🏻‍♂️举手的男人：浅肤色🙋🏼举手:中等-浅肤色🙋🏼‍♀️举手的女人：中浅肤色🙋🏼‍♂️举手的男人：中浅肤色🙋🏽
举手:中等肤色🙋🏽‍♀️举手的女人：中等肤色🙋🏽‍♂️举手的男人：中等肤色🙋🏾举手:中等-深肤色🙋🏾‍♀️举手的女人：中深肤色🙋🏾‍♂️举手的男人：中深肤色🙋🏿举手:较深肤色
🙋🏿‍♀️举手的女人：深肤色🙋🏿‍♂️举手的男人：深肤色🙍皱眉🙍‍♀️皱眉女🙍‍♂️皱眉男🙍🏻皱眉:较浅肤色🙍🏻‍♀️女人皱着眉头：浅肤色🙍🏻‍♂️男人皱着眉头：浅肤色🙍
🏼皱眉:中等-浅肤色🙍🏼‍♀️女人皱着眉头：中浅肤色🙍🏼‍♂️男人皱着眉头：中浅肤色🙍🏽皱眉:中等肤色🙍🏽‍♀️女人皱着眉头：中等肤色🙍🏽‍♂️男人皱着眉头：中等肤色🙍🏾皱眉
:中等-深肤色🙍🏾‍♀️女人皱着眉头：中深肤色🙍🏾‍♂️男人皱着眉头：中深肤色🙍🏿皱眉:较深肤色🙍🏿‍♀️女人皱着眉头：深肤色🙍🏿‍♂️男人皱着眉头：深肤色🙎撅嘴🙎‍♀️撅嘴女
🙎‍♂️撅嘴男🙎🏻撅嘴:较浅肤色🙎🏻‍♀️女人噘嘴：淡肤色🙎🏻‍♂️男人噘嘴：浅肤色🙎🏼撅嘴:中等-浅肤色🙎🏼‍♀️女人噘嘴：中浅肤色🙎🏼‍♂️男人噘嘴：中浅肤色🙎🏽撅嘴
:中等肤色🙎🏽‍♀️女人噘嘴：中等肤色🙎🏽‍♂️男人噘嘴：中等肤色🙎🏾撅嘴:中等-深肤色🙎🏾‍♀️女人噘嘴：中深肤色🙎🏾‍♂️男人噘嘴：中深肤色🙎🏿撅嘴:较深肤色🙎🏿‍♀️
女人噘嘴：深肤色🙎🏿‍♂️男人噘嘴：深肤色🤦捂脸🤦‍♀️女生捂脸🤦‍♂️男生捂脸🤦🏻捂脸:较浅肤色🤦🏻‍♀️女人捂脸：浅肤色🤦🏻‍♂️男人捂脸：浅肤色🤦🏼捂脸:中等-浅肤色
🤦🏼‍♀️女人捂脸：中浅肤色🤦🏼‍♂️男人捂脸：中浅肤色🤦🏽捂脸:中等肤色🤦🏽‍♀️女人捂脸：中等肤色🤦🏽‍♂️男人捂脸：中等肤色🤦🏾捂脸:中等-深肤色🤦🏾‍♀️女人捂脸：
中深肤色🤦🏾‍♂️男人捂脸：中深肤色🤦🏿捂脸:较深肤色🤦🏿‍♀️女人捂脸：深肤色🤦🏿‍♂️男人捂脸：深肤色🤷耸肩🤷‍♀️女生耸肩🤷‍♂️男生耸肩🤷🏻耸肩:较浅肤色🤷🏻‍♀
️女人耸肩：浅肤色🤷🏻‍♂️男人耸肩：浅肤色🤷🏼耸肩:中等-浅肤色🤷🏼‍♀️女人耸肩：中浅肤色🤷🏼‍♂️男人耸肩：中浅肤色🤷🏽耸肩:中等肤色🤷🏽‍♀️女人耸肩：中等肤色🤷🏽
‍♂️男人耸肩：中等肤色🤷🏾耸肩:中等-深肤色🤷🏾‍♀️女人耸肩：中深肤色🤷🏾‍♂️男人耸肩：中深肤色🤷🏿耸肩:较深肤色🤷🏿‍♀️女人耸肩：深肤色🤷🏿‍♂️男人耸肩：深肤色🧏
失聪者🧏‍♀️失聪的女人🧏‍♂️失聪的男人🧏🏻失聪者:较浅肤色🧏🏻‍♀️聋哑女人：浅肤色🧏🏻‍♂️聋哑男人：浅肤色🧏🏼失聪者:中等-浅肤色🧏🏼‍♀️聋哑女人：中浅肤色🧏🏼‍
♂️聋哑男人：中浅肤色🧏🏽失聪者:中等肤色🧏🏽‍♀️聋哑女人：中等肤色🧏🏽‍♂️聋哑男人：中等肤色🧏🏾失聪者:中等-深肤色🧏🏾‍♀️聋哑女人：中深肤色🧏🏾‍♂️聋哑男人：中深肤
色🧏🏿失聪者:较深肤色🧏🏿‍♀️聋哑女人：深肤色🧏🏿‍♂️聋哑男人：深肤色👨‍🍳职业和角色492👨‍⚕️男医生👨‍⚖️男法官👨‍✈️男飞行员👨‍🌾农夫👨‍🍳男厨师👨‍
🍼哺乳的男人👨‍🎓男学生👨‍🎤男歌手👨‍🎨男艺术家👨‍🏫男老师👨‍🏭男工人👨‍💻男程序员👨‍💼男白领👨‍🔧男技工👨‍🔬男科学家👨‍🚀男宇航员👨‍🚒男消防员
👨🏻‍⚕️男医生:较浅肤色👨🏻‍⚖️男人法官：浅肤色👨🏻‍✈️男人飞行员：浅肤色👨🏻‍🌾农夫:较浅肤色👨🏻‍🍳男厨师:较浅肤色👨🏻‍🍼哺乳的男人:较浅肤色👨🏻‍🎓男
学生:较浅肤色👨🏻‍🎤男歌手:较浅肤色👨🏻‍🎨男艺术家:较浅肤色👨🏻‍🏫男老师:较浅肤色👨🏻‍🏭男工人:较浅肤色👨🏻‍💻男程序员:较浅肤色👨🏻‍💼男白领:较浅肤色
👨🏻‍🔧男技工:较浅肤色👨🏻‍🔬男科学家:较浅肤色👨🏻‍🚀男宇航员:较浅肤色👨🏻‍🚒男消防员:较浅肤色👨🏼‍⚕️男士健康工作者：中浅肤色👨🏼‍⚖️男人法官：中浅肤色👨
🏼‍✈️男子飞行员：中浅肤色👨🏼‍🌾农夫:中等-浅肤色👨🏼‍🍳男厨师:中等-浅肤色👨🏼‍🍼哺乳的男人:中等-浅肤色👨🏼‍🎓男学生:中等-浅肤色👨🏼‍🎤男歌手:中等-浅肤
色👨🏼‍🎨男艺术家:中等-浅肤色👨🏼‍🏫男老师:中等-浅肤色👨🏼‍🏭男工人:中等-浅肤色👨🏼‍💻男程序员:中等-浅肤色👨🏼‍💼男白领:中等-浅肤色👨🏼‍🔧男技工:中
等-浅肤色👨🏼‍🔬男科学家:中等-浅肤色👨🏼‍🚀男宇航员:中等-浅肤色👨🏼‍🚒男消防员:中等-浅肤色👨🏽‍⚕️男性健康工作者：中等肤色👨🏽‍⚖️男人法官：中等肤色👨🏽‍✈
️男子飞行员：中等肤色👨🏽‍🌾农夫:中等肤色👨🏽‍🍳男厨师:中等肤色👨🏽‍🍼哺乳的男人:中等肤色👨🏽‍🎓男学生:中等肤色👨🏽‍🎤男歌手:中等肤色👨🏽‍🎨男艺术家:中
等肤色👨🏽‍🏫男老师:中等肤色👨🏽‍🏭男工人:中等肤色👨🏽‍💻男程序员:中等肤色👨🏽‍💼男白领:中等肤色👨🏽‍🔧男技工:中等肤色👨🏽‍🔬男科学家:中等肤色👨🏽‍
🚀男宇航员:中等肤色👨🏽‍🚒男消防员:中等肤色👨🏾‍⚕️男性健康工作者：中深肤色👨🏾‍⚖️男人法官：中深肤色👨🏾‍✈️男子飞行员：中深肤色👨🏾‍🌾农夫:中等-深肤色👨🏾‍
🍳男厨师:中等-深肤色👨🏾‍🍼哺乳的男人:中等-深肤色👨🏾‍🎓男学生:中等-深肤色👨🏾‍🎤男歌手:中等-深肤色👨🏾‍🎨男艺术家:中等-深肤色👨🏾‍🏫男老师:中等-深肤色
👨🏾‍🏭男工人:中等-深肤色👨🏾‍💻男程序员:中等-深肤色👨🏾‍💼男白领:中等-深肤色👨🏾‍🔧男技工:中等-深肤色👨🏾‍🔬男科学家:中等-深肤色👨🏾‍🚀男宇航员:中
等-深肤色👨🏾‍🚒男消防员:中等-深肤色👨🏿‍⚕️男性健康工作者：深肤色👨🏿‍⚖️男子法官：深肤色👨🏿‍✈️男子飞行员：深肤色👨🏿‍🌾农夫:较深肤色👨🏿‍🍳男厨师:较深肤
色👨🏿‍🍼哺乳的男人:较深肤色👨🏿‍🎓男学生:较深肤色👨🏿‍🎤男歌手:较深肤色👨🏿‍🎨男艺术家:较深肤色👨🏿‍🏫男老师:较深肤色👨🏿‍🏭男工人:较深肤色👨🏿‍
💻男程序员:较深肤色👨🏿‍💼男白领:较深肤色👨🏿‍🔧男技工:较深肤色👨🏿‍🔬男科学家:较深肤色👨🏿‍🚀男宇航员:较深肤色👨🏿‍🚒男消防员:较深肤色👩‍⚕️女医生👩‍
⚖️女法官👩‍✈️女飞行员👩‍🌾农妇👩‍🍳女厨师👩‍🍼哺乳的女人👩‍🎓女学生👩‍🎤女歌手👩‍🎨女艺术家👩‍🏫女老师👩‍🏭女工人👩‍💻女程序员👩‍💼女白领👩‍
🔧女技工👩‍🔬女科学家👩‍🚀女宇航员👩‍🚒女消防员👩🏻‍⚕️女性健康工作者：浅肤色👩🏻‍⚖️女法官：浅肤色👩🏻‍✈️女飞行员：浅肤色👩🏻‍🌾农妇:较浅肤色👩🏻‍🍳
女厨师:较浅肤色👩🏻‍🍼哺乳的女人:较浅肤色👩🏻‍🎓女学生:较浅肤色👩🏻‍🎤女歌手:较浅肤色👩🏻‍🎨女艺术家:较浅肤色👩🏻‍🏫女老师:较浅肤色👩🏻‍🏭女工人:较浅肤
色👩🏻‍💻女程序员:较浅肤色👩🏻‍💼女白领:较浅肤色👩🏻‍🔧女技工:较浅肤色👩🏻‍🔬女科学家:较浅肤色👩🏻‍🚀女宇航员:较浅肤色👩🏻‍🚒女消防员:较浅肤色👩🏼‍
⚕️女性健康工作者：中浅肤色👩🏼‍⚖️女法官：中浅肤色👩🏼‍✈️女飞行员：中浅肤色👩🏼‍🌾农妇:中等-浅肤色👩🏼‍🍳女厨师:中等-浅肤色👩🏼‍🍼哺乳的女人:中等-浅肤色👩
🏼‍🎓女学生:中等-浅肤色👩🏼‍🎤女歌手:中等-浅肤色👩🏼‍🎨女艺术家:中等-浅肤色👩🏼‍🏫女老师:中等-浅肤色👩🏼‍🏭女工人:中等-浅肤色👩🏼‍💻女程序员:中等-浅
肤色👩🏼‍💼女白领:中等-浅肤色👩🏼‍🔧女技工:中等-浅肤色👩🏼‍🔬女科学家:中等-浅肤色👩🏼‍🚀女宇航员:中等-浅肤色👩🏼‍🚒女消防员:中等-浅肤色👩🏽‍⚕️女性健
康工作者：中等肤色👩🏽‍⚖️女法官：中等肤色👩🏽‍✈️女飞行员：中等肤色👩🏽‍🌾农妇:中等肤色👩🏽‍🍳女厨师:中等肤色👩🏽‍🍼哺乳的女人:中等肤色👩🏽‍🎓女学生:中等肤
色👩🏽‍🎤女歌手:中等肤色👩🏽‍🎨女艺术家:中等肤色👩🏽‍🏫女老师:中等肤色👩🏽‍🏭女工人:中等肤色👩🏽‍💻女程序员:中等肤色👩🏽‍💼女白领:中等肤色👩🏽‍🔧
女技工:中等肤色👩🏽‍🔬女科学家:中等肤色👩🏽‍🚀女宇航员:中等肤色👩🏽‍🚒女消防员:中等肤色👩🏾‍⚕️女性健康工作者：中深肤色👩🏾‍⚖️女法官：中深肤色👩🏾‍✈️女飞行
员：中深肤色👩🏾‍🌾农妇:中等-深肤色👩🏾‍🍳女厨师:中等-深肤色👩🏾‍🍼哺乳的女人:中等-深肤色👩🏾‍🎓女学生:中等-深肤色👩🏾‍🎤女歌手:中等-深肤色👩🏾‍🎨女
艺术家:中等-深肤色👩🏾‍🏫女老师:中等-深肤色👩🏾‍🏭女工人:中等-深肤色👩🏾‍💻女程序员:中等-深肤色👩🏾‍💼女白领:中等-深肤色👩🏾‍🔧女技工:中等-深肤色👩🏾
‍🔬女科学家:中等-深肤色👩🏾‍🚀女宇航员:中等-深肤色👩🏾‍🚒女消防员:中等-深肤色👩🏿‍⚕️女性健康工作者：深肤色👩🏿‍⚖️女法官：深肤色👩🏿‍✈️女飞行员：深肤色👩
🏿‍🌾农妇:较深肤色👩🏿‍🍳女厨师:较深肤色👩🏿‍🍼哺乳的女人:较深肤色👩🏿‍🎓女学生:较深肤色👩🏿‍🎤女歌手:较深肤色👩🏿‍🎨女艺术家:较深肤色👩🏿‍🏫女老师
:较深肤色👩🏿‍🏭女工人:较深肤色👩🏿‍💻女程序员:较深肤色👩🏿‍💼女白领:较深肤色👩🏿‍🔧女技工:较深肤色👩🏿‍🔬女科学家:较深肤色👩🏿‍🚀女宇航员:较深肤色👩
🏿‍🚒女消防员:较深肤色👮警察👮‍♀️女警察👮‍♂️男警察👮🏻警察:较浅肤色👮🏻‍♀️女警官：浅肤色👮🏻‍♂️男警官：浅肤色👮🏼警察:中等-浅肤色👮🏼‍♀️女警官：中浅肤
色👮🏼‍♂️男警察:中等-浅肤色👮🏽警察:中等肤色👮🏽‍♀️女警察:中等肤色👮🏽‍♂️男警官：中等肤色👮🏾警察:中等-深肤色👮🏾‍♀️女警官：中深肤色👮🏾‍♂️男警官：中深
肤色👮🏿警察:较深肤色👮🏿‍♀️女警察:较深肤色👮🏿‍♂️男警察:较深肤色👰戴头纱的人👰‍♀️戴头纱的女人👰‍♂️戴头纱的男人👰🏻戴头纱的人:较浅肤色👰🏻‍♀️戴头纱的女人:
较浅肤色👰🏻‍♂️戴头纱的男人:较浅肤色👰🏼戴头纱的人:中等-浅肤色👰🏼‍♀️戴头纱的女人:中等-浅肤色👰🏼‍♂️戴头纱的男人:中等-浅肤色👰🏽戴头纱的人:中等肤色👰🏽‍♀️戴
头纱的女人:中等肤色👰🏽‍♂️戴头纱的男人:中等肤色👰🏾戴头纱的人:中等-深肤色👰🏾‍♀️戴头纱的女人:中等-深肤色👰🏾‍♂️戴头纱的男人:中等-深肤色👰🏿戴头纱的人:较深肤色👰
🏿‍♀️戴头纱的女人:较深肤色👰🏿‍♂️戴头纱的男人:较深肤色👲戴瓜皮帽的人👲🏻戴瓜皮帽的人:较浅肤色👲🏼戴瓜皮帽的人:中等-浅肤色👲🏽戴瓜皮帽的人:中等肤色👲🏾戴瓜皮帽的人:
中等-深肤色👲🏿戴瓜皮帽的人:较深肤色👳戴头巾的人👳‍♀️戴头巾的女人👳‍♂️戴头巾的男人👳🏻戴头巾的人:较浅肤色👳🏻‍♀️女人戴着头巾：浅肤色👳🏻‍♂️男子戴头巾：浅肤色👳
🏼戴头巾的人:中等-浅肤色👳🏼‍♀️女人戴着头巾：中浅肤色👳🏼‍♂️男士戴头巾：中浅肤色👳🏽戴头巾的人:中等肤色👳🏽‍♀️女人戴着头巾：中等肤色👳🏽‍♂️男士戴头巾：中等肤色👳
🏾戴头巾的人:中等-深肤色👳🏾‍♀️女人戴着头巾：中深肤色👳🏾‍♂️男士戴头巾：中深肤色👳🏿戴头巾的人:较深肤色👳🏿‍♀️女人戴着头巾：深肤色👳🏿‍♂️男子戴头巾：深肤色👷建筑
工人👷‍♀️女建筑工人👷‍♂️男建筑工人👷🏻建筑工人:较浅肤色👷🏻‍♀️女建筑工人：浅肤色👷🏻‍♂️男人建筑工人：浅肤色👷🏼建筑工人:中等-浅肤色👷🏼‍♀️女建筑工人：中浅肤色
👷🏼‍♂️男人建筑工人：中浅肤色👷🏽建筑工人:中等肤色👷🏽‍♀️女建筑工人：中等肤色👷🏽‍♂️男子建筑工人：中等肤色👷🏾建筑工人:中等-深肤色👷🏾‍♀️女建筑工人：中深肤色👷
🏾‍♂️男子建筑工人：中深肤色👷🏿建筑工人:较深肤色👷🏿‍♀️女建筑工人：深肤色👷🏿‍♂️男子建筑工人：深肤色👸公主👸🏻公主:较浅肤色👸🏼公主:中等-浅肤色👸🏽公主:中等肤
色👸🏾公主:中等-深肤色👸🏿公主:较深肤色💂卫兵💂‍♀️女卫兵💂‍♂️男卫兵💂🏻卫兵:较浅肤色💂🏻‍♀️女警卫：浅肤色💂🏻‍♂️男警卫：浅肤色💂🏼卫兵:中等-浅肤色💂
🏼‍♀️女警卫：中浅肤色💂🏼‍♂️男警卫：中浅肤色💂🏽卫兵:中等肤色💂🏽‍♀️女警卫：中等肤色💂🏽‍♂️男警卫：中等肤色💂🏾卫兵:中等-深肤色💂🏾‍♀️女警卫：中深肤色💂
🏾‍♂️男警卫：中深肤色💂🏿卫兵:较深肤色💂🏿‍♀️女警卫：深肤色💂🏿‍♂️男警卫：深肤色🕵️侦探🕵️‍♀️女侦探🕵️‍♂️男侦探🕵🏻侦探:较浅肤色🕵🏻‍♀️女侦探：浅肤色
🕵🏻‍♂️男侦探：浅肤色🕵🏼侦探:中等-浅肤色🕵🏼‍♀️女侦探：中浅肤色🕵🏼‍♂️男侦探：中浅肤色🕵🏽侦探:中等肤色🕵🏽‍♀️女侦探：中等肤色🕵🏽‍♂️男侦探：中等肤色🕵
🏾侦探:中等-深肤色🕵🏾‍♀️女侦探：中深肤色🕵🏾‍♂️男侦探：中深肤色🕵🏿侦探:较深肤色🕵🏿‍♀️女侦探：深肤色🕵🏿‍♂️男侦探：深肤色🤰孕妇🤰🏻孕妇:较浅肤色🤰🏼孕
妇:中等-浅肤色🤰🏽孕妇:中等肤色🤰🏾孕妇:中等-深肤色🤰🏿孕妇:较深肤色🤱母乳喂养🤱🏻母乳喂养:较浅肤色🤱🏼母乳喂养:中等-浅肤色🤱🏽母乳喂养:中等肤色🤱🏾母乳喂养:中
等-深肤色🤱🏿母乳喂养:较深肤色🤴王子🤴🏻王子:较浅肤色🤴🏼王子:中等-浅肤色🤴🏽王子:中等肤色🤴🏾王子:中等-深肤色🤴🏿王子:较深肤色🤵穿燕尾服的人🤵‍♀️穿礼服的女人
🤵‍♂️穿礼服的男人🤵🏻穿燕尾服的人:较浅肤色🤵🏻‍♀️穿礼服的女人:较浅肤色🤵🏻‍♂️穿礼服的男人:较浅肤色🤵🏼穿燕尾服的人:中等-浅肤色🤵🏼‍♀️穿礼服的女人:中等-浅肤色
🤵🏼‍♂️穿礼服的男人:中等-浅肤色🤵🏽穿燕尾服的人:中等肤色🤵🏽‍♀️穿礼服的女人:中等肤色🤵🏽‍♂️穿礼服的男人:中等肤色🤵🏾穿燕尾服的人:中等-深肤色🤵🏾‍♀️穿礼服的女
人:中等-深肤色🤵🏾‍♂️穿礼服的男人:中等-深肤色🤵🏿穿燕尾服的人:较深肤色🤵🏿‍♀️穿礼服的女人:较深肤色🤵🏿‍♂️穿礼服的男人:较深肤色🥷忍者🥷🏻忍者:较浅肤色🥷🏼忍者
:中等-浅肤色🥷🏽忍者:中等肤色🥷🏾忍者:中等-深肤色🥷🏿忍者:较深肤色🧑‍⚕️卫生工作者🧑‍⚖️法官🧑‍✈️飞行员🧑‍🌾农民🧑‍🍳厨师🧑‍🍼哺乳的人🧑‍🎓学生🧑‍
🎤歌手🧑‍🎨艺术家🧑‍🏫老师🧑‍🏭工人🧑‍💻程序员🧑‍💼白领🧑‍🔧技工🧑‍🔬科学家🧑‍🚀宇航员🧑‍🚒消防员🧑🏻‍⚕️卫生工作者:较浅肤色🧑🏻‍⚖️法官:较
浅肤色🧑🏻‍✈️飞行员:较浅肤色🧑🏻‍🌾农民:较浅肤色🧑🏻‍🍳厨师:较浅肤色🧑🏻‍🍼哺乳的人:较浅肤色🧑🏻‍🎓学生:较浅肤色🧑🏻‍🎤歌手:较浅肤色🧑🏻‍🎨艺术家
:较浅肤色🧑🏻‍🏫老师:较浅肤色🧑🏻‍🏭工人:较浅肤色🧑🏻‍💻程序员:较浅肤色🧑🏻‍💼白领:较浅肤色🧑🏻‍🔧技工:较浅肤色🧑🏻‍🔬科学家:较浅肤色🧑🏻‍🚀宇航
员:较浅肤色🧑🏻‍🚒消防员:较浅肤色🧑🏼‍⚕️卫生工作者:中等-浅肤色🧑🏼‍⚖️法官:中等-浅肤色🧑🏼‍✈️飞行员:中等-浅肤色🧑🏼‍🌾农民:中等-浅肤色🧑🏼‍🍳厨师:中
等-浅肤色🧑🏼‍🍼哺乳的人:中等-浅肤色🧑🏼‍🎓学生:中等-浅肤色🧑🏼‍🎤歌手:中等-浅肤色🧑🏼‍🎨艺术家:中等-浅肤色🧑🏼‍🏫老师:中等-浅肤色🧑🏼‍🏭工人:中等
-浅肤色🧑🏼‍💻程序员:中等-浅肤色🧑🏼‍💼白领:中等-浅肤色🧑🏼‍🔧技工:中等-浅肤色🧑🏼‍🔬科学家:中等-浅肤色🧑🏼‍🚀宇航员:中等-浅肤色🧑🏼‍🚒消防员:中等
-浅肤色🧑🏽‍⚕️卫生工作者:中等肤色🧑🏽‍⚖️法官:中等肤色🧑🏽‍✈️飞行员:中等肤色🧑🏽‍🌾农民:中等肤色🧑🏽‍🍳厨师:中等肤色🧑🏽‍🍼哺乳的人:中等肤色🧑🏽‍
🎓学生:中等肤色🧑🏽‍🎤歌手:中等肤色🧑🏽‍🎨艺术家:中等肤色🧑🏽‍🏫老师:中等肤色🧑🏽‍🏭工人:中等肤色🧑🏽‍💻程序员:中等肤色🧑🏽‍💼白领:中等肤色🧑🏽‍
🔧技工:中等肤色🧑🏽‍🔬科学家:中等肤色🧑🏽‍🚀宇航员:中等肤色🧑🏽‍🚒消防员:中等肤色🧑🏾‍⚕️卫生工作者:中等-深肤色🧑🏾‍⚖️法官:中等-深肤色🧑🏾‍✈️飞行员:
中等-深肤色🧑🏾‍🌾农民:中等-深肤色🧑🏾‍🍳厨师:中等-深肤色🧑🏾‍🍼哺乳的人:中等-深肤色🧑🏾‍🎓学生:中等-深肤色🧑🏾‍🎤歌手:中等-深肤色🧑🏾‍🎨艺术家:中
等-深肤色🧑🏾‍🏫老师:中等-深肤色🧑🏾‍🏭工人:中等-深肤色🧑🏾‍💻程序员:中等-深肤色🧑🏾‍💼白领:中等-深肤色🧑🏾‍🔧技工:中等-深肤色🧑🏾‍🔬科学家:中等-
深肤色🧑🏾‍🚀宇航员:中等-深肤色🧑🏾‍🚒消防员:中等-深肤色🧑🏿‍⚕️卫生工作者:较深肤色🧑🏿‍⚖️法官:较深肤色🧑🏿‍✈️飞行员:较深肤色🧑🏿‍🌾农民:较深肤色🧑
🏿‍🍳厨师:较深肤色🧑🏿‍🍼哺乳的人:较深肤色🧑🏿‍🎓学生:较深肤色🧑🏿‍🎤歌手:较深肤色🧑🏿‍🎨艺术家:较深肤色🧑🏿‍🏫老师:较深肤色🧑🏿‍🏭工人:较深肤色
🧑🏿‍💻程序员:较深肤色🧑🏿‍💼白领:较深肤色🧑🏿‍🔧技工:较深肤色🧑🏿‍🔬科学家:较深肤色🧑🏿‍🚀宇航员:较深肤色🧑🏿‍🚒消防员:较深肤色🧕带头饰的女人🧕🏻
带头饰的女人:较浅肤色🧕🏼带头饰的女人:中等-浅肤色🧕🏽带头饰的女人:中等肤色🧕🏾带头饰的女人:中等-深肤色🧕🏿带头饰的女人:较深肤色🫃怀孕的男人🫃🏻怀孕的男人:较浅肤色🫃🏼
怀孕的男人:中等-浅肤色🫃🏽怀孕的男人:中等肤色🫃🏾怀孕的男人:中等-深肤色🫃🏿怀孕的男人:较深肤色🫄怀孕的人🫄🏻怀孕的人:较浅肤色🫄🏼怀孕的人:中等-浅肤色🫄🏽怀孕的人:中
等肤色🫄🏾怀孕的人:中等-深肤色🫄🏿怀孕的人:较深肤色🫅戴王冠的人🫅🏻戴王冠的人:较浅肤色🫅🏼戴王冠的人:中等-浅肤色🫅🏽戴王冠的人:中等肤色🫅🏾戴王冠的人:中等-深肤色🫅
🏿戴王冠的人:较深肤色🎅虚构人物158🎅圣诞老人🎅🏻圣诞老人:较浅肤色🎅🏼圣诞老人:中等-浅肤色🎅🏽圣诞老人:中等肤色🎅🏾圣诞老人:中等-深肤色🎅🏿圣诞老人:较深肤色👼小天
使👼🏻小天使:较浅肤色👼🏼小天使:中等-浅肤色👼🏽小天使:中等肤色👼🏾小天使:中等-深肤色👼🏿小天使:较深肤色🤶圣诞奶奶🤶🏻圣诞奶奶:较浅肤色🤶🏼圣诞奶奶:中等-浅肤色
🤶🏽圣诞奶奶:中等肤色🤶🏾圣诞奶奶:中等-深肤色🤶🏿圣诞奶奶:较深肤色🦸超级英雄🦸‍♀️女超级英雄🦸‍♂️男超级英雄🦸🏻超级英雄:较浅肤色🦸🏻‍♀️女超级英雄：浅肤色🦸🏻
‍♂️男超级英雄：浅肤色🦸🏼超级英雄:中等-浅肤色🦸🏼‍♀️女超级英雄：中浅肤色🦸🏼‍♂️男超级英雄：中浅肤色🦸🏽超级英雄:中等肤色🦸🏽‍♀️女超级英雄：中等肤色🦸🏽‍♂️男超
级英雄：中等肤色🦸🏾超级英雄:中等-深肤色🦸🏾‍♀️女超级英雄：中深肤色🦸🏾‍♂️男超级英雄：中深肤色🦸🏿超级英雄:较深肤色🦸🏿‍♀️女超级英雄：深肤色🦸🏿‍♂️男超级英雄：深
肤色🦹超级大坏蛋🦹‍♀️女超级大坏蛋🦹‍♂️男超级大坏蛋🦹🏻超级大坏蛋:较浅肤色🦹🏻‍♀️女超级反派：浅肤色🦹🏻‍♂️男超级反派：浅肤色🦹🏼超级大坏蛋:中等-浅肤色🦹🏼‍♀️
女超级反派：中浅肤色🦹🏼‍♂️男超级反派：中浅肤色🦹🏽超级大坏蛋:中等肤色🦹🏽‍♀️女超级反派：中等肤色🦹🏽‍♂️男超级反派：中等肤色🦹🏾超级大坏蛋:中等-深肤色🦹🏾‍♀️女超
级反派：中深肤色🦹🏾‍♂️男超级反派：中深肤色🦹🏿超级大坏蛋:较深肤色🦹🏿‍♀️女超级反派：深肤色🦹🏿‍♂️男超级反派：深肤色🧌穴居巨怪🧑‍🎄圣诞人🧑🏻‍🎄圣诞人:较浅肤色
🧑🏼‍🎄圣诞人:中等-浅肤色🧑🏽‍🎄圣诞人:中等肤色🧑🏾‍🎄圣诞人:中等-深肤色🧑🏿‍🎄圣诞人:较深肤色🧙法师🧙‍♀️女法师🧙‍♂️男法师🧙🏻法师:较浅肤色🧙🏻‍
♀️女法师：浅肤色🧙🏻‍♂️男法师：浅肤色🧙🏼法师:中等-浅肤色🧙🏼‍♀️女法师：中浅肤色🧙🏼‍♂️男法师：中浅肤色🧙🏽法师:中等肤色🧙🏽‍♀️女法师：中等肤色🧙🏽‍♂️男
法师：中等肤色🧙🏾法师:中等-深肤色🧙🏾‍♀️女法师：中深肤色🧙🏾‍♂️男法师：中深肤色🧙🏿法师:较深肤色🧙🏿‍♀️女法师：深肤色🧙🏿‍♂️男法师：深肤色🧚精灵🧚‍♀️仙女
🧚‍♂️仙人🧚🏻精灵:较浅肤色🧚🏻‍♀️女仙子：浅肤色🧚🏻‍♂️男仙子：浅肤色🧚🏼精灵:中等-浅肤色🧚🏼‍♀️女仙子：中浅肤色🧚🏼‍♂️男仙子：中浅肤色🧚🏽精灵:中等肤色
🧚🏽‍♀️女仙子：中等肤色🧚🏽‍♂️男仙子：中等肤色🧚🏾精灵:中等-深肤色🧚🏾‍♀️女仙子：中深肤色🧚🏾‍♂️男仙子：中深肤色🧚🏿精灵:较深肤色🧚🏿‍♀️女仙子：深肤色🧚
🏿‍♂️男仙子：深肤色🧛吸血鬼🧛‍♀️女吸血鬼🧛‍♂️男吸血鬼🧛🏻吸血鬼:较浅肤色🧛🏻‍♀️女吸血鬼：浅肤色🧛🏻‍♂️男吸血鬼：浅肤色🧛🏼吸血鬼:中等-浅肤色🧛🏼‍♀️女吸
血鬼：中浅肤色🧛🏼‍♂️男吸血鬼：中浅肤色🧛🏽吸血鬼:中等肤色🧛🏽‍♀️女吸血鬼：中等肤色🧛🏽‍♂️男吸血鬼：中等肤色🧛🏾吸血鬼:中等-深肤色🧛🏾‍♀️女吸血鬼：中深肤色🧛
🏾‍♂️男吸血鬼：中深肤色🧛🏿吸血鬼:较深肤色🧛🏿‍♀️女吸血鬼：深肤色🧛🏿‍♂️男吸血鬼：深肤色🧜人鱼🧜‍♀️美人鱼🧜‍♂️男人鱼🧜🏻人鱼:较浅肤色🧜🏻‍♀️美人鱼：浅肤
色🧜🏻‍♂️男人鱼：浅肤色🧜🏼人鱼:中等-浅肤色🧜🏼‍♀️美人鱼：中浅肤色🧜🏼‍♂️男人鱼：中浅肤色🧜🏽人鱼:中等肤色🧜🏽‍♀️美人鱼：中等肤色🧜🏽‍♂️男人鱼：中等肤色
🧜🏾人鱼:中等-深肤色🧜🏾‍♀️美人鱼：中深肤色🧜🏾‍♂️男人鱼：中深肤色🧜🏿人鱼:较深肤色🧜🏿‍♀️美人鱼：深肤色🧜🏿‍♂️男人鱼：深肤色🧝小精灵🧝‍♀️女小精灵🧝‍♂
️男小精灵🧝🏻小精灵:较浅肤色🧝🏻‍♀️女精灵：浅肤色🧝🏻‍♂️男精灵：浅肤色🧝🏼小精灵:中等-浅肤色🧝🏼‍♀️女精灵：中浅肤色🧝🏼‍♂️男精灵：中浅肤色🧝🏽小精灵:中等肤
色🧝🏽‍♀️女精灵：中等肤色🧝🏽‍♂️男精灵：中等肤色🧝🏾小精灵:中等-深肤色🧝🏾‍♀️女精灵：中深肤色🧝🏾‍♂️男精灵：中深肤色🧝🏿小精灵:较深肤色🧝🏿‍♀️女精灵：深肤
色🧝🏿‍♂️男精灵：深肤色🧞妖怪🧞‍♀️女妖怪🧞‍♂️男妖怪🧟僵尸🧟‍♀️女僵尸🧟‍♂️男僵尸🫈毛怪🏃人物活动408🏃跑步者🏃‍♀️女生跑步🏃‍♀️‍➡️女生跑步:面向右边
🏃‍♂️男生跑步🏃‍♂️‍➡️男生跑步:面向右边🏃‍➡️跑步者:面向右边🏃🏻跑步者:较浅肤色🏃🏻‍♀️跑步的女人：浅肤色🏃🏻‍♀️‍➡️女生跑步:较浅肤色面向右边🏃🏻‍♂️跑步的
男人：浅肤色🏃🏻‍♂️‍➡️男生跑步:较浅肤色面向右边🏃🏻‍➡️跑步者:较浅肤色面向右边🏃🏼跑步者:中等-浅肤色🏃🏼‍♀️跑步的女人：中浅肤色🏃🏼‍♀️‍➡️女生跑步:中等-浅肤色
面向右边🏃🏼‍♂️跑步的男人：中浅肤色🏃🏼‍♂️‍➡️男生跑步:中等-浅肤色面向右边🏃🏼‍➡️跑步者:中等-浅肤色面向右边🏃🏽跑步者:中等肤色🏃🏽‍♀️跑步的女人：中等肤色🏃🏽
‍♀️‍➡️女生跑步:中等肤色面向右边🏃🏽‍♂️跑步的男人：中等肤色🏃🏽‍♂️‍➡️男生跑步:中等肤色面向右边🏃🏽‍➡️跑步者:中等肤色面向右边🏃🏾跑步者:中等-深肤色🏃🏾‍♀️跑
步的女人：中深肤色🏃🏾‍♀️‍➡️女生跑步:中等-深肤色面向右边🏃🏾‍♂️跑步的男人：中深肤色🏃🏾‍♂️‍➡️男生跑步:中等-深肤色面向右边🏃🏾‍➡️跑步者:中等-深肤色面向右边🏃
🏿跑步者:较深肤色🏃🏿‍♀️跑步的女人：深肤色🏃🏿‍♀️‍➡️女生跑步:较深肤色面向右边🏃🏿‍♂️跑步的男人：深肤色🏃🏿‍♂️‍➡️男生跑步:较深肤色面向右边🏃🏿‍➡️跑步者:较
深肤色面向右边👨‍🦯拄盲杖的男人👨‍🦯‍➡️拄盲杖的男人:面向右边👨‍🦼坐电动轮椅的男人👨‍🦼‍➡️坐电动轮椅的男人:面向右边👨‍🦽坐手动轮椅的男人👨‍🦽‍➡️坐手动轮椅的男人
:面向右边👨🏻‍🐰‍👨🏼兔先生:较浅肤色中等-浅肤色👨🏻‍🐰‍👨🏽兔先生:较浅肤色中等肤色👨🏻‍🐰‍👨🏾兔先生:较浅肤色中等-深肤色👨🏻‍🐰‍👨🏿兔先生:较浅肤
色较深肤色👨🏻‍🦯拄盲杖的男人:较浅肤色👨🏻‍🦯‍➡️拄盲杖的男人:较浅肤色面向右边👨🏻‍🦼坐电动轮椅的男人:较浅肤色👨🏻‍🦼‍➡️坐电动轮椅的男人:较浅肤色面向右边👨🏻‍
🦽坐手动轮椅的男人:较浅肤色👨🏻‍🦽‍➡️坐手动轮椅的男人:较浅肤色面向右边👨🏼‍🐰‍👨🏻兔先生:中等-浅肤色较浅肤色👨🏼‍🐰‍👨🏽兔先生:中等-浅肤色中等肤色👨🏼‍
🐰‍👨🏾兔先生:中等-浅肤色中等-深肤色👨🏼‍🐰‍👨🏿兔先生:中等-浅肤色较深肤色👨🏼‍🦯拄盲杖的男人:中等-浅肤色👨🏼‍🦯‍➡️拄盲杖的男人:中等-浅肤色面向右边👨🏼
‍🦼坐电动轮椅的男人:中等-浅肤色👨🏼‍🦼‍➡️坐电动轮椅的男人:中等-浅肤色面向右边👨🏼‍🦽坐手动轮椅的男人:中等-浅肤色👨🏼‍🦽‍➡️坐手动轮椅的男人:中等-浅肤色面向右边👨
🏽‍🐰‍👨🏻兔先生:中等肤色较浅肤色👨🏽‍🐰‍👨🏼兔先生:中等肤色中等-浅肤色👨🏽‍🐰‍👨🏾兔先生:中等肤色中等-深肤色👨🏽‍🐰‍👨🏿兔先生:中等肤色较深肤色👨
🏽‍🦯拄盲杖的男人:中等肤色👨🏽‍🦯‍➡️拄盲杖的男人:中等肤色面向右边👨🏽‍🦼坐电动轮椅的男人:中等肤色👨🏽‍🦼‍➡️坐电动轮椅的男人:中等肤色面向右边👨🏽‍🦽坐手动轮椅
的男人:中等肤色👨🏽‍🦽‍➡️坐手动轮椅的男人:中等肤色面向右边👨🏾‍🐰‍👨🏻兔先生:中等-深肤色较浅肤色👨🏾‍🐰‍👨🏼兔先生:中等-深肤色中等-浅肤色👨🏾‍🐰‍👨
🏽兔先生:中等-深肤色中等肤色👨🏾‍🐰‍👨🏿兔先生:中等-深肤色较深肤色👨🏾‍🦯拄盲杖的男人:中等-深肤色👨🏾‍🦯‍➡️拄盲杖的男人:中等-深肤色面向右边👨🏾‍🦼坐电动轮
椅的男人:中等-深肤色👨🏾‍🦼‍➡️坐电动轮椅的男人:中等-深肤色面向右边👨🏾‍🦽坐手动轮椅的男人:中等-深肤色👨🏾‍🦽‍➡️坐手动轮椅的男人:中等-深肤色面向右边👨🏿‍🐰‍
👨🏻兔先生:较深肤色较浅肤色👨🏿‍🐰‍👨🏼兔先生:较深肤色中等-浅肤色👨🏿‍🐰‍👨🏽兔先生:较深肤色中等肤色👨🏿‍🐰‍👨🏾兔先生:较深肤色中等-深肤色👨🏿‍🦯拄
盲杖的男人:较深肤色👨🏿‍🦯‍➡️拄盲杖的男人:较深肤色面向右边👨🏿‍🦼坐电动轮椅的男人:较深肤色👨🏿‍🦼‍➡️坐电动轮椅的男人:较深肤色面向右边👨🏿‍🦽坐手动轮椅的男人:较深
肤色👨🏿‍🦽‍➡️坐手动轮椅的男人:较深肤色面向右边👩‍🦯拄盲杖的女人👩‍🦯‍➡️拄盲杖的女人:面向右边👩‍🦼坐电动轮椅的女人👩‍🦼‍➡️坐电动轮椅的女人:面向右边👩‍🦽坐手
动轮椅的女人👩‍🦽‍➡️坐手动轮椅的女人:面向右边👩🏻‍🐰‍👩🏼兔女郎:较浅肤色中等-浅肤色👩🏻‍🐰‍👩🏽兔女郎:较浅肤色中等肤色👩🏻‍🐰‍👩🏾兔女郎:较浅肤色中等-
深肤色👩🏻‍🐰‍👩🏿兔女郎:较浅肤色较深肤色👩🏻‍🦯拄盲杖的女人:较浅肤色👩🏻‍🦯‍➡️拄盲杖的女人:较浅肤色面向右边👩🏻‍🦼坐电动轮椅的女人:较浅肤色👩🏻‍🦼‍➡️
坐电动轮椅的女人:较浅肤色面向右边👩🏻‍🦽坐手动轮椅的女人:较浅肤色👩🏻‍🦽‍➡️坐手动轮椅的女人:较浅肤色面向右边👩🏼‍🐰‍👩🏻兔女郎:中等-浅肤色较浅肤色👩🏼‍🐰‍👩
🏽兔女郎:中等-浅肤色中等肤色👩🏼‍🐰‍👩🏾兔女郎:中等-浅肤色中等-深肤色👩🏼‍🐰‍👩🏿兔女郎:中等-浅肤色较深肤色👩🏼‍🦯拄盲杖的女人:中等-浅肤色👩🏼‍🦯‍➡️
拄盲杖的女人:中等-浅肤色面向右边👩🏼‍🦼坐电动轮椅的女人:中等-浅肤色👩🏼‍🦼‍➡️坐电动轮椅的女人:中等-浅肤色面向右边👩🏼‍🦽坐手动轮椅的女人:中等-浅肤色👩🏼‍🦽‍➡️
坐手动轮椅的女人:中等-浅肤色面向右边👩🏽‍🐰‍👩🏻兔女郎:中等肤色较浅肤色👩🏽‍🐰‍👩🏼兔女郎:中等肤色中等-浅肤色👩🏽‍🐰‍👩🏾兔女郎:中等肤色中等-深肤色👩🏽‍
🐰‍👩🏿兔女郎:中等肤色较深肤色👩🏽‍🦯拄盲杖的女人:中等肤色👩🏽‍🦯‍➡️拄盲杖的女人:中等肤色面向右边👩🏽‍🦼坐电动轮椅的女人:中等肤色👩🏽‍🦼‍➡️坐电动轮椅的女人
:中等肤色面向右边👩🏽‍🦽坐手动轮椅的女人:中等肤色👩🏽‍🦽‍➡️坐手动轮椅的女人:中等肤色面向右边👩🏾‍🐰‍👩🏻兔女郎:中等-深肤色较浅肤色👩🏾‍🐰‍👩🏼兔女郎:中等
-深肤色中等-浅肤色👩🏾‍🐰‍👩🏽兔女郎:中等-深肤色中等肤色👩🏾‍🐰‍👩🏿兔女郎:中等-深肤色较深肤色👩🏾‍🦯拄盲杖的女人:中等-深肤色👩🏾‍🦯‍➡️拄盲杖的女人:中
等-深肤色面向右边👩🏾‍🦼坐电动轮椅的女人:中等-深肤色👩🏾‍🦼‍➡️坐电动轮椅的女人:中等-深肤色面向右边👩🏾‍🦽坐手动轮椅的女人:中等-深肤色👩🏾‍🦽‍➡️坐手动轮椅的女人
:中等-深肤色面向右边👩🏿‍🐰‍👩🏻兔女郎:较深肤色较浅肤色👩🏿‍🐰‍👩🏼兔女郎:较深肤色中等-浅肤色👩🏿‍🐰‍👩🏽兔女郎:较深肤色中等肤色👩🏿‍🐰‍👩🏾兔女郎
:较深肤色中等-深肤色👩🏿‍🦯拄盲杖的女人:较深肤色👩🏿‍🦯‍➡️拄盲杖的女人:较深肤色面向右边👩🏿‍🦼坐电动轮椅的女人:较深肤色👩🏿‍🦼‍➡️坐电动轮椅的女人:较深肤色面向右
边👩🏿‍🦽坐手动轮椅的女人:较深肤色👩🏿‍🦽‍➡️坐手动轮椅的女人:较深肤色面向右边👯戴兔耳朵的人👯‍♀️兔女郎👯‍♂️兔先生👯🏻戴兔耳朵的人:较浅肤色👯🏻‍♀️兔女郎:较浅
肤色👯🏻‍♂️兔先生:较浅肤色👯🏼戴兔耳朵的人:中等-浅肤色👯🏼‍♀️兔女郎:中等-浅肤色👯🏼‍♂️兔先生:中等-浅肤色👯🏽戴兔耳朵的人:中等肤色👯🏽‍♀️兔女郎:中等肤色👯
🏽‍♂️兔先生:中等肤色👯🏾戴兔耳朵的人:中等-深肤色👯🏾‍♀️兔女郎:中等-深肤色👯🏾‍♂️兔先生:中等-深肤色👯🏿戴兔耳朵的人:较深肤色👯🏿‍♀️兔女郎:较深肤色👯🏿‍♂
️兔先生:较深肤色💃跳舞的女人💃🏻跳舞的女人:较浅肤色💃🏼跳舞的女人:中等-浅肤色💃🏽跳舞的女人:中等肤色💃🏾跳舞的女人:中等-深肤色💃🏿跳舞的女人:较深肤色💆按摩💆‍♀️女
生按摩💆‍♂️男生按摩💆🏻按摩:较浅肤色💆🏻‍♀️女人接受按摩：浅肤色💆🏻‍♂️男人接受按摩：浅肤色💆🏼按摩:中等-浅肤色💆🏼‍♀️女人接受按摩：中浅肤色💆🏼‍♂️男人接受按
摩：中浅肤色💆🏽按摩:中等肤色💆🏽‍♀️女人接受按摩：中等肤色💆🏽‍♂️男人接受按摩：中等肤色💆🏾按摩:中等-深肤色💆🏾‍♀️女人接受按摩：中深肤色💆🏾‍♂️男人接受按摩：中深
肤色💆🏿按摩:较深肤色💆🏿‍♀️女人接受按摩：深肤色💆🏿‍♂️男人接受按摩：深肤色💇理发💇‍♀️女生理发💇‍♂️男生理发💇🏻理发:较浅肤色💇🏻‍♀️女人理发：浅肤色💇🏻‍
♂️男士理发：浅肤色💇🏼理发:中等-浅肤色💇🏼‍♀️女人理发：中浅肤色💇🏼‍♂️男士理发：中浅肤色💇🏽理发:中等肤色💇🏽‍♀️女人理发：中等肤色💇🏽‍♂️男士理发：中等肤色💇
🏾理发:中等-深肤色💇🏾‍♀️女人理发：中深肤色💇🏾‍♂️男士理发：中深肤色💇🏿理发:较深肤色💇🏿‍♀️女人理发：深肤色💇🏿‍♂️男士理发：深肤色🕴️西装革履的人🕴🏻西装革
履的人:较浅肤色🕴🏼西装革履的人:中等-浅肤色🕴🏽西装革履的人:中等肤色🕴🏾西装革履的人:中等-深肤色🕴🏿西装革履的人:较深肤色🕺跳舞的男人🕺🏻跳舞的男人:较浅肤色🕺🏼跳舞的
男人:中等-浅肤色🕺🏽跳舞的男人:中等肤色🕺🏾跳舞的男人:中等-深肤色🕺🏿跳舞的男人:较深肤色🚶行人🚶‍♀️女行人🚶‍♀️‍➡️女行人:面向右边🚶‍♂️男行人🚶‍♂️‍➡️男行人
:面向右边🚶‍➡️行人:面向右边🚶🏻行人:较浅肤色🚶🏻‍♀️女人走路：浅肤色🚶🏻‍♀️‍➡️女行人:较浅肤色面向右边🚶🏻‍♂️男人走路：浅肤色🚶🏻‍♂️‍➡️男行人:较浅肤色面向
右边🚶🏻‍➡️行人:较浅肤色面向右边🚶🏼行人:中等-浅肤色🚶🏼‍♀️女人走路：中浅肤色🚶🏼‍♀️‍➡️女行人:中等-浅肤色面向右边🚶🏼‍♂️男子走路：中浅肤色🚶🏼‍♂️‍➡️男
行人:中等-浅肤色面向右边🚶🏼‍➡️行人:中等-浅肤色面向右边🚶🏽行人:中等肤色🚶🏽‍♀️女人走路：中等肤色🚶🏽‍♀️‍➡️女行人:中等肤色面向右边🚶🏽‍♂️男子走路：中等肤色🚶
🏽‍♂️‍➡️男行人:中等肤色面向右边🚶🏽‍➡️行人:中等肤色面向右边🚶🏾行人:中等-深肤色🚶🏾‍♀️女人走路：中深肤色🚶🏾‍♀️‍➡️女行人:中等-深肤色面向右边🚶🏾‍♂️男子
走路：中深肤色🚶🏾‍♂️‍➡️男行人:中等-深肤色面向右边🚶🏾‍➡️行人:中等-深肤色面向右边🚶🏿行人:较深肤色🚶🏿‍♀️女人走路：深肤色🚶🏿‍♀️‍➡️女行人:较深肤色面向右边
🚶🏿‍♂️男子走路：深肤色🚶🏿‍♂️‍➡️男行人:较深肤色面向右边🚶🏿‍➡️行人:较深肤色面向右边🧍站立者🧍‍♀️站立的女人🧍‍♂️站立的男人🧍🏻站立者:较浅肤色🧍🏻‍♀️女
人站立：浅肤色🧍🏻‍♂️男人站立：浅肤色🧍🏼站立者:中等-浅肤色🧍🏼‍♀️女人站立：中浅肤色🧍🏼‍♂️男人站立：中浅肤色🧍🏽站立者:中等肤色🧍🏽‍♀️女人站立：中等肤色🧍🏽
‍♂️男人站立：中等肤色🧍🏾站立者:中等-深肤色🧍🏾‍♀️女人站立：中深肤色🧍🏾‍♂️男人站立：中深肤色🧍🏿站立者:较深肤色🧍🏿‍♀️女人站立：深肤色🧍🏿‍♂️男人站立：深肤色
🧎下跪者🧎‍♀️跪下的女人🧎‍♀️‍➡️跪下的女人:面向右边🧎‍♂️跪下的男人🧎‍♂️‍➡️跪下的男人:面向右边🧎‍➡️下跪者:面向右边🧎🏻下跪者:较浅肤色🧎🏻‍♀️女人跪着：浅肤
色🧎🏻‍♀️‍➡️跪下的女人:较浅肤色面向右边🧎🏻‍♂️男人跪着：浅肤色🧎🏻‍♂️‍➡️跪下的男人:较浅肤色面向右边🧎🏻‍➡️下跪者:较浅肤色面向右边🧎🏼下跪者:中等-浅肤色🧎
🏼‍♀️女人跪着：中浅肤色🧎🏼‍♀️‍➡️跪下的女人:中等-浅肤色面向右边🧎🏼‍♂️男子跪着：中浅肤色🧎🏼‍♂️‍➡️跪下的男人:中等-浅肤色面向右边🧎🏼‍➡️下跪者:中等-浅肤色面
向右边🧎🏽下跪者:中等肤色🧎🏽‍♀️女人跪着：中等肤色🧎🏽‍♀️‍➡️跪下的女人:中等肤色面向右边🧎🏽‍♂️男人跪着：中等肤色🧎🏽‍♂️‍➡️跪下的男人:中等肤色面向右边🧎🏽‍
➡️下跪者:中等肤色面向右边🧎🏾下跪者:中等-深肤色🧎🏾‍♀️女人跪着：中深肤色🧎🏾‍♀️‍➡️跪下的女人:中等-深肤色面向右边🧎🏾‍♂️男子跪着：中深肤色🧎🏾‍♂️‍➡️跪下的男
人:中等-深肤色面向右边🧎🏾‍➡️下跪者:中等-深肤色面向右边🧎🏿下跪者:较深肤色🧎🏿‍♀️女人跪着：深肤色🧎🏿‍♀️‍➡️跪下的女人:较深肤色面向右边🧎🏿‍♂️男子跪着：深肤色
🧎🏿‍♂️‍➡️跪下的男人:较深肤色面向右边🧎🏿‍➡️下跪者:较深肤色面向右边🧑‍🦯拄盲杖的人🧑‍🦯‍➡️拄盲杖的人:面向右边🧑‍🦼坐电动轮椅的人🧑‍🦼‍➡️坐电动轮椅的人:面
向右边🧑‍🦽坐手动轮椅的人🧑‍🦽‍➡️坐手动轮椅的人:面向右边🧑‍🩰芭蕾舞者🧑🏻‍🐰‍🧑🏼戴兔耳朵的人:较浅肤色中等-浅肤色🧑🏻‍🐰‍🧑🏽戴兔耳朵的人:较浅肤色中等肤色
🧑🏻‍🐰‍🧑🏾戴兔耳朵的人:较浅肤色中等-深肤色🧑🏻‍🐰‍🧑🏿戴兔耳朵的人:较浅肤色较深肤色🧑🏻‍🦯拄盲杖的人:较浅肤色🧑🏻‍🦯‍➡️拄盲杖的人:较浅肤色面向右边🧑
🏻‍🦼坐电动轮椅的人:较浅肤色🧑🏻‍🦼‍➡️坐电动轮椅的人:较浅肤色面向右边🧑🏻‍🦽坐手动轮椅的人:较浅肤色🧑🏻‍🦽‍➡️坐手动轮椅的人:较浅肤色面向右边🧑🏻‍🩰芭蕾舞者:
较浅肤色🧑🏼‍🐰‍🧑🏻戴兔耳朵的人:中等-浅肤色较浅肤色🧑🏼‍🐰‍🧑🏽戴兔耳朵的人:中等-浅肤色中等肤色🧑🏼‍🐰‍🧑🏾戴兔耳朵的人:中等-浅肤色中等-深肤色🧑🏼‍🐰
‍🧑🏿戴兔耳朵的人:中等-浅肤色较深肤色🧑🏼‍🦯拄盲杖的人:中等-浅肤色🧑🏼‍🦯‍➡️拄盲杖的人:中等-浅肤色面向右边🧑🏼‍🦼坐电动轮椅的人:中等-浅肤色🧑🏼‍🦼‍➡️坐电
动轮椅的人:中等-浅肤色面向右边🧑🏼‍🦽坐手动轮椅的人:中等-浅肤色🧑🏼‍🦽‍➡️坐手动轮椅的人:中等-浅肤色面向右边🧑🏼‍🩰芭蕾舞者:中等-浅肤色🧑🏽‍🐰‍🧑🏻戴兔耳朵的
人:中等肤色较浅肤色🧑🏽‍🐰‍🧑🏼戴兔耳朵的人:中等肤色中等-浅肤色🧑🏽‍🐰‍🧑🏾戴兔耳朵的人:中等肤色中等-深肤色🧑🏽‍🐰‍🧑🏿戴兔耳朵的人:中等肤色较深肤色🧑🏽‍
🦯拄盲杖的人:中等肤色🧑🏽‍🦯‍➡️拄盲杖的人:中等肤色面向右边🧑🏽‍🦼坐电动轮椅的人:中等肤色🧑🏽‍🦼‍➡️坐电动轮椅的人:中等肤色面向右边🧑🏽‍🦽坐手动轮椅的人:中等肤色
🧑🏽‍🦽‍➡️坐手动轮椅的人:中等肤色面向右边🧑🏽‍🩰芭蕾舞者:中等肤色🧑🏾‍🐰‍🧑🏻戴兔耳朵的人:中等-深肤色较浅肤色🧑🏾‍🐰‍🧑🏼戴兔耳朵的人:中等-深肤色中等-浅
肤色🧑🏾‍🐰‍🧑🏽戴兔耳朵的人:中等-深肤色中等肤色🧑🏾‍🐰‍🧑🏿戴兔耳朵的人:中等-深肤色较深肤色🧑🏾‍🦯拄盲杖的人:中等-深肤色🧑🏾‍🦯‍➡️拄盲杖的人:中等-深肤
色面向右边🧑🏾‍🦼坐电动轮椅的人:中等-深肤色🧑🏾‍🦼‍➡️坐电动轮椅的人:中等-深肤色面向右边🧑🏾‍🦽坐手动轮椅的人:中等-深肤色🧑🏾‍🦽‍➡️坐手动轮椅的人:中等-深肤色面
向右边🧑🏾‍🩰芭蕾舞者:中等-深肤色🧑🏿‍🐰‍🧑🏻戴兔耳朵的人:较深肤色较浅肤色🧑🏿‍🐰‍🧑🏼戴兔耳朵的人:较深肤色中等-浅肤色🧑🏿‍🐰‍🧑🏽戴兔耳朵的人:较深肤色
中等肤色🧑🏿‍🐰‍🧑🏾戴兔耳朵的人:较深肤色中等-深肤色🧑🏿‍🦯拄盲杖的人:较深肤色🧑🏿‍🦯‍➡️拄盲杖的人:较深肤色面向右边🧑🏿‍🦼坐电动轮椅的人:较深肤色🧑🏿‍🦼
‍➡️坐电动轮椅的人:较深肤色面向右边🧑🏿‍🦽坐手动轮椅的人:较深肤色🧑🏿‍🦽‍➡️坐手动轮椅的人:较深肤色面向右边🧑🏿‍🩰芭蕾舞者:较深肤色🧖蒸房里的人🧖‍♀️蒸房里的女人🧖
‍♂️蒸房里的男人🧖🏻蒸房里的人:较浅肤色🧖🏻‍♀️蒸汽房间里的女人：浅肤色🧖🏻‍♂️蒸汽房间里的男人：浅肤色🧖🏼蒸房里的人:中等-浅肤色🧖🏼‍♀️蒸汽房间里的女人：中浅肤色🧖
🏼‍♂️蒸汽房间里的男人：中浅肤色🧖🏽蒸房里的人:中等肤色🧖🏽‍♀️蒸汽房间里的女人：中等肤色🧖🏽‍♂️蒸汽房间里的男人：中等肤色🧖🏾蒸房里的人:中等-深肤色🧖🏾‍♀️蒸汽房间里
的女人：中深肤色🧖🏾‍♂️蒸汽房间里的男人：中深肤色🧖🏿蒸房里的人:较深肤色🧖🏿‍♀️蒸汽房间里的女人：深肤色🧖🏿‍♂️蒸汽房间里的男人：深肤色🧗攀爬的人🧗‍♀️攀爬的女人🧗‍♂
️攀爬的男人🧗🏻攀爬的人:较浅肤色🧗🏻‍♀️女子攀爬：浅肤色🧗🏻‍♂️男子攀爬：浅肤色🧗🏼攀爬的人:中等-浅肤色🧗🏼‍♀️女子攀爬：中浅肤色🧗🏼‍♂️男子攀爬：中浅肤色🧗🏽
攀爬的人:中等肤色🧗🏽‍♀️女子攀爬：中等肤色🧗🏽‍♂️男子攀爬：中等肤色🧗🏾攀爬的人:中等-深肤色🧗🏾‍♀️女子攀爬：中深肤色🧗🏾‍♂️男子攀爬：中深肤色🧗🏿攀爬的人:较深肤
色🧗🏿‍♀️女子攀爬：深肤色🧗🏿‍♂️男子攀爬：深肤色🚴运动308⛷️滑雪的人⛹️玩球⛹️‍♀️女生玩球⛹️‍♂️男生玩球⛹🏻玩球:较浅肤色⛹🏻‍♀️拍球的女人：浅肤色⛹🏻‍♂️拍球的
男人：浅肤色⛹🏼玩球:中等-浅肤色⛹🏼‍♀️拍球的女人：中浅肤色⛹🏼‍♂️拍球的男人：中浅肤色⛹🏽玩球:中等肤色⛹🏽‍♀️拍球的女人：中等肤色⛹🏽‍♂️拍球的男人：中等肤色⛹🏾玩球:中等
-深肤色⛹🏾‍♀️拍球的女人：中深肤色⛹🏾‍♂️拍球的男人：中深肤色⛹🏿玩球:较深肤色⛹🏿‍♀️拍球的女人：深肤色⛹🏿‍♂️拍球的男人：深肤色🏂滑雪板🏂🏻滑雪板:较浅肤色🏂🏼滑雪板
:中等-浅肤色🏂🏽滑雪板:中等肤色🏂🏾滑雪板:中等-深肤色🏂🏿滑雪板:较深肤色🏄冲浪🏄‍♀️女生冲浪🏄‍♂️男生冲浪🏄🏻冲浪:较浅肤色🏄🏻‍♀️冲浪的女人：浅肤色🏄🏻‍♂
️冲浪的男人：浅肤色🏄🏼冲浪:中等-浅肤色🏄🏼‍♀️冲浪的女人：中浅肤色🏄🏼‍♂️冲浪的男人：中浅肤色🏄🏽冲浪:中等肤色🏄🏽‍♀️冲浪的女人：中等肤色🏄🏽‍♂️冲浪的男人：中等
肤色🏄🏾冲浪:中等-深肤色🏄🏾‍♀️冲浪的女人：中深肤色🏄🏾‍♂️冲浪的男人：中深肤色🏄🏿冲浪:较深肤色🏄🏿‍♀️冲浪的女人：深肤色🏄🏿‍♂️冲浪的男人：深肤色🏇赛马🏇🏻
赛马:较浅肤色🏇🏼赛马:中等-浅肤色🏇🏽赛马:中等肤色🏇🏾赛马:中等-深肤色🏇🏿赛马:较深肤色🏊游泳🏊‍♀️女生游泳🏊‍♂️男生游泳🏊🏻游泳:较浅肤色🏊🏻‍♀️游泳的女人
：浅肤色🏊🏻‍♂️游泳的男人：浅肤色🏊🏼游泳:中等-浅肤色🏊🏼‍♀️游泳的女人：中浅肤色🏊🏼‍♂️游泳的男人：中浅肤色🏊🏽游泳:中等肤色🏊🏽‍♀️游泳的女人：中等肤色🏊🏽‍
♂️游泳的男人：中等肤色🏊🏾游泳:中等-深肤色🏊🏾‍♀️游泳的女人：中深肤色🏊🏾‍♂️游泳的男人：中深肤色🏊🏿游泳:较深肤色🏊🏿‍♀️游泳的女人：深肤色🏊🏿‍♂️游泳的男人：深
肤色🏋️举重🏋️‍♀️女生举重🏋️‍♂️男生举重🏋🏻举重:较浅肤色🏋🏻‍♀️女子举重：浅肤色🏋🏻‍♂️男子举重：浅肤色🏋🏼举重:中等-浅肤色🏋🏼‍♀️女子举重：中浅肤色🏋
🏼‍♂️男子举重：中浅肤色🏋🏽举重:中等肤色🏋🏽‍♀️女子举重：中等肤色🏋🏽‍♂️男子举重：中等肤色🏋🏾举重:中等-深肤色🏋🏾‍♀️女子举重：中深肤色🏋🏾‍♂️男子举重：中深
肤色🏋🏿举重:较深肤色🏋🏿‍♀️女子举重：深肤色🏋🏿‍♂️男子举重：深肤色🏌️打高尔夫的人🏌️‍♀️女生打高尔夫🏌️‍♂️男生打高尔夫🏌🏻打高尔夫的人:较浅肤色🏌🏻‍♀️女子
高尔夫球：浅肤色🏌🏻‍♂️男子高尔夫球：浅肤色🏌🏼打高尔夫的人:中等-浅肤色🏌🏼‍♀️女子高尔夫球：中浅肤色🏌🏼‍♂️男子高尔夫球：中浅肤色🏌🏽打高尔夫的人:中等肤色🏌🏽‍♀️
女子高尔夫球：中等肤色🏌🏽‍♂️男子高尔夫球：中等肤色🏌🏾打高尔夫的人:中等-深肤色🏌🏾‍♀️女子高尔夫球：中深肤色🏌🏾‍♂️男子高尔夫球：中深肤色🏌🏿打高尔夫的人:较深肤色🏌
🏿‍♀️女子高尔夫球：深肤色🏌🏿‍♂️男子高尔夫球：深肤色👨🏻‍🫯‍👨🏼男生摔跤:较浅肤色中等-浅肤色👨🏻‍🫯‍👨🏽男生摔跤:较浅肤色中等肤色👨🏻‍🫯‍👨🏾男生摔跤
:较浅肤色中等-深肤色👨🏻‍🫯‍👨🏿男生摔跤:较浅肤色较深肤色👨🏼‍🫯‍👨🏻男生摔跤:中等-浅肤色较浅肤色👨🏼‍🫯‍👨🏽男生摔跤:中等-浅肤色中等肤色👨🏼‍🫯‍👨
🏾男生摔跤:中等-浅肤色中等-深肤色👨🏼‍🫯‍👨🏿男生摔跤:中等-浅肤色较深肤色👨🏽‍🫯‍👨🏻男生摔跤:中等肤色较浅肤色👨🏽‍🫯‍👨🏼男生摔跤:中等肤色中等-浅肤色👨
🏽‍🫯‍👨🏾男生摔跤:中等肤色中等-深肤色👨🏽‍🫯‍👨🏿男生摔跤:中等肤色较深肤色👨🏾‍🫯‍👨🏻男生摔跤:中等-深肤色较浅肤色👨🏾‍🫯‍👨🏼男生摔跤:中等-深肤色
中等-浅肤色👨🏾‍🫯‍👨🏽男生摔跤:中等-深肤色中等肤色👨🏾‍🫯‍👨🏿男生摔跤:中等-深肤色较深肤色👨🏿‍🫯‍👨🏻男生摔跤:较深肤色较浅肤色👨🏿‍🫯‍👨🏼男生摔
跤:较深肤色中等-浅肤色👨🏿‍🫯‍👨🏽男生摔跤:较深肤色中等肤色👨🏿‍🫯‍👨🏾男生摔跤:较深肤色中等-深肤色👩🏻‍🫯‍👩🏼女生摔跤:较浅肤色中等-浅肤色👩🏻‍🫯‍
👩🏽女生摔跤:较浅肤色中等肤色👩🏻‍🫯‍👩🏾女生摔跤:较浅肤色中等-深肤色👩🏻‍🫯‍👩🏿女生摔跤:较浅肤色较深肤色👩🏼‍🫯‍👩🏻女生摔跤:中等-浅肤色较浅肤色👩🏼
‍🫯‍👩🏽女生摔跤:中等-浅肤色中等肤色👩🏼‍🫯‍👩🏾女生摔跤:中等-浅肤色中等-深肤色👩🏼‍🫯‍👩🏿女生摔跤:中等-浅肤色较深肤色👩🏽‍🫯‍👩🏻女生摔跤:中等肤色
较浅肤色👩🏽‍🫯‍👩🏼女生摔跤:中等肤色中等-浅肤色👩🏽‍🫯‍👩🏾女生摔跤:中等肤色中等-深肤色👩🏽‍🫯‍👩🏿女生摔跤:中等肤色较深肤色👩🏾‍🫯‍👩🏻女生摔跤:
中等-深肤色较浅肤色👩🏾‍🫯‍👩🏼女生摔跤:中等-深肤色中等-浅肤色👩🏾‍🫯‍👩🏽女生摔跤:中等-深肤色中等肤色👩🏾‍🫯‍👩🏿女生摔跤:中等-深肤色较深肤色👩🏿‍🫯
‍👩🏻女生摔跤:较深肤色较浅肤色👩🏿‍🫯‍👩🏼女生摔跤:较深肤色中等-浅肤色👩🏿‍🫯‍👩🏽女生摔跤:较深肤色中等肤色👩🏿‍🫯‍👩🏾女生摔跤:较深肤色中等-深肤色🚣划
艇🚣‍♀️女生划船🚣‍♂️男生划船🚣🏻划艇:较浅肤色🚣🏻‍♀️女子划艇：浅肤色🚣🏻‍♂️男子划艇：浅肤色🚣🏼划艇:中等-浅肤色🚣🏼‍♀️女子划艇：中浅肤色🚣🏼‍♂️男子划艇
：中浅肤色🚣🏽划艇:中等肤色🚣🏽‍♀️女子划艇：中等肤色🚣🏽‍♂️男子划艇：中等肤色🚣🏾划艇:中等-深肤色🚣🏾‍♀️女子划艇：中深肤色🚣🏾‍♂️男子划艇：中深肤色🚣🏿划艇:
较深肤色🚣🏿‍♀️女子划艇：深肤色🚣🏿‍♂️男子划艇：深肤色🚴骑自行车🚴‍♀️女生骑自行车🚴‍♂️男生骑自行车🚴🏻骑自行车:较浅肤色🚴🏻‍♀️骑自行车的女人：浅肤色🚴🏻‍♂️
骑自行车的男人：浅肤色🚴🏼骑自行车:中等-浅肤色🚴🏼‍♀️骑自行车的女人：中浅肤色🚴🏼‍♂️骑自行车的男人：中浅肤色🚴🏽骑自行车:中等肤色🚴🏽‍♀️骑自行车的女人：中等肤色🚴🏽
‍♂️骑自行车的男人：中等肤色🚴🏾骑自行车:中等-深肤色🚴🏾‍♀️骑自行车的女人：中深肤色🚴🏾‍♂️骑自行车的男人：中深肤色🚴🏿骑自行车:较深肤色🚴🏿‍♀️女生骑自行车:较深肤色
🚴🏿‍♂️男生骑自行车:较深肤色🚵骑山地车🚵‍♀️女生骑山地车🚵‍♂️男生骑山地车🚵🏻骑山地车:较浅肤色🚵🏻‍♀️女子山地自行车：浅肤色🚵🏻‍♂️男子山地自行车：浅肤色🚵🏼骑
山地车:中等-浅肤色🚵🏼‍♀️女子山地自行车：中浅肤色🚵🏼‍♂️男子山地自行车：中浅肤色🚵🏽骑山地车:中等肤色🚵🏽‍♀️女子山地自行车：中等肤色🚵🏽‍♂️男子山地自行车：中等肤色
🚵🏾骑山地车:中等-深肤色🚵🏾‍♀️女子山地自行车：中深肤色🚵🏾‍♂️男子山地自行车：中深肤色🚵🏿骑山地车:较深肤色🚵🏿‍♀️女子山地自行车：深肤色🚵🏿‍♂️男子山地自行车：深
肤色🤸侧手翻🤸‍♀️女生侧手翻🤸‍♂️男生侧手翻🤸🏻侧手翻:较浅肤色🤸🏻‍♀️女人翻筋斗：浅肤色🤸🏻‍♂️男人翻筋斗：浅肤色🤸🏼侧手翻:中等-浅肤色🤸🏼‍♀️女人翻筋斗：中浅
肤色🤸🏼‍♂️男人翻筋斗：中浅肤色🤸🏽侧手翻:中等肤色🤸🏽‍♀️女人翻筋斗：中等肤色🤸🏽‍♂️男人翻筋斗：中等肤色🤸🏾侧手翻:中等-深肤色🤸🏾‍♀️女人翻筋斗：中深肤色🤸🏾
‍♂️男人翻筋斗：中深肤色🤸🏿侧手翻:较深肤色🤸🏿‍♀️女人翻筋斗：深肤色🤸🏿‍♂️男人翻筋斗：深肤色🤹抛接杂耍🤹‍♀️女生抛接杂耍🤹‍♂️男生抛接杂耍🤹🏻抛接杂耍:较浅肤色🤹
🏻‍♀️女人玩杂耍：浅肤色🤹🏻‍♂️男人玩杂耍：浅肤色🤹🏼抛接杂耍:中等-浅肤色🤹🏼‍♀️女人玩杂耍：中浅肤色🤹🏼‍♂️男人玩杂耍：中浅肤色🤹🏽抛接杂耍:中等肤色🤹🏽‍♀️女
人玩杂耍：中等肤色🤹🏽‍♂️男人玩杂耍：中等肤色🤹🏾抛接杂耍:中等-深肤色🤹🏾‍♀️女人玩杂耍：中深肤色🤹🏾‍♂️男人玩杂耍：中深肤色🤹🏿抛接杂耍:较深肤色🤹🏿‍♀️女人玩杂耍
：深肤色🤹🏿‍♂️男人玩杂耍：深肤色🤺击剑选手🤼摔跤选手🤼‍♀️女生摔跤🤼‍♂️男生摔跤🤼🏻摔跤选手:较浅肤色🤼🏻‍♀️女生摔跤:较浅肤色🤼🏻‍♂️男生摔跤:较浅肤色🤼🏼摔
跤选手:中等-浅肤色🤼🏼‍♀️女生摔跤:中等-浅肤色🤼🏼‍♂️男生摔跤:中等-浅肤色🤼🏽摔跤选手:中等肤色🤼🏽‍♀️女生摔跤:中等肤色🤼🏽‍♂️男生摔跤:中等肤色🤼🏾摔跤选手:
中等-深肤色🤼🏾‍♀️女生摔跤:中等-深肤色🤼🏾‍♂️男生摔跤:中等-深肤色🤼🏿摔跤选手:较深肤色🤼🏿‍♀️女生摔跤:较深肤色🤼🏿‍♂️男生摔跤:较深肤色🤽水球🤽‍♀️女生玩水
球🤽‍♂️男生玩水球🤽🏻水球:较浅肤色🤽🏻‍♀️女人玩水球：浅肤色🤽🏻‍♂️男子打水球：浅肤色🤽🏼水球:中等-浅肤色🤽🏼‍♀️女子打水球：中浅肤色🤽🏼‍♂️男子打水球：中浅肤
色🤽🏽水球:中等肤色🤽🏽‍♀️女子打水球：中等肤色🤽🏽‍♂️男子打水球：中等肤色🤽🏾水球:中等-深肤色🤽🏾‍♀️女子打水球：中深肤色🤽🏾‍♂️男子打水球：中深肤色🤽🏿水球:
较深肤色🤽🏿‍♀️女子打水球：深肤色🤽🏿‍♂️男子打水球：深肤色🤾手球🤾‍♀️女生玩手球🤾‍♂️男生玩手球🤾🏻手球:较浅肤色🤾🏻‍♀️女子手球：浅肤色🤾🏻‍♂️男子手球：浅肤
色🤾🏼手球:中等-浅肤色🤾🏼‍♀️女子手球：中浅肤色🤾🏼‍♂️男子手球：中浅肤色🤾🏽手球:中等肤色🤾🏽‍♀️女子手球：中等肤色🤾🏽‍♂️男子手球：中等肤色🤾🏾手球:中等-深
肤色🤾🏾‍♀️女子手球：中深肤色🤾🏾‍♂️男子手球：中深肤色🤾🏿手球:较深肤色🤾🏿‍♀️女子手球：深肤色🤾🏿‍♂️男子手球：深肤色🧑🏻‍🫯‍🧑🏼摔跤选手:较浅肤色中等-浅
肤色🧑🏻‍🫯‍🧑🏽摔跤选手:较浅肤色中等肤色🧑🏻‍🫯‍🧑🏾摔跤选手:较浅肤色中等-深肤色🧑🏻‍🫯‍🧑🏿摔跤选手:较浅肤色较深肤色🧑🏼‍🫯‍🧑🏻摔跤选手:中等-浅
肤色较浅肤色🧑🏼‍🫯‍🧑🏽摔跤选手:中等-浅肤色中等肤色🧑🏼‍🫯‍🧑🏾摔跤选手:中等-浅肤色中等-深肤色🧑🏼‍🫯‍🧑🏿摔跤选手:中等-浅肤色较深肤色🧑🏽‍🫯‍🧑
🏻摔跤选手:中等肤色较浅肤色🧑🏽‍🫯‍🧑🏼摔跤选手:中等肤色中等-浅肤色🧑🏽‍🫯‍🧑🏾摔跤选手:中等肤色中等-深肤色🧑🏽‍🫯‍🧑🏿摔跤选手:中等肤色较深肤色🧑🏾‍
🫯‍🧑🏻摔跤选手:中等-深肤色较浅肤色🧑🏾‍🫯‍🧑🏼摔跤选手:中等-深肤色中等-浅肤色🧑🏾‍🫯‍🧑🏽摔跤选手:中等-深肤色中等肤色🧑🏾‍🫯‍🧑🏿摔跤选手:中等-深肤
色较深肤色🧑🏿‍🫯‍🧑🏻摔跤选手:较深肤色较浅肤色🧑🏿‍🫯‍🧑🏼摔跤选手:较深肤色中等-浅肤色🧑🏿‍🫯‍🧑🏽摔跤选手:较深肤色中等肤色🧑🏿‍🫯‍🧑🏾摔跤选手:较
深肤色中等-深肤色🛌人物休息30🛀洗澡的人🛀🏻洗澡的人:较浅肤色🛀🏼洗澡的人:中等-浅肤色🛀🏽洗澡的人:中等肤色🛀🏾洗澡的人:中等-深肤色🛀🏿洗澡的人:较深肤色🛌躺在床上的人
🛌🏻躺在床上的人:较浅肤色🛌🏼躺在床上的人:中等-浅肤色🛌🏽躺在床上的人:中等肤色🛌🏾躺在床上的人:中等-深肤色🛌🏿躺在床上的人:较深肤色🧘盘腿的人🧘‍♀️盘腿的女人🧘‍♂️
盘腿的男人🧘🏻盘腿的人:较浅肤色🧘🏻‍♀️打坐的女人：浅肤色🧘🏻‍♂️打坐的男人：浅肤色🧘🏼盘腿的人:中等-浅肤色🧘🏼‍♀️打坐的女人：中浅肤色🧘🏼‍♂️打坐的男人：中浅肤色
🧘🏽盘腿的人:中等肤色🧘🏽‍♀️打坐的女人：中等肤色🧘🏽‍♂️打坐的男人：中等肤色🧘🏾盘腿的人:中等-深肤色🧘🏾‍♀️打坐的女人：中深肤色🧘🏾‍♂️打坐的男人：中深肤色🧘🏿
盘腿的人:较深肤色🧘🏿‍♀️打坐的女人：深肤色🧘🏿‍♂️打坐的男人：深肤色👨‍👩‍👧‍👦家庭和情侣337👨‍❤️‍👨带心的夫妇：男人和男人👨‍❤️‍💋‍👨亲吻：男人和男人👨
‍👦家庭:男人男孩👨‍👦‍👦家庭:男人男孩男孩👨‍👧家庭:男人女孩👨‍👧‍👦家庭:男人女孩男孩👨‍👧‍👧家庭:男人女孩女孩👨‍👨‍👦家庭:男人男人男孩👨‍👨‍👦‍
👦家庭:男人男人男孩男孩👨‍👨‍👧家庭:男人男人女孩👨‍👨‍👧‍👦家庭:男人男人女孩男孩👨‍👨‍👧‍👧家庭:男人男人女孩女孩👨‍👩‍👦家庭:男人女人男孩👨‍👩‍👦‍
👦家庭:男人女人男孩男孩👨‍👩‍👧家庭:男人女人女孩👨‍👩‍👧‍👦家庭:男人女人女孩男孩👨‍👩‍👧‍👧家庭:男人女人女孩女孩👨🏻‍❤️‍👨🏻情侣:男人男人较浅肤色👨
🏻‍❤️‍👨🏼情侣:男人男人较浅肤色中等-浅肤色👨🏻‍❤️‍👨🏽情侣:男人男人较浅肤色中等肤色👨🏻‍❤️‍👨🏾情侣:男人男人较浅肤色中等-深肤色👨🏻‍❤️‍👨🏿情侣:男人
男人较浅肤色较深肤色👨🏻‍❤️‍💋‍👨🏻亲吻:男人男人较浅肤色👨🏻‍❤️‍💋‍👨🏼亲吻:男人男人较浅肤色中等-浅肤色👨🏻‍❤️‍💋‍👨🏽亲吻:男人男人较浅肤色中等肤色👨
🏻‍❤️‍💋‍👨🏾亲吻:男人男人较浅肤色中等-深肤色👨🏻‍❤️‍💋‍👨🏿亲吻:男人男人较浅肤色较深肤色👨🏻‍🤝‍👨🏼手拉手的两个男人:较浅肤色中等-浅肤色👨🏻‍🤝‍
👨🏽手拉手的两个男人:较浅肤色中等肤色👨🏻‍🤝‍👨🏾手拉手的两个男人:较浅肤色中等-深肤色👨🏻‍🤝‍👨🏿手拉手的两个男人:较浅肤色较深肤色👨🏼‍❤️‍👨🏻情侣:男人男人
中等-浅肤色较浅肤色👨🏼‍❤️‍👨🏼情侣:男人男人中等-浅肤色👨🏼‍❤️‍👨🏽情侣:男人男人中等-浅肤色中等肤色👨🏼‍❤️‍👨🏾情侣:男人男人中等-浅肤色中等-深肤色👨🏼‍
❤️‍👨🏿情侣:男人男人中等-浅肤色较深肤色👨🏼‍❤️‍💋‍👨🏻亲吻:男人男人中等-浅肤色较浅肤色👨🏼‍❤️‍💋‍👨🏼亲吻:男人男人中等-浅肤色👨🏼‍❤️‍💋‍👨🏽亲
吻:男人男人中等-浅肤色中等肤色👨🏼‍❤️‍💋‍👨🏾亲吻:男人男人中等-浅肤色中等-深肤色👨🏼‍❤️‍💋‍👨🏿亲吻:男人男人中等-浅肤色较深肤色👨🏼‍🤝‍👨🏻手拉手的两个
男人:中等-浅肤色较浅肤色👨🏼‍🤝‍👨🏽手拉手的两个男人:中等-浅肤色中等肤色👨🏼‍🤝‍👨🏾手拉手的两个男人:中等-浅肤色中等-深肤色👨🏼‍🤝‍👨🏿手拉手的两个男人:中等
-浅肤色较深肤色👨🏽‍❤️‍👨🏻情侣:男人男人中等肤色较浅肤色👨🏽‍❤️‍👨🏼情侣:男人男人中等肤色中等-浅肤色👨🏽‍❤️‍👨🏽情侣:男人男人中等肤色👨🏽‍❤️‍👨🏾情
侣:男人男人中等肤色中等-深肤色👨🏽‍❤️‍👨🏿情侣:男人男人中等肤色较深肤色👨🏽‍❤️‍💋‍👨🏻亲吻:男人男人中等肤色较浅肤色👨🏽‍❤️‍💋‍👨🏼亲吻:男人男人中等肤色中
等-浅肤色👨🏽‍❤️‍💋‍👨🏽亲吻:男人男人中等肤色👨🏽‍❤️‍💋‍👨🏾亲吻:男人男人中等肤色中等-深肤色👨🏽‍❤️‍💋‍👨🏿亲吻:男人男人中等肤色较深肤色👨🏽‍🤝
‍👨🏻手拉手的两个男人:中等肤色较浅肤色👨🏽‍🤝‍👨🏼手拉手的两个男人:中等肤色中等-浅肤色👨🏽‍🤝‍👨🏾手拉手的两个男人:中等肤色中等-深肤色👨🏽‍🤝‍👨🏿手拉手的
两个男人:中等肤色较深肤色👨🏾‍❤️‍👨🏻情侣:男人男人中等-深肤色较浅肤色👨🏾‍❤️‍👨🏼情侣:男人男人中等-深肤色中等-浅肤色👨🏾‍❤️‍👨🏽情侣:男人男人中等-深肤色中等
肤色👨🏾‍❤️‍👨🏾情侣:男人男人中等-深肤色👨🏾‍❤️‍👨🏿情侣:男人男人中等-深肤色较深肤色👨🏾‍❤️‍💋‍👨🏻亲吻:男人男人中等-深肤色较浅肤色👨🏾‍❤️‍💋‍
👨🏼亲吻:男人男人中等-深肤色中等-浅肤色👨🏾‍❤️‍💋‍👨🏽亲吻:男人男人中等-深肤色中等肤色👨🏾‍❤️‍💋‍👨🏾亲吻:男人男人中等-深肤色👨🏾‍❤️‍💋‍👨🏿亲吻
:男人男人中等-深肤色较深肤色👨🏾‍🤝‍👨🏻手拉手的两个男人:中等-深肤色较浅肤色👨🏾‍🤝‍👨🏼手拉手的两个男人:中等-深肤色中等-浅肤色👨🏾‍🤝‍👨🏽手拉手的两个男人:
中等-深肤色中等肤色👨🏾‍🤝‍👨🏿手拉手的两个男人:中等-深肤色较深肤色👨🏿‍❤️‍👨🏻情侣:男人男人较深肤色较浅肤色👨🏿‍❤️‍👨🏼情侣:男人男人较深肤色中等-浅肤色👨
🏿‍❤️‍👨🏽情侣:男人男人较深肤色中等肤色👨🏿‍❤️‍👨🏾情侣:男人男人较深肤色中等-深肤色👨🏿‍❤️‍👨🏿情侣:男人男人较深肤色👨🏿‍❤️‍💋‍👨🏻亲吻:男人男人较
深肤色较浅肤色👨🏿‍❤️‍💋‍👨🏼亲吻:男人男人较深肤色中等-浅肤色👨🏿‍❤️‍💋‍👨🏽亲吻:男人男人较深肤色中等肤色👨🏿‍❤️‍💋‍👨🏾亲吻:男人男人较深肤色中等-深肤
色👨🏿‍❤️‍💋‍👨🏿亲吻:男人男人较深肤色👨🏿‍🤝‍👨🏻手拉手的两个男人:较深肤色较浅肤色👨🏿‍🤝‍👨🏼手拉手的两个男人:较深肤色中等-浅肤色👨🏿‍🤝‍👨🏽手
拉手的两个男人:较深肤色中等肤色👨🏿‍🤝‍👨🏾手拉手的两个男人:较深肤色中等-深肤色👩‍❤️‍👨带心的夫妇：女人和男人👩‍❤️‍👩情侣:女人女人👩‍❤️‍💋‍👨吻：女人和男人
👩‍❤️‍💋‍👩亲吻:女人女人👩‍👦家庭:女人男孩👩‍👦‍👦家庭:女人男孩男孩👩‍👧家庭:女人女孩👩‍👧‍👦家庭:女人女孩男孩👩‍👧‍👧家庭:女人女孩女孩👩‍👩‍
👦家庭:女人女人男孩👩‍👩‍👦‍👦家庭:女人女人男孩男孩👩‍👩‍👧家庭:女人女人女孩👩‍👩‍👧‍👦家庭:女人女人女孩男孩👩‍👩‍👧‍👧家庭:女人女人女孩女孩👩🏻‍❤
️‍👨🏻情侣:女人男人较浅肤色👩🏻‍❤️‍👨🏼情侣:女人男人较浅肤色中等-浅肤色👩🏻‍❤️‍👨🏽情侣:女人男人较浅肤色中等肤色👩🏻‍❤️‍👨🏾情侣:女人男人较浅肤色中等-深
肤色👩🏻‍❤️‍👨🏿情侣:女人男人较浅肤色较深肤色👩🏻‍❤️‍👩🏻情侣:女人女人较浅肤色👩🏻‍❤️‍👩🏼情侣:女人女人较浅肤色中等-浅肤色👩🏻‍❤️‍👩🏽情侣:女人女人
较浅肤色中等肤色👩🏻‍❤️‍👩🏾情侣:女人女人较浅肤色中等-深肤色👩🏻‍❤️‍👩🏿情侣:女人女人较浅肤色较深肤色👩🏻‍❤️‍💋‍👨🏻亲吻:女人男人较浅肤色👩🏻‍❤️‍💋
‍👨🏼亲吻:女人男人较浅肤色中等-浅肤色👩🏻‍❤️‍💋‍👨🏽亲吻:女人男人较浅肤色中等肤色👩🏻‍❤️‍💋‍👨🏾亲吻:女人男人较浅肤色中等-深肤色👩🏻‍❤️‍💋‍👨🏿亲
吻:女人男人较浅肤色较深肤色👩🏻‍❤️‍💋‍👩🏻亲吻:女人女人较浅肤色👩🏻‍❤️‍💋‍👩🏼亲吻:女人女人较浅肤色中等-浅肤色👩🏻‍❤️‍💋‍👩🏽亲吻:女人女人较浅肤色中等
肤色👩🏻‍❤️‍💋‍👩🏾亲吻:女人女人较浅肤色中等-深肤色👩🏻‍❤️‍💋‍👩🏿亲吻:女人女人较浅肤色较深肤色👩🏻‍🤝‍👨🏼手拉手的一男一女:较浅肤色中等-浅肤色👩🏻‍
🤝‍👨🏽手拉手的一男一女:较浅肤色中等肤色👩🏻‍🤝‍👨🏾手拉手的一男一女:较浅肤色中等-深肤色👩🏻‍🤝‍👨🏿手拉手的一男一女:较浅肤色较深肤色👩🏻‍🤝‍👩🏼手拉手的
两个女人:较浅肤色中等-浅肤色👩🏻‍🤝‍👩🏽手拉手的两个女人:较浅肤色中等肤色👩🏻‍🤝‍👩🏾手拉手的两个女人:较浅肤色中等-深肤色👩🏻‍🤝‍👩🏿手拉手的两个女人:较浅肤色
较深肤色👩🏼‍❤️‍👨🏻情侣:女人男人中等-浅肤色较浅肤色👩🏼‍❤️‍👨🏼情侣:女人男人中等-浅肤色👩🏼‍❤️‍👨🏽情侣:女人男人中等-浅肤色中等肤色👩🏼‍❤️‍👨🏾情
侣:女人男人中等-浅肤色中等-深肤色👩🏼‍❤️‍👨🏿情侣:女人男人中等-浅肤色较深肤色👩🏼‍❤️‍👩🏻情侣:女人女人中等-浅肤色较浅肤色👩🏼‍❤️‍👩🏼情侣:女人女人中等-浅肤
色👩🏼‍❤️‍👩🏽情侣:女人女人中等-浅肤色中等肤色👩🏼‍❤️‍👩🏾情侣:女人女人中等-浅肤色中等-深肤色👩🏼‍❤️‍👩🏿情侣:女人女人中等-浅肤色较深肤色👩🏼‍❤️‍💋
‍👨🏻亲吻:女人男人中等-浅肤色较浅肤色👩🏼‍❤️‍💋‍👨🏼亲吻:女人男人中等-浅肤色👩🏼‍❤️‍💋‍👨🏽亲吻:女人男人中等-浅肤色中等肤色👩🏼‍❤️‍💋‍👨🏾亲吻:
女人男人中等-浅肤色中等-深肤色👩🏼‍❤️‍💋‍👨🏿亲吻:女人男人中等-浅肤色较深肤色👩🏼‍❤️‍💋‍👩🏻亲吻:女人女人中等-浅肤色较浅肤色👩🏼‍❤️‍💋‍👩🏼亲吻:女人
女人中等-浅肤色👩🏼‍❤️‍💋‍👩🏽亲吻:女人女人中等-浅肤色中等肤色👩🏼‍❤️‍💋‍👩🏾亲吻:女人女人中等-浅肤色中等-深肤色👩🏼‍❤️‍💋‍👩🏿亲吻:女人女人中等-浅
肤色较深肤色👩🏼‍🤝‍👨🏻手拉手的一男一女:中等-浅肤色较浅肤色👩🏼‍🤝‍👨🏽手拉手的一男一女:中等-浅肤色中等肤色👩🏼‍🤝‍👨🏾手拉手的一男一女:中等-浅肤色中等-深肤
色👩🏼‍🤝‍👨🏿手拉手的一男一女:中等-浅肤色较深肤色👩🏼‍🤝‍👩🏻手拉手的两个女人:中等-浅肤色较浅肤色👩🏼‍🤝‍👩🏽手拉手的两个女人:中等-浅肤色中等肤色👩🏼‍
🤝‍👩🏾手拉手的两个女人:中等-浅肤色中等-深肤色👩🏼‍🤝‍👩🏿手拉手的两个女人:中等-浅肤色较深肤色👩🏽‍❤️‍👨🏻情侣:女人男人中等肤色较浅肤色👩🏽‍❤️‍👨🏼情侣
:女人男人中等肤色中等-浅肤色👩🏽‍❤️‍👨🏽情侣:女人男人中等肤色👩🏽‍❤️‍👨🏾情侣:女人男人中等肤色中等-深肤色👩🏽‍❤️‍👨🏿情侣:女人男人中等肤色较深肤色👩🏽‍❤
️‍👩🏻情侣:女人女人中等肤色较浅肤色👩🏽‍❤️‍👩🏼情侣:女人女人中等肤色中等-浅肤色👩🏽‍❤️‍👩🏽情侣:女人女人中等肤色👩🏽‍❤️‍👩🏾情侣:女人女人中等肤色中等-深
肤色👩🏽‍❤️‍👩🏿情侣:女人女人中等肤色较深肤色👩🏽‍❤️‍💋‍👨🏻亲吻:女人男人中等肤色较浅肤色👩🏽‍❤️‍💋‍👨🏼亲吻:女人男人中等肤色中等-浅肤色👩🏽‍❤️‍
💋‍👨🏽亲吻:女人男人中等肤色👩🏽‍❤️‍💋‍👨🏾亲吻:女人男人中等肤色中等-深肤色👩🏽‍❤️‍💋‍👨🏿亲吻:女人男人中等肤色较深肤色👩🏽‍❤️‍💋‍👩🏻亲吻:女人
女人中等肤色较浅肤色👩🏽‍❤️‍💋‍👩🏼亲吻:女人女人中等肤色中等-浅肤色👩🏽‍❤️‍💋‍👩🏽亲吻:女人女人中等肤色👩🏽‍❤️‍💋‍👩🏾亲吻:女人女人中等肤色中等-深肤色
👩🏽‍❤️‍💋‍👩🏿亲吻:女人女人中等肤色较深肤色👩🏽‍🤝‍👨🏻手拉手的一男一女:中等肤色较浅肤色👩🏽‍🤝‍👨🏼手拉手的一男一女:中等肤色中等-浅肤色👩🏽‍🤝‍👨
🏾手拉手的一男一女:中等肤色中等-深肤色👩🏽‍🤝‍👨🏿手拉手的一男一女:中等肤色较深肤色👩🏽‍🤝‍👩🏻手拉手的两个女人:中等肤色较浅肤色👩🏽‍🤝‍👩🏼手拉手的两个女人:
中等肤色中等-浅肤色👩🏽‍🤝‍👩🏾手拉手的两个女人:中等肤色中等-深肤色👩🏽‍🤝‍👩🏿手拉手的两个女人:中等肤色较深肤色👩🏾‍❤️‍👨🏻情侣:女人男人中等-深肤色较浅肤色
👩🏾‍❤️‍👨🏼情侣:女人男人中等-深肤色中等-浅肤色👩🏾‍❤️‍👨🏽情侣:女人男人中等-深肤色中等肤色👩🏾‍❤️‍👨🏾情侣:女人男人中等-深肤色👩🏾‍❤️‍👨🏿情侣:
女人男人中等-深肤色较深肤色👩🏾‍❤️‍👩🏻情侣:女人女人中等-深肤色较浅肤色👩🏾‍❤️‍👩🏼情侣:女人女人中等-深肤色中等-浅肤色👩🏾‍❤️‍👩🏽情侣:女人女人中等-深肤色中
等肤色👩🏾‍❤️‍👩🏾情侣:女人女人中等-深肤色👩🏾‍❤️‍👩🏿情侣:女人女人中等-深肤色较深肤色👩🏾‍❤️‍💋‍👨🏻亲吻:女人男人中等-深肤色较浅肤色👩🏾‍❤️‍💋‍
👨🏼亲吻:女人男人中等-深肤色中等-浅肤色👩🏾‍❤️‍💋‍👨🏽亲吻:女人男人中等-深肤色中等肤色👩🏾‍❤️‍💋‍👨🏾亲吻:女人男人中等-深肤色👩🏾‍❤️‍💋‍👨🏿亲吻
:女人男人中等-深肤色较深肤色👩🏾‍❤️‍💋‍👩🏻亲吻:女人女人中等-深肤色较浅肤色👩🏾‍❤️‍💋‍👩🏼亲吻:女人女人中等-深肤色中等-浅肤色👩🏾‍❤️‍💋‍👩🏽亲吻:女
人女人中等-深肤色中等肤色👩🏾‍❤️‍💋‍👩🏾亲吻:女人女人中等-深肤色👩🏾‍❤️‍💋‍👩🏿亲吻:女人女人中等-深肤色较深肤色👩🏾‍🤝‍👨🏻手拉手的一男一女:中等-深肤色
较浅肤色👩🏾‍🤝‍👨🏼手拉手的一男一女:中等-深肤色中等-浅肤色👩🏾‍🤝‍👨🏽手拉手的一男一女:中等-深肤色中等肤色👩🏾‍🤝‍👨🏿手拉手的一男一女:中等-深肤色较深肤色
👩🏾‍🤝‍👩🏻手拉手的两个女人:中等-深肤色较浅肤色👩🏾‍🤝‍👩🏼手拉手的两个女人:中等-深肤色中等-浅肤色👩🏾‍🤝‍👩🏽手拉手的两个女人:中等-深肤色中等肤色👩🏾‍
🤝‍👩🏿手拉手的两个女人:中等-深肤色较深肤色👩🏿‍❤️‍👨🏻情侣:女人男人较深肤色较浅肤色👩🏿‍❤️‍👨🏼情侣:女人男人较深肤色中等-浅肤色👩🏿‍❤️‍👨🏽情侣:女人男
人较深肤色中等肤色👩🏿‍❤️‍👨🏾情侣:女人男人较深肤色中等-深肤色👩🏿‍❤️‍👨🏿情侣:女人男人较深肤色👩🏿‍❤️‍👩🏻情侣:女人女人较深肤色较浅肤色👩🏿‍❤️‍👩🏼
情侣:女人女人较深肤色中等-浅肤色👩🏿‍❤️‍👩🏽情侣:女人女人较深肤色中等肤色👩🏿‍❤️‍👩🏾情侣:女人女人较深肤色中等-深肤色👩🏿‍❤️‍👩🏿情侣:女人女人较深肤色👩🏿
‍❤️‍💋‍👨🏻亲吻:女人男人较深肤色较浅肤色👩🏿‍❤️‍💋‍👨🏼亲吻:女人男人较深肤色中等-浅肤色👩🏿‍❤️‍💋‍👨🏽亲吻:女人男人较深肤色中等肤色👩🏿‍❤️‍💋‍
👨🏾亲吻:女人男人较深肤色中等-深肤色👩🏿‍❤️‍💋‍👨🏿亲吻:女人男人较深肤色👩🏿‍❤️‍💋‍👩🏻亲吻:女人女人较深肤色较浅肤色👩🏿‍❤️‍💋‍👩🏼亲吻:女人女人较
深肤色中等-浅肤色👩🏿‍❤️‍💋‍👩🏽亲吻:女人女人较深肤色中等肤色👩🏿‍❤️‍💋‍👩🏾亲吻:女人女人较深肤色中等-深肤色👩🏿‍❤️‍💋‍👩🏿亲吻:女人女人较深肤色👩
🏿‍🤝‍👨🏻手拉手的一男一女:较深肤色较浅肤色👩🏿‍🤝‍👨🏼手拉手的一男一女:较深肤色中等-浅肤色👩🏿‍🤝‍👨🏽手拉手的一男一女:较深肤色中等肤色👩🏿‍🤝‍👨🏾手
拉手的一男一女:较深肤色中等-深肤色👩🏿‍🤝‍👩🏻手拉手的两个女人:较深肤色较浅肤色👩🏿‍🤝‍👩🏼手拉手的两个女人:较深肤色中等-浅肤色👩🏿‍🤝‍👩🏽手拉手的两个女人:较
深肤色中等肤色👩🏿‍🤝‍👩🏾手拉手的两个女人:较深肤色中等-深肤色👫手拉手的一男一女👫🏻手拉手的一男一女:较浅肤色👫🏼手拉手的一男一女:中等-浅肤色👫🏽手拉手的一男一女:中等肤
色👫🏾手拉手的一男一女:中等-深肤色👫🏿手拉手的一男一女:较深肤色👬手拉手的两个男人👬🏻手拉手的两个男人:较浅肤色👬🏼手拉手的两个男人:中等-浅肤色👬🏽手拉手的两个男人:中等肤色
👬🏾手拉手的两个男人:中等-深肤色👬🏿手拉手的两个男人:较深肤色👭手拉手的两个女人👭🏻手拉手的两个女人:较浅肤色👭🏼手拉手的两个女人:中等-浅肤色👭🏽手拉手的两个女人:中等肤色
👭🏾手拉手的两个女人:中等-深肤色👭🏿手拉手的两个女人:较深肤色💏亲吻💏🏻亲吻:较浅肤色💏🏼亲吻:中等-浅肤色💏🏽亲吻:中等肤色💏🏾亲吻:中等-深肤色💏🏿亲吻:较深肤色
💑情侣💑🏻情侣:较浅肤色💑🏼情侣:中等-浅肤色💑🏽情侣:中等肤色💑🏾情侣:中等-深肤色💑🏿情侣:较深肤色🧑‍🤝‍🧑手拉手的两个人🧑🏻‍❤️‍💋‍🧑🏼亲吻:成人成人
较浅肤色中等-浅肤色🧑🏻‍❤️‍💋‍🧑🏽亲吻:成人成人较浅肤色中等肤色🧑🏻‍❤️‍💋‍🧑🏾亲吻:成人成人较浅肤色中等-深肤色🧑🏻‍❤️‍💋‍🧑🏿亲吻:成人成人较浅肤色较深
肤色🧑🏻‍❤️‍🧑🏼情侣:成人成人较浅肤色中等-浅肤色🧑🏻‍❤️‍🧑🏽情侣:成人成人较浅肤色中等肤色🧑🏻‍❤️‍🧑🏾情侣:成人成人较浅肤色中等-深肤色🧑🏻‍❤️‍🧑🏿情
侣:成人成人较浅肤色较深肤色🧑🏻‍🤝‍🧑🏻手拉手的两个人:较浅肤色🧑🏻‍🤝‍🧑🏼手拉手的两个人:较浅肤色中等-浅肤色🧑🏻‍🤝‍🧑🏽手拉手的两个人:较浅肤色中等肤色🧑🏻
‍🤝‍🧑🏾手拉手的两个人:较浅肤色中等-深肤色🧑🏻‍🤝‍🧑🏿手拉手的两个人:较浅肤色较深肤色🧑🏼‍❤️‍💋‍🧑🏻亲吻:成人成人中等-浅肤色较浅肤色🧑🏼‍❤️‍💋‍🧑
🏽亲吻:成人成人中等-浅肤色中等肤色🧑🏼‍❤️‍💋‍🧑🏾亲吻:成人成人中等-浅肤色中等-深肤色🧑🏼‍❤️‍💋‍🧑🏿亲吻:成人成人中等-浅肤色较深肤色🧑🏼‍❤️‍🧑🏻情侣:
成人成人中等-浅肤色较浅肤色🧑🏼‍❤️‍🧑🏽情侣:成人成人中等-浅肤色中等肤色🧑🏼‍❤️‍🧑🏾情侣:成人成人中等-浅肤色中等-深肤色🧑🏼‍❤️‍🧑🏿情侣:成人成人中等-浅肤色较
深肤色🧑🏼‍🤝‍🧑🏻手拉手的两个人:中等-浅肤色较浅肤色🧑🏼‍🤝‍🧑🏼手拉手的两个人:中等-浅肤色🧑🏼‍🤝‍🧑🏽手拉手的两个人:中等-浅肤色中等肤色🧑🏼‍🤝‍🧑
🏾手拉手的两个人:中等-浅肤色中等-深肤色🧑🏼‍🤝‍🧑🏿手拉手的两个人:中等-浅肤色较深肤色🧑🏽‍❤️‍💋‍🧑🏻亲吻:成人成人中等肤色较浅肤色🧑🏽‍❤️‍💋‍🧑🏼亲吻:
成人成人中等肤色中等-浅肤色🧑🏽‍❤️‍💋‍🧑🏾亲吻:成人成人中等肤色中等-深肤色🧑🏽‍❤️‍💋‍🧑🏿亲吻:成人成人中等肤色较深肤色🧑🏽‍❤️‍🧑🏻情侣:成人成人中等肤色较
浅肤色🧑🏽‍❤️‍🧑🏼情侣:成人成人中等肤色中等-浅肤色🧑🏽‍❤️‍🧑🏾情侣:成人成人中等肤色中等-深肤色🧑🏽‍❤️‍🧑🏿情侣:成人成人中等肤色较深肤色🧑🏽‍🤝‍🧑🏻
手拉手的两个人:中等肤色较浅肤色🧑🏽‍🤝‍🧑🏼手拉手的两个人:中等肤色中等-浅肤色🧑🏽‍🤝‍🧑🏽手拉手的两个人:中等肤色🧑🏽‍🤝‍🧑🏾手拉手的两个人:中等肤色中等-深肤色
🧑🏽‍🤝‍🧑🏿手拉手的两个人:中等肤色较深肤色🧑🏾‍❤️‍💋‍🧑🏻亲吻:成人成人中等-深肤色较浅肤色🧑🏾‍❤️‍💋‍🧑🏼亲吻:成人成人中等-深肤色中等-浅肤色🧑🏾‍❤
️‍💋‍🧑🏽亲吻:成人成人中等-深肤色中等肤色🧑🏾‍❤️‍💋‍🧑🏿亲吻:成人成人中等-深肤色较深肤色🧑🏾‍❤️‍🧑🏻情侣:成人成人中等-深肤色较浅肤色🧑🏾‍❤️‍🧑🏼情
侣:成人成人中等-深肤色中等-浅肤色🧑🏾‍❤️‍🧑🏽情侣:成人成人中等-深肤色中等肤色🧑🏾‍❤️‍🧑🏿情侣:成人成人中等-深肤色较深肤色🧑🏾‍🤝‍🧑🏻手拉手的两个人:中等-深
肤色较浅肤色🧑🏾‍🤝‍🧑🏼手拉手的两个人:中等-深肤色中等-浅肤色🧑🏾‍🤝‍🧑🏽手拉手的两个人:中等-深肤色中等肤色🧑🏾‍🤝‍🧑🏾手拉手的两个人:中等-深肤色🧑🏾‍
🤝‍🧑🏿手拉手的两个人:中等-深肤色较深肤色🧑🏿‍❤️‍💋‍🧑🏻亲吻:成人成人较深肤色较浅肤色🧑🏿‍❤️‍💋‍🧑🏼亲吻:成人成人较深肤色中等-浅肤色🧑🏿‍❤️‍💋‍🧑
🏽亲吻:成人成人较深肤色中等肤色🧑🏿‍❤️‍💋‍🧑🏾亲吻:成人成人较深肤色中等-深肤色🧑🏿‍❤️‍🧑🏻情侣:成人成人较深肤色较浅肤色🧑🏿‍❤️‍🧑🏼情侣:成人成人较深肤色中
等-浅肤色🧑🏿‍❤️‍🧑🏽情侣:成人成人较深肤色中等肤色🧑🏿‍❤️‍🧑🏾情侣:成人成人较深肤色中等-深肤色🧑🏿‍🤝‍🧑🏻手拉手的两个人:较深肤色较浅肤色🧑🏿‍🤝‍🧑
🏼手拉手的两个人:较深肤色中等-浅肤色🧑🏿‍🤝‍🧑🏽手拉手的两个人:较深肤色中等肤色🧑🏿‍🤝‍🧑🏾手拉手的两个人:较深肤色中等-深肤色🧑🏿‍🤝‍🧑🏿手拉手的两个人:较深
肤色👣人物符号11👣脚印👤人像👥双人像👪家庭🗣️说话🧑‍🧑‍🧒一孩家庭🧑‍🧑‍🧒‍🧒二孩家庭🧑‍🧒单亲一孩家庭🧑‍🧒‍🧒单亲二孩家庭🫂人的拥抱🫆指纹👩🏻‍
🦰肤色和发型9👨🏿肤色5🏻较浅肤色🏼中等-浅肤色🏽中等肤色🏾中等-深肤色🏿较深肤色🧑‍🦱发型4🦰红发🦱卷发🦲秃顶🦳白发🐵动物和自然160🐀哺乳动物66🐀耗子🐁老鼠
🐂公牛🐃水牛🐄奶牛🐅老虎🐆豹子🐇兔子🐈猫🐈‍⬛黑猫🐎马🐏公羊🐐山羊🐑母羊🐒猴子🐕狗🐕‍🦺服务犬🐖猪🐗野猪🐘大象🐨考拉🐩贵宾犬🐪骆驼🐫双峰骆驼🐭老鼠头🐮
奶牛头🐯老虎头🐰兔子头🐱猫脸🐴马头🐵猴头🐶狗脸🐷猪头🐹仓鼠🐺狼🐻熊🐻‍❄️北极熊🐼熊猫🐽猪鼻子🐾爪印🐿️松鼠🦁狮子🦄独角兽🦇蝙蝠🦊狐狸🦌鹿🦍大猩猩🦏犀牛🦒
长颈鹿🦓斑马🦔刺猬🦘袋鼠🦙美洲鸵🦛河马🦝浣熊🦡獾🦣猛犸🦥树懒🦦水獭🦧红毛猩猩🦨臭鼬🦫海狸🦬大野牛🦮导盲犬🫎驼鹿🫏驴🐓鸟类22🐓公鸡🐔鸡🐣小鸡破壳🐤小鸡🐥正
面朝向的小鸡🐦鸟🐦‍⬛黑色的鸟🐦‍🔥凤凰🐧企鹅🕊️鸽🦃火鸡🦅鹰🦆鸭子🦉猫头鹰🦚孔雀🦜鹦鹉🦢天鹅🦤渡渡鸟🦩火烈鸟🪶羽毛🪽翅膀🪿鹅🐸两栖动物1🐸青蛙🐍爬行动物8
🐉龙🐊鳄鱼🐍蛇🐢龟🐲龙头🦎蜥蜴🦕蜥蜴类🦖霸王龙🐟海洋生物18🐋鲸鱼🐙章鱼🐚海螺🐟鱼🐠热带鱼🐡河豚🐬海豚🐳喷水的鲸🦀蟹🦈鲨鱼🦐虾🦑乌贼🦞龙虾🦪牡蛎🦭海豹
🪸珊瑚🪼水母🫍虎鲸🐛昆虫16🐌蜗牛🐛毛毛虫🐜蚂蚁🐝蜜蜂🐞瓢虫🕷️蜘蛛🕸️蜘蛛网🦂蝎子🦋蝴蝶🦗蟋蟀🦟蚊子🦠细菌🪰苍蝇🪱蠕虫🪲甲虫🪳蟑螂🌹花朵12🌷郁金香🌸樱
花🌹玫瑰🌺芙蓉🌻向日葵🌼开花🏵️圆形花饰💐花束💮白花🥀枯萎的花🪷莲花🪻风信子🌴其他植物17☘️三叶草🌱幼苗🌲松树🌳落叶树🌴棕榈树🌵仙人掌🌾稻子🌿药草🍀四叶草🍁枫
叶🍂落叶🍃风吹叶落🍄蘑菇🪴盆栽植物🪹空巢🪺有蛋的巢🪾无叶树🍓食物和饮料131🍅水果20🍅西红柿🍇葡萄🍈甜瓜🍉西瓜🍊橘子🍋柠檬🍋‍🟩青柠🍌香蕉🍍菠萝🍎红苹果🍏青
苹果🍐梨🍑桃🍒樱桃🍓草莓🥝猕猴桃🥥椰子🥭芒果🫐蓝莓🫒橄榄🥬蔬菜19🌰栗子🌶️红辣椒🌽玉米🍄‍🟫褐色蘑菇🍆茄子🥑鳄梨🥒黄瓜🥔土豆🥕胡萝卜🥜花生🥦西兰花🥬绿叶
蔬菜🧄蒜🧅洋葱🫑灯笼椒🫘豆🫚姜🫛豌豆荚🫜根菜🍕熟食34🌭热狗🌮墨西哥卷饼🌯墨西哥玉米煎饼🍔汉堡🍕披萨🍖排骨🍗家禽的腿🍞面包🍟薯条🍲一锅食物🍳煎蛋🍿爆米花🥐羊角
面包🥓培根🥖法式长棍面包🥗绿色沙拉🥘装有食物的浅底锅🥙夹心饼🥚蛋🥞烙饼🥣碗勺🥨椒盐卷饼🥩肉块🥪三明治🥫罐头食品🥯面包圈🧀芝士🧂盐🧆炸豆丸子🧇华夫饼🧈黄油🫓扁面包
🫔墨西哥粽子🫕奶酪火锅🍚亚洲食物17🍘米饼🍙饭团🍚米饭🍛咖喱饭🍜面条🍝意粉🍠烤红薯🍡团子🍢关东煮🍣寿司🍤天妇罗🍥鱼板🍱盒饭🥟饺子🥠幸运饼干🥡外卖盒🥮月饼🍦甜点
14🍦圆筒冰激凌🍧刨冰🍨冰淇淋🍩甜甜圈🍪饼干🍫巧克力🍬糖🍭棒棒糖🍮奶黄🍯蜂蜜🍰水果蛋糕🎂生日蛋糕🥧派🧁纸杯蛋糕☕️饮料20☕热饮🍵热茶🍶清酒🍷葡萄酒🍸鸡尾酒🍹热带
水果饮料🍺啤酒🍻干杯🍼奶瓶🍾开香槟🥂碰杯🥃平底杯🥛一杯奶🥤带吸管杯🧃饮料盒🧉马黛茶🧊冰块🧋珍珠奶茶🫖茶壶🫗倾倒液体🍴餐具7🍴刀叉🍽️餐具🏺双耳瓶🔪菜刀🥄匙🥢筷
子🫙罐🚌旅行和地点219🌍️地图7🌍地球上的欧洲非洲🌎地球上的美洲🌏地球上的亚洲澳洲🌐带经纬线的地球🗺️世界地图🗾日本地图🧭指南针🌋自然风光10⛰️山🌋火山🏔️雪山🏕️露营
🏖️沙滩伞🏜️沙漠🏝️无人荒岛🏞️国家公园🗻富士山🛘山体滑坡🏗️建筑27🏗️施工🏘️房屋建筑🏚️废墟🏛️古典建筑🏟️体育馆🏠房子🏡别墅🏢办公楼🏣日本邮局🏤邮局🏥医院
🏦银行🏨酒店🏩情人酒店🏪便利店🏫学校🏬商场🏭工厂🏯日本城堡🏰欧洲城堡💒婚礼🗼东京塔🗽自由女神像🛖小屋🧱砖🪨岩石🪵木头⛪️宗教场所6⛩️神社⛪教堂🕋克尔白🕌清真寺🕍
犹太教堂🛕印度寺庙⛲️其他地点17♨️温泉⛲喷泉⛺帐篷🌁有雾🌃夜晚🌄山顶日出🌅日出🌆城市黄昏🌇日落🌉夜幕下的桥🎠旋转木马🎡摩天轮🎢过山车🎪马戏团帐篷🏙️城市风光💈理发店🛝
游乐场滑梯⛽️陆路交通50⛽油泵🏍️摩托车🏎️赛车🚂蒸汽火车🚃轨道车🚄高速列车🚅子弹头高速列车🚆火车🚇地铁🚈轻轨🚉车站🚊路面电车🚋有轨电车🚌公交车🚍迎面驶来的公交车🚎无轨
电车🚏公交车站🚐小巴🚑救护车🚒消防车🚓警车🚔迎面驶来的警车🚕出租车🚖迎面驶来的出租车🚗汽车🚘迎面驶来的汽车🚙运动型多用途车🚚货车🚛铰接式货车🚜拖拉机🚝单轨🚞山区铁路🚥
横向的红绿灯🚦纵向的红绿灯🚧路障🚨警车灯🚲自行车🛑停止标志🛞车轮🛢️石油桶🛣️高速公路🛤️铁轨🛴滑板车🛵小型摩托车🛹滑板🛺三轮摩托车🛻敞蓬小型载货卡车🛼四轮滑冰鞋🦼电动
轮椅🦽手动轮椅🚢水路交通9⚓锚⛴️渡轮⛵帆船🚢船🚤快艇🛟救生圈🛥️摩托艇🛳️客轮🛶独木舟✈️航空交通13✈️飞机💺座位🚀火箭🚁直升机🚟空轨🚠缆车🚡索道🛩️小型飞机🛫航班
起飞🛬航班降落🛰️卫星🛸飞碟🪂降落伞🛎️酒店2🛎️服务铃🧳行李箱⌚️时间31⌚手表⌛沙漏⏰闹钟⏱️秒表⏲️定时器⏳沙正往下流的沙漏🕐一点🕑两点🕒三点🕓四点🕔五点🕕六点🕖七点
🕗八点🕘九点🕙十点🕚十一点🕛十二点🕜一点半🕝两点半🕞三点半🕟四点半🕠五点半🕡六点半🕢七点半🕣八点半🕤九点半🕥十点半🕦十一点半🕧十二点半🕰️座钟☂️天空和天气47☀️
太阳☁️云☂️伞☃️雪与雪人☄️彗星☔雨伞⚡高压⛄雪人⛅阴⛈️雷阵雨⛱️阳伞❄️雪花⭐星星🌀台风🌂收起的伞🌈彩虹🌊浪花🌌银河🌑朔月🌒蛾眉月🌓上弦月🌔盈凸月🌕满月🌖亏凸月🌗下弦月
🌘残月🌙弯月🌚微笑的朔月🌛微笑的上弦月🌜微笑的下弦月🌝微笑的月亮🌞微笑的太阳🌟闪亮的星星🌠流星🌡️温度计🌤️晴偶有云🌥️多云🌦️晴转雨🌧️下雨🌨️下雪🌩️打雷🌪️龙卷
风🌫️雾🌬️大风💧水滴🔥火焰🪐有环行星⚽️活动85🎈节日21✨闪亮🎀蝴蝶结🎁礼物🎃南瓜灯🎄圣诞树🎆焰火🎇烟花🎈气球🎉拉炮彩带🎊五彩纸屑球🎋七夕树🎍门松🎎日本人形🎏
鲤鱼旗🎐风铃🎑赏月🎗️提示丝带🎟️入场券🎫票🧧红包🧨爆竹🏅奖项和奖牌6🎖️军功章🏅奖牌🏆奖杯🥇金牌🥈银牌🥉铜牌🏀运动27⚽足球⚾棒球⛳高尔夫球洞⛸️滑冰🎣钓鱼竿🎳保龄
球🎽运动背心🎾网球🎿滑雪🏀篮球🏈美式橄榄球🏉英式橄榄球🏏板球🏐排球🏑曲棍球🏒冰球🏓乒乓球🏸羽毛球🛷雪橇🤿潜水面罩🥅球门🥊拳击手套🥋练武服🥌冰壶🥍袋棍球🥎垒球🥏
飞盘🎯游戏24♟️兵♠️黑桃♣️梅花♥️红桃♦️方片🀄红中🃏大小王🎮游戏手柄🎯正中靶心的飞镖🎰老虎机🎱台球🎲骰子🎴花札🔫水枪🔮水晶球🕹️游戏操控杆🧩拼图🧸泰迪熊🪀悠悠球
🪁风筝🪄魔棒🪅彩罐🪆套娃🪩镜球🎨艺术和工艺7🎨调色盘🎭表演艺术🖼️带框的画🧵线🧶毛线🪡缝合针🪢结🔋物品266👖服装47⛑️白十字头盔🎒书包🎓毕业帽🎩礼帽👑皇冠👒
女帽👓眼镜👔领带👕T恤👖牛仔裤👗连衣裙👘和服👙比基尼👚女装👛钱包👜手提包👝手袋👞男鞋👟跑鞋👠高跟鞋👡女式凉鞋👢女靴💄唇膏💍戒指💎宝石📿念珠🕶️墨镜🛍️购物袋
🥻纱丽🥼白大褂🥽护目镜🥾登山鞋🥿平底鞋🦺救生衣🧢鸭舌帽🧣围巾🧤手套🧥外套🧦袜子🩰芭蕾舞鞋🩱连体泳衣🩲三角裤🩳短裤🩴夹趾凉鞋🪖军用头盔🪭折扇🪮发夹📢声音9📢喇叭
📣扩音器📯邮号🔇已静音的扬声器🔈低音量的扬声器🔉中等音量的扬声器🔊高音量的扬声器🔔铃铛🔕禁止响铃🎵音乐9🎙️录音室麦克风🎚️电平滑块🎛️控制旋钮🎤麦克风🎧耳机🎵音符🎶多
个音符🎼乐谱📻收音机🎹乐器13🎷萨克斯管🎸吉他🎹音乐键盘🎺小号🎻小提琴🥁鼓🪇沙球🪈长笛🪉竖琴🪊长号🪕班卓琴🪗手风琴🪘长鼓📞电话6☎️电话📞电话听筒📟寻呼机📠传真
机📱手机📲带有箭头的手机💻️电脑14⌨️键盘💻笔记本电脑💽电脑光盘💾软盘💿光盘📀DVD🔋电池🔌电源插头🖥️台式电脑🖨️打印机🖱️电脑鼠标🖲️轨迹球🧮算盘🪫电池电量不足
💡灯光和视频16🎞️影片帧🎥电影摄影机🎬场记板🏮红灯笼💡灯泡📷相机📸开闪光灯的相机📹摄像机📺电视机📼录像带📽️电影放映机🔍左斜的放大镜🔎右斜的放大镜🔦手电筒🕯️蜡烛🪔
印度油灯📒书籍和纸张17🏷️标签📃带卷边的页面📄文件📑标签页📒账本📓笔记本📔精装笔记本📕合上的书本📖打开的书本📗绿色书本📘蓝色书本📙橙色书本📚书📜卷轴📰报纸🔖书签🗞
️报纸卷💰金钱11💰钱袋💳信用卡💴日元💵美元💶欧元💷英镑💸长翅膀的钱💹趋势向上且带有日元符号的图表🧾收据🪎宝箱🪙硬币✉️邮件13✉️信封📤发件箱📥收件箱📦包裹📧电子邮件
📨来信📩收邮件📪无待收信件📫有待收信件📬有新信件📭无新信件📮邮筒🗳️投票箱✏️书写7✏️铅笔✒️钢笔尖📝备忘录🖊️笔🖋️钢笔🖌️画笔🖍️蜡笔✂️办公23✂️剪刀💼公文包📁
文件夹📂打开的文件夹📅日历📆手撕日历📇卡片索引📈趋势向上的图表📉趋势向下的图表📊条形图📋剪贴板📌图钉📍圆图钉📎回形针📏直尺📐三角尺🖇️连起来的两个回形针🗂️索引分隔文件夹
🗃️卡片盒🗄️文件柜🗑️垃圾桶🗒️线圈本🗓️线圈日历🔏锁和钥匙6🔏墨水笔和锁🔐钥匙和锁🔑钥匙🔒合上的锁🔓打开的锁🗝️老式钥匙⛏️工具27⚒️锤子与镐⚔️交叉放置的剑⚖️天平⚙️
齿轮⛏️铁镐⛓️链条⛓️‍💥断链🏹弓和箭💣炸弹🔗链接🔧扳手🔨锤子🔩螺母与螺栓🗜️夹钳🗡️匕首🛠️锤子与扳手🛡️盾牌🦯盲杖🧰工具箱🧲磁铁🪃回旋镖🪏铲🪓斧头🪚木工锯🪛
螺丝刀🪜梯子🪝挂钩🔭科技7⚗️蒸馏器📡卫星天线🔬显微镜🔭望远镜🧪试管🧫培养皿🧬DNA💊医疗7💉注射器💊药丸🩸血滴🩹创可贴🩺听诊器🩻X射线🩼拐杖🚽家居25🚪门🚽马
桶🚿淋浴🛁浴缸🛋️沙发和灯🛏️床🛒购物车🛗电梯🧯灭火器🧴乳液瓶🧷安全别针🧹扫帚🧺筐🧻卷纸🧼皂🧽海绵🪑椅子🪒剃须刀🪞镜子🪟窗户🪠活塞🪣桶🪤捕鼠器🪥牙刷🫧气泡
🚬其他物品9⚰️棺材⚱️骨灰缸🗿摩埃🚬香烟🧿纳扎尔护身符🪦墓碑🪧标语牌🪪身份证🪬法蒂玛之手🛑符号224🚻公共标志13♿轮椅标识🏧取款机🚮倒垃圾🚰饮用水🚹男厕🚺女厕🚻卫生
间🚼宝宝🚾厕所🛂护照检查🛃海关🛄提取行李🛅寄存行李⚠️警示13☢️辐射☣️生物危害⚠️警告⛔禁止通行📵禁止使用手机🔞18禁🚫禁止🚭禁止吸烟🚯禁止乱扔垃圾🚱非饮用水🚳禁止自行车
🚷禁止行人通行🚸儿童过街↩️箭头21↔️左右箭头↕️上下箭头↖️左上箭头↗️右上箭头↘️右下箭头↙️左下箭头↩️右转弯箭头↪️左转弯箭头➡️向右箭头⤴️右上弯箭头⤵️右下弯箭头⬅️向左箭头⬆️向上
箭头⬇️向下箭头🔃顺时针垂直箭头🔄逆时针箭头按钮🔙返回箭头🔚结束箭头🔛ON!箭头🔜SOON箭头🔝置顶☪️宗教13☦️东正教十字架☪️星月☮️和平符号☯️阴阳☸️法轮⚛️原子符号✝️十字架
✡️六芒星🔯带中间点的六芒星🕉️奥姆🕎烛台🛐宗教场所🪯坎达♈️星座13♈白羊座♉金牛座♊双子座♋巨蟹座♌狮子座♍处女座♎天秤座♏天蝎座♐射手座♑摩羯座♒水瓶座♓双鱼座⛎蛇夫座⏏️音频和视频符
号25⏏️推出按钮⏩快进按钮⏪快退按钮⏫快速上升按钮⏬快速下降按钮⏭️下一个音轨按钮⏮️上一个音轨按钮⏯️播放或暂停按钮⏸️暂停按钮⏹️停止按钮⏺️录制按钮▶️播放按钮◀️倒退按钮🎦电影院📳振动模
式📴手机关机📶信号强度条🔀随机播放音轨按钮🔁重复按钮🔂重复一次按钮🔅低亮度按钮🔆高亮度按钮🔼向上三角形按钮🔽向下三角形按钮🛜无线♀️性别3♀️女性符号♂️男性符号⚧️跨性别符号✖️
数学6♾️无穷大✖️乘➕加➖减➗除🟰粗等号‼️标点7‼️双感叹号⁉️感叹疑问号❓红色问号❔白色问号❕白色感叹号❗红色感叹号〰️波浪型破折号💲货币2💱货币兑换💲粗美元符号☑️其他符号22©️版权
®️注册™️商标☑️勾选框♻️回收标志⚕️医疗标志⚜️百合花饰✅勾号按钮✔️勾号✳️八轮辐星号✴️八角星❇️火花❌叉号❎叉号按钮➰卷曲环➿双卷曲环⭕红色空心圆圈〽️庵点📛姓名牌🔰日本新手驾驶标志
🔱三叉戟徽章🫟泼溅0️⃣键帽13#️⃣按键:#*️⃣键帽：*0️⃣键帽：01️⃣键帽：12️⃣键帽：23️⃣键帽：34️⃣键帽：45️⃣键帽：56️⃣键帽：67️⃣键帽：78️⃣键帽：89️⃣键帽
：9🔟按键:10🅰️字符39ℹ️信息Ⓜ️圆圈包围的M㊗️日文的“祝贺”按钮㊙️日文的“秘密”按钮🅰️A型血🅱️B型血🅾️O型血🅿️停车按钮🆎AB型血🆑CL按钮🆒cool按钮🆓免费按
钮🆔ID按钮🆕new按钮🆖NG按钮🆗OK按钮🆘SOS按钮🆙up按钮🆚VS按钮🈁日文的“这里”按钮🈂️日文的“服务费”按钮🈚日文的“免费”按钮🈯日文的“预留”按钮🈲日文的“禁止”
按钮🈳日文的“有空位”按钮🈴日文的“合格”按钮🈵日文的“没有空位”按钮🈶日文的“收费”按钮🈷️日文的“月总量”按钮🈸日文的“申请”按钮🈹日文的“打折”按钮🈺日文的“开始营业”按钮🉐日
文的“议价”按钮🉑日文的“可接受”按钮🔠输入大写拉丁字母🔡输入小写拉丁字母🔢输入数字🔣输入符号🔤输入拉丁字母🟣几何34▪️黑色小方块▫️白色小方块◻️白色中方块◼️黑色中方块◽白色中小方
块◾黑色中小方块⚪白色圆⚫黑色圆⬛黑线大方框⬜白线大方框💠带圆点的菱形🔘单选按钮🔲黑色方形按钮🔳白色方形按钮🔴红色圆🔵蓝色圆🔶橙色大菱形🔷蓝色大菱形🔸橙色小菱形🔹蓝色小菱形🔺红色
正三角🔻红色倒三角🟠橙色圆🟡黄色圆🟢绿色圆🟣紫色圆🟤棕色圆🟥红色方块🟦蓝色方块🟧橙色方块🟨黄色方块🟩绿色方块🟪紫色方块🟫棕色方块🏁旗帜270🚩普通旗帜8🎌交叉旗🏁黑白
方格旗🏳️白旗🏳️‍⚧️跨性别旗🏳️‍🌈彩虹旗🏴黑旗🏴‍☠️海盗旗🚩三角旗🇬🇧国家和地区旗帜259🇦🇨旗:阿森松岛🇦🇩旗:安道尔🇦🇪旗:阿拉伯联合酋长国🇦🇫旗:阿富汗
🇦🇬旗:安提瓜和巴布达🇦🇮旗:安圭拉🇦🇱旗:阿尔巴尼亚🇦🇲旗:亚美尼亚🇦🇴旗:安哥拉🇦🇶旗:南极洲🇦🇷旗:阿根廷🇦🇸旗:美属萨摩亚🇦🇹旗:奥地利🇦🇺旗:澳大利亚
🇦🇼旗:阿鲁巴🇦🇽旗:奥兰群岛🇦🇿旗:阿塞拜疆🇧🇦旗:波斯尼亚和黑塞哥维那🇧🇧旗:巴巴多斯🇧🇩旗:孟加拉国🇧🇪旗:比利时🇧🇫旗:布基纳法索🇧🇬旗:保加利亚🇧🇭旗
:巴林🇧🇮旗:布隆迪🇧🇯旗:贝宁🇧🇱旗:圣巴泰勒米🇧🇲旗:百慕大🇧🇳旗:文莱🇧🇴旗:玻利维亚🇧🇶旗:荷属加勒比区🇧🇷旗:巴西🇧🇸旗:巴哈马🇧🇹旗:不丹🇧🇻旗
:布韦岛🇧🇼旗:博茨瓦纳🇧🇾旗:白俄罗斯🇧🇿旗:伯利兹🇨🇦旗:加拿大🇨🇨旗:科科斯（基林）群岛🇨🇩旗:刚果（金）🇨🇫旗:中非共和国🇨🇬旗:刚果（布）🇨🇭旗:瑞士🇨
🇮旗:科特迪瓦🇨🇰旗:库克群岛🇨🇱旗:智利🇨🇲旗:喀麦隆🇨🇳旗:中国🇨🇴旗:哥伦比亚🇨🇵旗:克利珀顿岛🇨🇶旗:萨克岛🇨🇷旗:哥斯达黎加🇨🇺旗:古巴🇨🇻旗:佛得
角🇨🇼旗:库拉索🇨🇽旗:圣诞岛🇨🇾旗:塞浦路斯🇨🇿旗:捷克🇩🇪旗:德国🇩🇬旗:迪戈加西亚岛🇩🇯旗:吉布提🇩🇰旗:丹麦🇩🇲旗:多米尼克🇩🇴旗:多米尼加共和国🇩
🇿旗:阿尔及利亚🇪🇦旗:休达及梅利利亚🇪🇨旗:厄瓜多尔🇪🇪旗:爱沙尼亚🇪🇬旗:埃及🇪🇭旗:西撒哈拉🇪🇷旗:厄立特里亚🇪🇸旗:西班牙🇪🇹旗:埃塞俄比亚🇪🇺旗:欧盟
🇫🇮旗:芬兰🇫🇯旗:斐济🇫🇰旗:福克兰群岛🇫🇲旗:密克罗尼西亚🇫🇴旗:法罗群岛🇫🇷旗:法国🇬🇦旗:加蓬🇬🇧旗:英国🇬🇩旗:格林纳达🇬🇪旗:格鲁吉亚🇬🇫旗:法
属圭亚那🇬🇬旗:根西岛🇬🇭旗:加纳🇬🇮旗:直布罗陀🇬🇱旗:格陵兰🇬🇲旗:冈比亚🇬🇳旗:几内亚🇬🇵旗:瓜德罗普🇬🇶旗:赤道几内亚🇬🇷旗:希腊🇬🇸旗:南乔治亚和南桑
威奇群岛🇬🇹旗:危地马拉🇬🇺旗:关岛🇬🇼旗:几内亚比绍🇬🇾旗:圭亚那🇭🇰旗:中国香港特别行政区🇭🇲旗:赫德岛和麦克唐纳群岛🇭🇳旗:洪都拉斯🇭🇷旗:克罗地亚🇭🇹旗:海
地🇭🇺旗:匈牙利🇮🇨旗:加纳利群岛🇮🇩旗:印度尼西亚🇮🇪旗:爱尔兰🇮🇱旗:以色列🇮🇲旗:马恩岛🇮🇳旗:印度🇮🇴旗:英属印度洋领地🇮🇶旗:伊拉克🇮🇷旗:伊朗🇮
🇸旗:冰岛🇮🇹旗:意大利🇯🇪旗:泽西岛🇯🇲旗:牙买加🇯🇴旗:约旦🇯🇵旗:日本🇰🇪旗:肯尼亚🇰🇬旗:吉尔吉斯斯坦🇰🇭旗:柬埔寨🇰🇮旗:基里巴斯🇰🇲旗:科摩罗🇰
🇳旗:圣基茨和尼维斯🇰🇵旗:朝鲜🇰🇷旗:韩国🇰🇼旗:科威特🇰🇾旗:开曼群岛🇰🇿旗:哈萨克斯坦🇱🇦旗:老挝🇱🇧旗:黎巴嫩🇱🇨旗:圣卢西亚🇱🇮旗:列支敦士登🇱🇰旗
:斯里兰卡🇱🇷旗:利比里亚🇱🇸旗:莱索托🇱🇹旗:立陶宛🇱🇺旗:卢森堡🇱🇻旗:拉脱维亚🇱🇾旗:利比亚🇲🇦旗:摩洛哥🇲🇨旗:摩纳哥🇲🇩旗:摩尔多瓦🇲🇪旗:黑山🇲
🇫旗:法属圣马丁🇲🇬旗:马达加斯加🇲🇭旗:马绍尔群岛🇲🇰旗:北马其顿🇲🇱旗:马里🇲🇲旗:缅甸🇲🇳旗:蒙古🇲🇴旗:中国澳门特别行政区🇲🇵旗:北马里亚纳群岛🇲🇶旗:马
提尼克🇲🇷旗:毛里塔尼亚🇲🇸旗:蒙特塞拉特🇲🇹旗:马耳他🇲🇺旗:毛里求斯🇲🇻旗:马尔代夫🇲🇼旗:马拉维🇲🇽旗:墨西哥🇲🇾旗:马来西亚🇲🇿旗:莫桑比克🇳🇦旗:纳米
比亚🇳🇨旗:新喀里多尼亚🇳🇪旗:尼日尔🇳🇫旗:诺福克岛🇳🇬旗:尼日利亚🇳🇮旗:尼加拉瓜🇳🇱旗:荷兰🇳🇴旗:挪威🇳🇵旗:尼泊尔🇳🇷旗:瑙鲁🇳🇺旗:纽埃🇳🇿旗:
新西兰🇴🇲旗:阿曼🇵🇦旗:巴拿马🇵🇪旗:秘鲁🇵🇫旗:法属波利尼西亚🇵🇬旗:巴布亚新几内亚🇵🇭旗:菲律宾🇵🇰旗:巴基斯坦🇵🇱旗:波兰🇵🇲旗:圣皮埃尔和密克隆群岛🇵
🇳旗:皮特凯恩群岛🇵🇷旗:波多黎各🇵🇸旗:巴勒斯坦领土🇵🇹旗:葡萄牙🇵🇼旗:帕劳🇵🇾旗:巴拉圭🇶🇦旗:卡塔尔🇷🇪旗:留尼汪🇷🇴旗:罗马尼亚🇷🇸旗:塞尔维亚🇷🇺
旗:俄罗斯🇷🇼旗:卢旺达🇸🇦旗:沙特阿拉伯🇸🇧旗:所罗门群岛🇸🇨旗:塞舌尔🇸🇩旗:苏丹🇸🇪旗:瑞典🇸🇬旗:新加坡🇸🇭旗:圣赫勒拿🇸🇮旗:斯洛文尼亚🇸🇯旗:斯瓦尔
巴和扬马延🇸🇰旗:斯洛伐克🇸🇱旗:塞拉利昂🇸🇲旗:圣马力诺🇸🇳旗:塞内加尔🇸🇴旗:索马里🇸🇷旗:苏里南🇸🇸旗:南苏丹🇸🇹旗:圣多美和普林西比🇸🇻旗:萨尔瓦多🇸🇽
旗:荷属圣马丁🇸🇾旗:叙利亚🇸🇿旗:斯威士兰🇹🇦旗:特里斯坦-达库尼亚群岛🇹🇨旗:特克斯和凯科斯群岛🇹🇩旗:乍得🇹🇫旗:法属南部领地🇹🇬旗:多哥🇹🇭旗:泰国🇹🇯旗:
塔吉克斯坦🇹🇰旗:托克劳🇹🇱旗:东帝汶🇹🇲旗:土库曼斯坦🇹🇳旗:突尼斯🇹🇴旗:汤加🇹🇷旗:土耳其🇹🇹旗:特立尼达和多巴哥🇹🇻旗:图瓦卢🇹🇼旗:台湾🇹🇿旗:坦桑尼
亚🇺🇦旗:乌克兰🇺🇬旗:乌干达🇺🇲旗:美国本土外小岛屿🇺🇳旗:联合国🇺🇸旗:美国🇺🇾旗:乌拉圭🇺🇿旗:乌兹别克斯坦🇻🇦旗:梵蒂冈🇻🇨旗:圣文森特和格林纳丁斯🇻🇪
旗:委内瑞拉🇻🇬旗:英属维尔京群岛🇻🇮旗:美属维尔京群岛🇻🇳旗:越南🇻🇺旗:瓦努阿图🇼🇫旗:瓦利斯和富图纳🇼🇸旗:萨摩亚🇽🇰旗:科索沃🇾🇪旗:也门🇾🇹旗:马约特🇿
🇦旗:南非🇿🇲旗:赞比亚🇿🇼旗:津巴布韦🏴󠁧󠁢󠁥󠁮󠁧󠁿特殊地区旗帜3🏴󠁧󠁢󠁥󠁮󠁧󠁿旗:英格兰🏴󠁧󠁢󠁳󠁣󠁴󠁿旗:苏格兰🏴󠁧󠁢󠁷󠁬󠁳󠁿旗:
威尔士AI绘画平台🆕🕹️像素玩家🧱乐高积木风格🎬海报导演🪅皮克斯风格全部主题与风格*/